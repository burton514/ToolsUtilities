@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0.venv\Scripts\python.exe" (
  >&2 echo Veloura MCP: first run START_WINDOWS.cmd once to install dependencies.
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" -u "%~dp0mcp_stdio.py"
exit /b %errorlevel%
