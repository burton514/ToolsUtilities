"""ImageFlow core — Excel names, safe PNG export and persisted settings.
No GUI calls in this module so image work can run on a worker thread.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from urllib.parse import unquote, urlsplit

from PIL import Image, ImageOps
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

APP_DIR = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / ".local" / "share")) / "VelouraImageManager"
CONFIG_PATH = APP_DIR / "settings.json"

# Output choices are deliberately narrower than formats accepted as input.
OUTPUT_FORMATS = {"png": (".png", "PNG"), "jpg": (".jpg", "JPEG"),
                  "webp": (".webp", "WEBP"), "bmp": (".bmp", "BMP"),
                  "tiff": (".tiff", "TIFF")}
OUTPUT_EXTENSIONS = {ext: fmt for fmt, (ext, _) in OUTPUT_FORMATS.items()}
OUTPUT_EXTENSIONS.update({".jpeg": "jpg", ".tif": "tiff"})
SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff", ".avif"}
WINDOWS_FORBIDDEN = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
RESERVED_NAMES = {"CON", "PRN", "AUX", "NUL", *{f"COM{i}" for i in range(1, 10)}, *{f"LPT{i}" for i in range(1, 10)}}

DEFAULTS = {
    "destination": str(Path.home() / "Pictures" / "Veloura_Images"),
    "operation": "copy",
    "output_format": "png",
    "resize_enabled": False,
    "resize_width": 1024,
    "resize_height": 1024,
    "resize_mode": "contain",
    "conflict": "ask",
    "advance": True,
    "has_header": True,
    "last_excel": "",  # Legacy setting, retained for existing installations.
    "last_source": "",
    "last_sheet": "",
    "last_column": 1,
    "last_prompt_column": 0,
    "reference_path": "",
    "window_geometry": "1220x800",
}


@dataclass
class NameItem:
    name: str
    excel_row: int
    state: str = "pending"  # pending / existing / done / invalid
    detail: str = ""
    prompt: str = ""


@dataclass
class ExportOptions:
    destination: Path
    operation: str = "copy"
    resize_enabled: bool = False
    width: int = 1024
    height: int = 1024
    mode: str = "contain"
    overwrite: bool = False
    output_format: str = "png"
    output_extension: str | None = None  # Keep .jpeg/.tif when resizing in place.


@dataclass
class ExportResult:
    source: Path
    destination: Path
    width: int
    height: int
    moved: bool
    resized: bool
    bytes: int


def load_settings() -> dict:
    settings = dict(DEFAULTS)
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            settings.update({key: val for key, val in raw.items() if key in settings})
    except (OSError, ValueError, TypeError):
        pass
    if not settings["last_source"]:
        settings["last_source"] = settings["last_excel"]
    return settings


def save_settings(settings: dict) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    temp = CONFIG_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp, CONFIG_PATH)


def normalized_name(value: object) -> str:
    """Return a PNG basename without changing the user's other characters."""
    name = str(value).strip()
    # Spreadsheet cells sometimes already contain a source image extension.
    # Strip only recognized image suffixes; preserve dotted version names.
    suffix = Path(name).suffix.lower()
    if suffix in SUPPORTED_EXTENSIONS:
        name = name[:-len(suffix)].strip()
    return name


def validate_name(name: str) -> Optional[str]:
    if not name:
        return "Tên ảnh đang trống"
    if WINDOWS_FORBIDDEN.search(name):
        return 'Tên chứa ký tự không được phép: < > : " / \\ | ? *'
    if name[-1] in (" ", ".") or name in (".", ".."):
        return "Tên không được kết thúc bằng dấu cách hoặc dấu chấm"
    if name.split(".", 1)[0].upper() in RESERVED_NAMES:
        return "Tên được Windows dành riêng"
    if len(name) > 200:
        return "Tên ảnh quá dài (tối đa 200 ký tự)"
    return None


def cell_to_name(cell) -> str:
    value = cell.value
    if value is None or isinstance(value, bool):
        return ""
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, (int, float)):
        fmt = str(cell.number_format).strip()
        # Preserve identifiers styled as 0001, 0002 in Excel.
        if re.fullmatch(r"0{2,30}", fmt) and float(value).is_integer():
            return str(int(value)).zfill(len(fmt))
        if float(value).is_integer():
            return str(int(value))
        return str(value)
    return str(value).strip()


def load_excel_sheets(path: str):
    """Caller must close workbook after using it."""
    workbook = load_workbook(path, read_only=True, data_only=True)
    if not workbook.sheetnames:
        workbook.close()
        raise ValueError("Excel không có sheet nào")
    return workbook


@dataclass(frozen=True)
class CSVCell:
    """A small Excel-compatible cell wrapper so column selection works unchanged."""
    value: str
    row: int
    number_format: str = "General"


class CSVSheet:
    """Stream CSV rows rather than holding all image names in memory."""

    def __init__(self, path: Path, encoding: str, delimiter: str, has_sep_directive: bool):
        self.path = path
        self.encoding = encoding
        self.delimiter = delimiter
        self.has_sep_directive = has_sep_directive
        self.max_column = self._sample_column_count()

    def _records(self):
        with self.path.open("r", encoding=self.encoding, newline="") as stream:
            reader = csv.reader(stream, delimiter=self.delimiter, strict=True)
            if self.has_sep_directive:
                next(reader, None)
            for row_number, record in enumerate(reader, 1):
                yield row_number, record

    def _sample_column_count(self) -> int:
        width = 1
        for n, (_, record) in enumerate(self._records()):
            width = max(width, len(record))
            if n >= 999:
                break
        return min(width, 150)

    def iter_rows(self, min_row=1, max_row=None, min_col=1, max_col=None):
        last_col = max_col if max_col is not None else self.max_column
        for row_number, record in self._records():
            if row_number < min_row:
                continue
            if max_row is not None and row_number > max_row:
                break
            yield tuple(CSVCell(record[i - 1] if i <= len(record) else "", row_number)
                        for i in range(min_col, last_col + 1))


class CSVWorkbook:
    """One virtual sheet for CSV files, matching the Excel workbook interface."""
    sheetnames = ["Dữ liệu CSV"]
    is_csv = True

    def __init__(self, path: Path, encoding: str, delimiter: str, has_sep_directive: bool):
        self.sheet = CSVSheet(path, encoding, delimiter, has_sep_directive)

    def __getitem__(self, sheet_name: str):
        if sheet_name != self.sheetnames[0]:
            raise KeyError(sheet_name)
        return self.sheet

    @property
    def active(self):
        return self.sheet

    def close(self):
        pass


def _csv_encoding(sample: bytes) -> str:
    if sample.startswith((b"\xff\xfe", b"\xfe\xff")):
        return "utf-16"
    if sample.startswith(b"\xef\xbb\xbf"):
        return "utf-8-sig"
    # Handle UTF-16 exports without a BOM (e.g. certain text editors).
    if len(sample) > 4 and sample.count(b"\x00") > len(sample) // 8:
        even_zeros = sample[::2].count(0)
        odd_zeros = sample[1::2].count(0)
        if odd_zeros > even_zeros * 4:
            return "utf-16-le"
        if even_zeros > odd_zeros * 4:
            return "utf-16-be"
    try:
        sample[:-4].decode("utf-8-sig") if len(sample) >= 8 else sample.decode("utf-8-sig")
        return "utf-8-sig"
    except UnicodeDecodeError:
        # Windows ANSI CSV from Vietnamese Excel often uses CP1258.
        # Non-Unicode codepages cannot be recognized perfectly; CP1252 is
        # a useful fallback for CSV generated by other Windows locales.
        for fallback in ("cp1258", "cp1252", "latin-1"):
            try:
                sample.decode(fallback)
                return fallback
            except UnicodeDecodeError:
                continue
        raise ValueError("Không nhận diện được bảng mã CSV")


def load_csv_names(path: str) -> CSVWorkbook:
    """Read CSV with Vietnamese-friendly encodings and delimiter auto-detection."""
    source = Path(path)
    with source.open("rb") as stream:
        sample = stream.read(65536)
    if not sample:
        raise ValueError("CSV đang trống")
    encoding = _csv_encoding(sample)
    try:
        decoded = sample.decode(encoding)
    except UnicodeError as exc:
        raise ValueError("Không đọc được bảng mã CSV") from exc
    if "\x00" in decoded:
        raise ValueError("CSV chứa dữ liệu không hợp lệ")
    first = decoded.splitlines()[0].lstrip("\ufeff").strip() if decoded.splitlines() else ""
    has_sep_directive = len(first) == 5 and first[:4].lower() == "sep=" and first[4] in ",;\t|"
    if has_sep_directive:
        delimiter = first[4]
    else:
        # Guess common spreadsheet separators only. Avoid accidental splitting
        # of one-column files with arbitrary punctuation in image filenames.
        try:
            delimiter = csv.Sniffer().sniff(decoded, delimiters=",;\t|").delimiter
        except csv.Error:
            lines = [line for line in decoded.splitlines()[:30] if line.strip()]
            candidates = (",", ";", "\t", "|")
            delimiter = max(candidates, key=lambda ch: sum(line.count(ch) for line in lines))
    try:
        return CSVWorkbook(source, encoding, delimiter, has_sep_directive)
    except (UnicodeError, csv.Error) as exc:
        raise ValueError("Dữ liệu CSV không hợp lệ hoặc bảng mã không được hỗ trợ") from exc


def normalize_source_path(raw_path: str) -> str:
    """Normalize user-pasted Windows paths without modifying valid filenames.

    Explorer and other tools sometimes copy a Windows path as /C:/folder/file.csv
    or as a file:///C:/folder/file.csv URI. Both must become C:/folder/file.csv
    before they are passed to Windows file APIs. Keep regular local/UNC paths.
    """
    path = str(raw_path).strip()
    if len(path) >= 2 and path[0] == path[-1] and path[0] in ('"', "'"):
        path = path[1:-1].strip()
    if path.lower().startswith("file://"):
        parsed = urlsplit(path)
        if parsed.scheme.lower() != "file":
            raise ValueError("Đường dẫn file không hợp lệ")
        path = unquote(parsed.path)
        if parsed.netloc and parsed.netloc.lower() != "localhost":
            path = "//" + parsed.netloc + path
    # A leading slash ahead of a drive letter is not a Windows absolute path.
    # Strictly match the drive-letter form to preserve legitimate UNC paths.
    if re.match(r"^[/\\][A-Za-z]:[/\\]", path):
        path = path[1:]
    return path


def load_name_source(path: str):
    """Open a supported Excel or CSV file with a common sheet/column API."""
    path = normalize_source_path(path)
    extension = Path(path).suffix.lower()
    if extension == ".csv":
        return load_csv_names(path)
    if extension in (".xlsx", ".xlsm"):
        return load_excel_sheets(path)
    raise ValueError("Chỉ hỗ trợ file .xlsx, .xlsm hoặc .csv")


def get_column_options(sheet, has_header: bool):
    max_col = sheet.max_column
    if max_col is None:
        # Some valid XLSX producers omit the worksheet <dimension> element.
        # Discover columns from a small header sample instead of requiring it.
        max_col = max((len(row) for row in sheet.iter_rows(min_row=1, max_row=12)), default=1)
    limit = min(max(max_col, 1), 150)
    names = []
    first_row = next(sheet.iter_rows(min_row=1, max_row=1, min_col=1, max_col=limit), [])
    for idx in range(1, limit + 1):
        letter = get_column_letter(idx)
        label = cell_to_name(first_row[idx - 1]) if has_header and len(first_row) >= idx else ""
        if label:
            label = " ".join(label.split())[:40]
        names.append((idx, f"{letter}  ·  {label}" if label else f"{letter}  ·  Cột {letter}"))
    return names


def read_names(sheet, column: int, has_header: bool):
    if column < 1 or column > 150:
        raise ValueError("Cột không hợp lệ")
    start = 2 if has_header else 1
    output = []
    seen = set()
    duplicates = 0
    for row in sheet.iter_rows(min_row=start, min_col=column, max_col=column):
        cell = row[0]
        raw = cell_to_name(cell)
        if not raw:
            continue
        name = normalized_name(raw)
        if not name:
            continue
        key = name.casefold()
        if key in seen:
            duplicates += 1
            continue
        seen.add(key)
        error = validate_name(name)
        output.append(NameItem(name, cell.row, "invalid" if error else "pending", error or ""))
    return output, duplicates


def cell_to_prompt(cell) -> str:
    """Preserve the whole prompt, including line breaks, without changing it."""
    if cell is None or cell.value is None:
        return ""
    val = cell.value
    if isinstance(val, bool):
        return str(val)
    return str(val)


def read_names_with_prompts(sheet, name_column: int, prompt_column: int, has_header: bool):
    """Read name/prompt cells from the SAME source row, even when names repeat.

    A prompt column of 0 disables prompt reading. For duplicate names, the
    first matching source row is kept, retaining its corresponding prompt.
    """
    if not 1 <= name_column <= 150:
        raise ValueError("Cột tên ảnh không hợp lệ")
    if not 0 <= prompt_column <= 150:
        raise ValueError("Cột prompt không hợp lệ")
    start = 2 if has_header else 1
    first_col = min(name_column, prompt_column) if prompt_column else name_column
    last_col = max(name_column, prompt_column)
    output = []
    seen = set()
    duplicates = 0
    for cells in sheet.iter_rows(min_row=start, min_col=first_col, max_col=last_col):
        name_cell = cells[name_column - first_col]
        raw = cell_to_name(name_cell)
        if not raw:
            continue
        name = normalized_name(raw)
        if not name:
            continue
        key = name.casefold()
        if key in seen:
            duplicates += 1
            continue
        seen.add(key)
        error = validate_name(name)
        prompt = cell_to_prompt(cells[prompt_column - first_col]) if prompt_column else ""
        output.append(NameItem(name, name_cell.row, "invalid" if error else "pending", error or "", prompt))
    return output, duplicates


def dimensions_for(img: Image.Image, options: ExportOptions) -> tuple[int, int]:
    return (options.width, options.height) if options.resize_enabled else img.size


def resized_image(image: Image.Image, width: int, height: int, mode: str) -> Image.Image:
    """Resize with alpha preserved. No resize can occur without explicit enabling."""
    if mode not in {"contain", "cover", "stretch"}:
        raise ValueError("Cách resize không hợp lệ")
    img = image.convert("RGBA")
    target = (width, height)
    if mode == "stretch":
        return img.resize(target, Image.Resampling.LANCZOS)
    if mode == "cover":
        return ImageOps.fit(img, target, method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
    # Contain: do not crop; pad remaining space with TRANSPARENT pixels.
    img.thumbnail(target, Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", target, (0, 0, 0, 0))
    canvas.alpha_composite(img, ((width - img.width) // 2, (height - img.height) // 2))
    return canvas




def _commit_png(temp_path: Path, destination: Path, overwrite: bool) -> None:
    """Publish a fully-written temporary PNG without a check/rename race.

    For no-replace, CreateHardLink (via os.link) is atomic on a local filesystem;
    only one competing writer can claim a destination. On Windows filesystems
    without hard links, MoveFileExW without REPLACE_EXISTING is a safe fallback.
    If neither is available, fail closed rather than risking overwriting an icon.
    """
    if overwrite:
        os.replace(temp_path, destination)
        return
    try:
        os.link(temp_path, destination)
    except FileExistsError:
        raise FileExistsError(f"Ảnh đích đã tồn tại: {destination.name}") from None
    except OSError as exc:
        if os.name != "nt":
            raise OSError(f"Không thể ghi PNG an toàn trên ổ này: {exc}") from exc
        import ctypes
        from ctypes import wintypes
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.MoveFileExW.argtypes = (wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD)
        kernel32.MoveFileExW.restype = wintypes.BOOL
        # Flags=0: do not replace an existing destination, same-volume atomic rename.
        if not kernel32.MoveFileExW(str(temp_path), str(destination), 0):
            code = ctypes.get_last_error()
            if code in (80, 183):
                raise FileExistsError(f"Ảnh đích đã tồn tại: {destination.name}") from None
            raise OSError(code, f"Không thể ghi PNG an toàn trên ổ này: {destination}") from exc
    else:
        temp_path.unlink()  # Remove the extra link after the destination was claimed.

def _export_image_unlocked(source: Path, name: str, options: ExportOptions) -> ExportResult:
    """Atomically export an image; delete source only after a successful commit."""
    source = Path(source).expanduser().resolve()
    dest_dir = Path(options.destination).expanduser().resolve()
    err = validate_name(name)
    if err:
        raise ValueError(err)
    if not source.is_file():
        raise FileNotFoundError("Không tìm thấy ảnh nguồn")
    if source.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError("Định dạng ảnh không được hỗ trợ")
    if options.operation not in ("copy", "move"):
        raise ValueError("Thao tác không hợp lệ")
    if options.resize_enabled and (not 1 <= options.width <= 16384 or not 1 <= options.height <= 16384):
        raise ValueError("Kích thước resize phải từ 1 đến 16384 pixel")
    if options.resize_enabled and options.width * options.height > 80_000_000:
        raise ValueError("Kích thước quá lớn (tối đa 80 triệu pixel)")
    output_format = str(options.output_format).lower()
    if output_format not in OUTPUT_FORMATS:
        raise ValueError("Định dạng xuất ảnh không được hỗ trợ")
    extension, pil_format = OUTPUT_FORMATS[output_format]
    if options.output_extension is not None:
        requested = str(options.output_extension)
        if OUTPUT_EXTENSIONS.get(requested.lower()) != output_format:
            raise ValueError('Phần mở rộng không phù hợp định dạng ảnh')
        extension = requested
    dest = dest_dir / (name + extension)
    if len(str(dest)) > 245 and os.name == "nt":
        raise ValueError("Đường dẫn quá dài. Hãy chọn thư mục đích ngắn hơn")
    same_file = os.path.normcase(str(source)) == os.path.normcase(str(dest))
    if dest.exists() and not options.overwrite:
        raise FileExistsError("Ảnh đích đã tồn tại")
    if dest.exists() and dest.is_dir():
        raise IsADirectoryError("Tên ảnh trùng một thư mục hiện có")
    dest_dir.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        # Use a temp file in the destination directory so committing is atomic.
        with tempfile.NamedTemporaryFile(prefix=".veloura_", suffix=extension, dir=str(dest_dir), delete=False) as tmp:
            temp_path = Path(tmp.name)
        if output_format == "png" and source.suffix.lower() == ".png" and not options.resize_enabled:
            shutil.copyfile(source, temp_path)
            with Image.open(temp_path) as check:
                check.verify()
            with Image.open(source) as info:
                size = info.size
        else:
            with Image.open(source) as opened:
                opened.load()
                image = ImageOps.exif_transpose(opened)
                if options.resize_enabled:
                    result = resized_image(image, options.width, options.height, options.mode)
                else:
                    result = image.convert("RGBA") if image.mode in ("RGBA", "P", "LA") or "transparency" in image.info else image.convert("RGB")
                # JPEG/BMP cannot represent alpha: flatten onto white rather
                # than silently dropping transparent pixels to black.
                if output_format in ("jpg", "bmp"):
                    rgba = result.convert("RGBA")
                    background = Image.new("RGB", rgba.size, "white")
                    background.paste(rgba, mask=rgba.getchannel("A"))
                    result.close()
                    rgba.close()
                    result = background
                elif output_format in ("webp", "tiff") and result.mode not in ("RGB", "RGBA"):
                    converted = result.convert("RGBA")
                    result.close()
                    result = converted
                kwargs = ({"optimize": True} if output_format == "png" else
                          {"quality": 94, "subsampling": 0} if output_format == "jpg" else
                          {"quality": 95, "method": 4} if output_format == "webp" else
                          {"compression": "tiff_deflate"} if output_format == "tiff" else {})
                result.save(temp_path, format=pil_format, **kwargs)
                size = result.size
                result.close()
        # Atomic no-replace commit: another writer cannot win between check and rename.
        _commit_png(temp_path, dest, options.overwrite)
        temp_path = None
        moved = options.operation == "move" and not same_file
        if moved:
            # If deletion fails, keep the valid destination, and notify the caller.
            try:
                source.unlink()
            except OSError as exc:
                raise RuntimeError("Đã lưu ảnh đích nhưng không thể xóa ảnh nguồn: " + str(exc)) from exc
        return ExportResult(source, dest, size[0], size[1], moved, options.resize_enabled, dest.stat().st_size)
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass


def save_csv_log(path: Path, entries: list[dict]):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, ["Thời gian", "Tên ảnh", "Ảnh nguồn", "Ảnh đích", "Thao tác", "Kích thước", "Kết quả"])
        writer.writeheader()
        for row in entries:
            writer.writerow({key: row.get(key, "") for key in writer.fieldnames})

# All callers (GUI and Agent) must serialize writes to an image folder.
def export_image(source: Path, name: str, options: ExportOptions) -> ExportResult:
    import hashlib
    from storage_lock import file_lock
    destination = Path(options.destination).expanduser().resolve(strict=False)
    key = hashlib.sha256(os.path.normcase(str(destination)).encode('utf-8')).hexdigest()
    with file_lock(APP_DIR / 'locks' / (key + '.lock')):
        return _export_image_unlocked(source, name, options)


def export_png(source: Path, name: str, options: ExportOptions) -> ExportResult:
    """Backward-compatible entry point; honors options.output_format."""
    return export_image(source, name, options)


def assemble_prompt(prompt: str, name: str, template: str = '', enabled: bool = False) -> str:
    """Exact shared Prompt-template logic for both GUI and local Agent."""
    if not enabled or not template.strip():
        return prompt
    template = template.strip()
    if '{prompt}' in template:
        return template.replace('{prompt}', prompt).replace('{name}', name)
    return template.replace('{name}', name) + '\n\n' + prompt
