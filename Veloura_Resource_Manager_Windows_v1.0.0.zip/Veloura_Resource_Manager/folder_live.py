"""Folder-first PNG monitoring, with native Windows events and no disk cache.

A worker watches the directory; the Tk thread never scans it on every tick.
On Windows, FindFirstChangeNotificationW wakes the worker only after actual
filesystem changes. A slow reconciliation scan protects against lost events,
network filesystems, and changes made while switching projects. Other systems
use a polling fallback. Only changed PNGs are decoded/validated on rescans.
"""
from __future__ import annotations

import hashlib
import os
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable
from PIL import Image
from imageflow_core import OUTPUT_EXTENSIONS, OUTPUT_FORMATS


@dataclass(frozen=True)
class IconFile:
    path: Path
    size: int
    modified_ns: int
    inode: int = 0
    valid: bool = True
    # Keep this in RAM only. A coarse Windows directory event cannot tell us
    # which PNG changed if a writer restores size/mtime after replacing it.
    content_digest: str = ""
    change_ns: int = 0


@dataclass
class FolderSnapshot:
    folder: str = ""
    files: dict[str, IconFile] = field(default_factory=dict)
    error: str = ""
    # Offline/missing output is not the same as a successfully scanned empty
    # directory. Consumers must never delete persistent review marks offline.
    available: bool = True

    def for_icon(self, icon_name: str, preferred: str = "png") -> IconFile | None:
        """Return one valid exported image; prefer selected format, then PNG.

        Other formats remain visible when the user changes the export choice.
        """
        preferred_ext = OUTPUT_FORMATS.get(str(preferred).lower(), OUTPUT_FORMATS["png"])[0]
        suffixes = (preferred_ext, ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".tif")
        for ext in dict.fromkeys(suffixes):
            found = self.files.get((icon_name + ext).casefold())
            if found is not None and found.valid:
                return found
        return None

    def invalid_for_icon(self, icon_name: str, preferred: str = "png") -> IconFile | None:
        preferred_ext = OUTPUT_FORMATS.get(str(preferred).lower(), OUTPUT_FORMATS["png"])[0]
        suffixes = (preferred_ext, ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".tif")
        for ext in dict.fromkeys(suffixes):
            found = self.files.get((icon_name + ext).casefold())
            if found is not None and not found.valid:
                return found
        return None


def _is_valid_png(path: str, size: int) -> bool:
    """Validate image bytes against extension; no disk cache is kept."""
    if size < 32:
        return False
    expected = OUTPUT_EXTENSIONS.get(Path(path).suffix.lower())
    if not expected:
        return False
    expected_pil = OUTPUT_FORMATS[expected][1]
    try:
        with Image.open(path) as picture:
            if picture.format != expected_pil:
                return False
            picture.verify()
        with Image.open(path) as picture:
            picture.load()
            return picture.format == expected_pil
    except (OSError, ValueError, SyntaxError, EOFError, Image.DecompressionBombError):
        return False


def _png_fingerprint(path: str) -> str:
    """Small in-RAM fingerprint only; never create an image cache on disk."""
    checksum = hashlib.blake2b(digest_size=16)
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(chunk)
    return checksum.hexdigest()


def scan_png_folder(folder: str | Path | None,
                    previous: FolderSnapshot | None = None,
                    check_contents: bool = False) -> FolderSnapshot:
    """Read actual folder entries and validate only changed PNGs.

    When a *coarse* Windows folder event occurs or the user requests an F5
    refresh, check_contents detects byte changes even if size and mtime were
    restored. Unchanged images are hashed but never decoded again. Ordinary
    periodic reconciliation uses metadata only; no disk image cache exists.
    """
    directory = os.fspath(folder).strip() if folder is not None else ""
    snapshot = FolderSnapshot(folder=directory)
    if not directory:
        snapshot.available = False
        return snapshot
    old_files = previous.files if previous is not None and previous.folder == directory and not previous.error else {}
    try:
        with os.scandir(directory) as entries:
            for entry in entries:
                lower = entry.name.casefold()
                # Atomic exporters use hidden temporary PNGs; these are never
                # finished icons and must never appear as corrupt gallery items.
                if Path(lower).suffix not in OUTPUT_EXTENSIONS or lower.startswith(".veloura_"):
                    continue
                try:
                    if not entry.is_file():
                        continue
                    stat = entry.stat()
                except (FileNotFoundError, PermissionError, OSError):
                    # A disappearing/locked entry during enumeration means
                    # this scan was incomplete. It is not proof of deletion.
                    snapshot.available = False
                    snapshot.error = "Thư mục PNG đang thay đổi; sẽ kiểm tra lại"
                    return snapshot
                inode = getattr(stat, "st_ino", 0)
                change_ns = getattr(stat, "st_ctime_ns", 0)
                key = entry.name.casefold()
                old = old_files.get(key)
                same_metadata = (old is not None and old.path == Path(entry.path)
                                 and old.size == stat.st_size
                                 and old.modified_ns == stat.st_mtime_ns
                                 and old.inode == inode
                                 and old.change_ns == change_ns)
                if same_metadata and not check_contents:
                    valid, digest = old.valid, old.content_digest
                else:
                    try:
                        digest = _png_fingerprint(entry.path)
                    except (OSError, ValueError):
                        # A file being written or locked cannot be confirmed
                        # deleted/corrupt; don't prune manual state for it.
                        snapshot.available = False
                        snapshot.error = "Chưa đọc được đầy đủ file PNG trong thư mục"
                        return snapshot
                    valid = (old.valid if same_metadata and digest == old.content_digest
                             else _is_valid_png(entry.path, stat.st_size))
                snapshot.files[key] = IconFile(
                    Path(entry.path), stat.st_size, stat.st_mtime_ns, inode,
                    valid, digest, change_ns,
                )
    except FileNotFoundError:
        # Missing folders are NOT equivalent to an accessible empty folder.
        # A removable/network drive may reconnect; preserve review marks.
        snapshot.available = False
    except NotADirectoryError:
        snapshot.available = False
        snapshot.error = "Đường dẫn đích không phải thư mục"
    except OSError as exc:
        snapshot.available = False
        snapshot.error = str(exc)
    return snapshot


class _WindowsFolderWatcher:
    """Windows kernel directory notifications; no external dependencies.

    Notifications intentionally do not store duplicate filename data. The
    worker enumerates *metadata* after an event, validating only modified PNGs.
    Periodic reconciliation covers transient/disconnected network folders.
    """

    def __init__(self, folder: str):
        import ctypes
        from ctypes import wintypes

        self._ctypes = ctypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.FindFirstChangeNotificationW.argtypes = (wintypes.LPCWSTR, wintypes.BOOL, wintypes.DWORD)
        kernel.FindFirstChangeNotificationW.restype = wintypes.HANDLE
        kernel.FindNextChangeNotification.argtypes = (wintypes.HANDLE,)
        kernel.FindNextChangeNotification.restype = wintypes.BOOL
        kernel.FindCloseChangeNotification.argtypes = (wintypes.HANDLE,)
        kernel.FindCloseChangeNotification.restype = wintypes.BOOL
        kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        self._kernel = kernel
        mask = 0x00000001 | 0x00000002 | 0x00000008 | 0x00000010 | 0x00000040
        handle = kernel.FindFirstChangeNotificationW(folder, False, mask)
        if handle in (None, 0, wintypes.HANDLE(-1).value):
            raise OSError(ctypes.get_last_error(), "Không thể theo dõi thay đổi folder")
        self._handle = handle

    def wait(self, timeout: float) -> bool:
        if not self._handle:
            return False
        result = self._kernel.WaitForSingleObject(self._handle, max(0, int(timeout * 1000)))
        if result == 0:  # WAIT_OBJECT_0
            if not self._kernel.FindNextChangeNotification(self._handle):
                raise OSError(self._ctypes.get_last_error(), "Folder watcher không còn hoạt động")
            return True
        if result == 0x102:  # WAIT_TIMEOUT
            return False
        raise OSError(self._ctypes.get_last_error(), "Không đọc được thông báo thay đổi folder")

    def close(self):
        if self._handle:
            self._kernel.FindCloseChangeNotification(self._handle)
            self._handle = None


def _native_watcher(folder: str):
    if os.name != "nt" or not folder or not os.path.isdir(folder):
        return None
    try:
        return _WindowsFolderWatcher(folder)
    except (OSError, AttributeError):
        return None


class FolderLiveMonitor:
    """Publish authoritative snapshots, ignoring events for old projects.

    Windows: event-based + periodic safety reconciliation (default 45 s).
    Fallback: metadata polling, with unchanged PNGs never decoded again.
    """

    def __init__(self, callback: Callable[[int, FolderSnapshot], None], interval: float = 2.5,
                 reconcile_interval: float = 45.0, watcher_factory=None):
        self._callback = callback
        self._interval = max(0.2, interval)
        self._reconcile_interval = max(1.0, reconcile_interval)
        self._watcher_factory = watcher_factory or _native_watcher
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._stopped = threading.Event()
        self._paused = threading.Event()
        self._folder = ""
        self._generation = 0
        self._previous: FolderSnapshot | None = None
        self._thread = threading.Thread(target=self._run, name="VelouraFolderLive", daemon=True)
        self._thread.start()

    def watch(self, folder: str | Path | None) -> int:
        next_folder = os.fspath(folder).strip() if folder is not None else ""
        with self._lock:
            self._folder = next_folder
            self._generation += 1
            self._previous = None
            generation = self._generation
        self._wake.set()
        return generation

    def pause(self):
        """Suspend expensive rescans while a GUI batch writes many files."""
        self._paused.set()

    def resume(self):
        """Re-enable authoritative monitoring after a batch finishes."""
        self._paused.clear()
        self._wake.set()

    def stop(self):
        self._stopped.set()
        self._wake.set()
        if self._thread.is_alive() and threading.current_thread() is not self._thread:
            self._thread.join(timeout=3)

    def _publish(self, generation, folder, snapshot):
        with self._lock:
            if generation != self._generation or folder != self._folder:
                return
            if self._previous == snapshot:
                return
            self._previous = snapshot
        if not self._stopped.is_set():
            self._callback(generation, snapshot)

    def _run(self):
        watcher = None
        active = -1
        last_scan = 0.0
        try:
            while not self._stopped.is_set():
                if self._paused.is_set():
                    self._stopped.wait(timeout=0.12)
                    continue
                with self._lock:
                    generation, folder = self._generation, self._folder
                if generation != active:
                    if watcher is not None:
                        watcher.close()
                    watcher = self._watcher_factory(folder)
                    active = generation
                    # Watcher is installed before initial scan to avoid missing
                    # changes between initial enumeration and event subscription.
                    snapshot = scan_png_folder(folder)
                    self._publish(generation, folder, snapshot)
                    last_scan = time.monotonic()
                    self._wake.clear()
                    continue

                if watcher is not None:
                    try:
                        event = watcher.wait(min(self._interval, 0.4))
                        if event:
                            # Coalesce burst notifications during a file copy or
                            # rename; only inspect the folder after events settle.
                            deadline = time.monotonic() + 0.16
                            while not self._stopped.is_set():
                                remaining = deadline - time.monotonic()
                                if remaining <= 0 or not watcher.wait(min(remaining, 0.04)):
                                    break
                    except OSError:
                        watcher.close()
                        watcher = None
                        event = True  # immediate full reconciliation on failure
                else:
                    self._wake.wait(timeout=self._interval)
                    self._wake.clear()
                    event = True

                if self._paused.is_set():
                    continue
                now = time.monotonic()
                if not event and now - last_scan < self._reconcile_interval:
                    continue
                # A replaced/missing folder requires a new native watcher.
                if watcher is None and os.path.isdir(folder):
                    watcher = self._watcher_factory(folder)
                with self._lock:
                    previous = self._previous if generation == self._generation else None
                # Native notifications are coarse: their payload contains no
                # filenames. Fingerprint existing bytes on genuine events so
                # same-size / restored-mtime overwrites cannot be overlooked.
                # Polling/reconciliation does not rehash unchanged files.
                snapshot = scan_png_folder(folder, previous, check_contents=bool(watcher is not None and event))
                self._publish(generation, folder, snapshot)
                last_scan = now
        finally:
            if watcher is not None:
                watcher.close()
