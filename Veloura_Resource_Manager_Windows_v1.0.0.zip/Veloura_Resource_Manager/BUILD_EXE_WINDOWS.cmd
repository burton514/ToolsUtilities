@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_exe_windows.ps1"
if errorlevel 1 (
  echo.
  echo EXE build failed. See the message above.
  pause
  exit /b 1
)
echo.
echo EXE created in the dist folder.
pause
endlocal
