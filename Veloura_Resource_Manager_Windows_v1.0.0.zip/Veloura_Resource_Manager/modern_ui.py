"""Monochrome desktop shell and explicit page-feature method routing.

Image export, CSV/Excel loading, project switching and clipboard logic are
implemented by the controller feature modules and are not duplicated here.
"""
from __future__ import annotations
import tkinter as tk
from pathlib import Path
from app_version import APP_TITLE
from ui_thumbnail_cache import ThumbnailCache
from tkinter import ttk
from PIL import Image, ImageTk


from veloura.gui.theme import ACTIVE, BG, BLACK, BORDER, F, FIELD, HOVER, INK, MED, MUTED, SMALL, SOFT, WHITE


from veloura.gui.workspace import WorkspaceUI
from veloura.gui.gallery import GalleryUI
from veloura.gui.projects import ProjectsUI
from veloura.gui.other_pages import OtherPagesUI


class MonoUI:
    """Desktop presentation methods explicitly delegated to their feature modules."""
    _build_sidebar = WorkspaceUI._build_sidebar
    toggle_source_details = WorkspaceUI.toggle_source_details
    _build_main_panel = WorkspaceUI._build_main_panel
    _resize_options = staticmethod(WorkspaceUI._resize_options)
    _conflict_options = staticmethod(WorkspaceUI._conflict_options)
    _responsive_workspace = WorkspaceUI._responsive_workspace
    _resize_right_content = WorkspaceUI._resize_right_content
    _update_counter = WorkspaceUI._update_counter
    paint_dropzone = WorkspaceUI.paint_dropzone
    select_previous = WorkspaceUI.select_previous
    _update_review_controls = WorkspaceUI._update_review_controls
    _refresh_selected_output_preview = WorkspaceUI._refresh_selected_output_preview
    _show_preview = WorkspaceUI._show_preview
    rename_item = WorkspaceUI.rename_item
    _restore_reference = WorkspaceUI._restore_reference
    _update_reference_scroll_region = WorkspaceUI._update_reference_scroll_region
    _render_reference = WorkspaceUI._render_reference
    _toggle_reference_for_icon = WorkspaceUI._toggle_reference_for_icon
    _store_reference_config = WorkspaceUI._store_reference_config
    choose_reference = WorkspaceUI.choose_reference
    set_reference = WorkspaceUI.set_reference
    clear_reference = WorkspaceUI.clear_reference
    _remove_reference = WorkspaceUI._remove_reference
    copy_reference = WorkspaceUI.copy_reference
    _refresh_target = WorkspaceUI._refresh_target
    _update_empty_selection = WorkspaceUI._update_empty_selection
    persist_settings = WorkspaceUI.persist_settings
    _install_project = WorkspaceUI._install_project
    _get_template_text = WorkspaceUI._get_template_text
    _set_template_text = WorkspaceUI._set_template_text
    _assembled_prompt = WorkspaceUI._assembled_prompt
    _refresh_prompt = WorkspaceUI._refresh_prompt
    copy_prompt = WorkspaceUI.copy_prompt
    _build_gallery_page = GalleryUI._build_gallery_page
    _gallery_mouse_wheel = GalleryUI._gallery_mouse_wheel
    _bind_gallery_wheel_children = GalleryUI._bind_gallery_wheel_children
    _gallery_query_changed = GalleryUI._gallery_query_changed
    _on_gallery_canvas_configure = GalleryUI._on_gallery_canvas_configure
    _gallery_resize_done = GalleryUI._gallery_resize_done
    _change_gallery_page = GalleryUI._change_gallery_page
    _gallery_display_items = GalleryUI._gallery_display_items
    _gallery_status_text = staticmethod(GalleryUI._gallery_status_text)
    _gallery_can_reconcile_cards = staticmethod(GalleryUI._gallery_can_reconcile_cards)
    _make_gallery_card = GalleryUI._make_gallery_card
    _update_gallery_card_image = GalleryUI._update_gallery_card_image
    _reconcile_gallery_cards = GalleryUI._reconcile_gallery_cards
    refresh_gallery = GalleryUI.refresh_gallery
    _gallery_scope = GalleryUI._gallery_scope
    _gallery_prune_selection = GalleryUI._gallery_prune_selection
    _gallery_update_batch_toolbar = GalleryUI._gallery_update_batch_toolbar
    _gallery_paint_selection = GalleryUI._gallery_paint_selection
    _gallery_repaint_selections = GalleryUI._gallery_repaint_selections
    _gallery_toggle_selection = GalleryUI._gallery_toggle_selection
    _gallery_clear_selection = GalleryUI._gallery_clear_selection
    _gallery_select_all = GalleryUI._gallery_select_all
    _gallery_batch_dialog = GalleryUI._gallery_batch_dialog
    _gallery_batch_resize = GalleryUI._gallery_batch_resize
    _gallery_batch_convert = GalleryUI._gallery_batch_convert
    _gallery_start_batch = GalleryUI._gallery_start_batch
    _gallery_batch_progress = GalleryUI._gallery_batch_progress
    _gallery_batch_finished = GalleryUI._gallery_batch_finished
    _gallery_go = GalleryUI._gallery_go
    _gallery_select = GalleryUI._gallery_select
    _toggle_gallery_review = GalleryUI._toggle_gallery_review
    _open_gallery_selected = GalleryUI._open_gallery_selected
    _goto_gallery_selected = GalleryUI._goto_gallery_selected
    _on_gallery_card = GalleryUI._on_gallery_card
    _open_external = GalleryUI._open_external
    _build_projects_page = ProjectsUI._build_projects_page
    refresh_projects_page = ProjectsUI.refresh_projects_page
    _select_project_card = ProjectsUI._select_project_card
    _render_project_detail = ProjectsUI._render_project_detail
    _select_project_from_page = ProjectsUI._select_project_from_page
    _duplicate_project = ProjectsUI._duplicate_project
    _build_extra_pages = OtherPagesUI._build_extra_pages
    _refresh_progress_page = OtherPagesUI._refresh_progress_page
    _refresh_reference_page = OtherPagesUI._refresh_reference_page
    _copy_one_reference = OtherPagesUI._copy_one_reference
    _build_template_content = OtherPagesUI._build_template_content
    _save_prompt_template = OtherPagesUI._save_prompt_template
    _refresh_template_page = OtherPagesUI._refresh_template_page
    _refresh_history_page = OtherPagesUI._refresh_history_page
    _refresh_settings_page = OtherPagesUI._refresh_settings_page
    _build_about_page = OtherPagesUI._build_about_page

    def _prepare_icons(self):
        """Load visual assets only when a visible widget needs them.

        Previously all 435 icon PNGs were decoded into Tk photos on startup,
        even when their corresponding views or states were never used.
        """
        self.ui_icons = {}
        self._missing_ui_icons = set()
        self._ui_icon_dir = Path(__file__).parent / 'assets' / 'mono'
        logo = Path(__file__).parent / 'assets' / 'veloura_logo_mono.png'
        if logo.is_file():
            try:
                with Image.open(logo) as picture:
                    self.ui_icons['logo'] = ImageTk.PhotoImage(picture.convert('RGBA'))
            except (OSError, ValueError):
                pass

    def _get_icon(self, name, variant='black'):
        if not name:
            return None
        key = f'{variant}/{name}'
        if key in self.ui_icons:
            return self.ui_icons[key]
        if key in self._missing_ui_icons:
            return None
        path = self._ui_icon_dir / variant / f'{name}.png'
        if not path.is_file():
            self._missing_ui_icons.add(key)
            return self.ui_icons.get(name)
        try:
            with Image.open(path) as picture:
                photo = ImageTk.PhotoImage(picture.convert('RGBA'))
            self.ui_icons[key] = photo
            return photo
        except (OSError, ValueError):
            self._missing_ui_icons.add(key)
            return None

    def _cached_thumbnail(self, path, size, *, icon_file=None):
        """Return (Tk photo, original dimensions), invalidated by disk changes."""
        if not hasattr(self, '_thumbnail_cache'):
            self._thumbnail_cache = ThumbnailCache(48)
        if icon_file is None:
            stat = Path(path).stat()
            signature = (stat.st_size, stat.st_mtime_ns, getattr(stat, 'st_ino', 0),
                         getattr(stat, 'st_ctime_ns', 0))
        else:
            signature = (icon_file.size, icon_file.modified_ns, icon_file.inode,
                         icon_file.change_ns, icon_file.content_digest)

        def decode():
            with Image.open(path) as picture:
                original_size = picture.size
                thumb = picture.convert('RGBA')
                thumb.thumbnail(size, Image.Resampling.LANCZOS)
                return ImageTk.PhotoImage(thumb), original_size

        return self._thumbnail_cache.get(path, size, signature, decode)

    def button(self, parent, title, command, primary=False, subtle=False, width=None,
               icon_name=None, small=False):
        bg, fg = (BLACK, WHITE) if primary else (SOFT if subtle else WHITE, INK)
        over = '#303030' if primary else HOVER
        icon = self._get_icon(icon_name, 'white' if primary else 'black')
        btn = tk.Button(parent, text=title, command=command, bg=bg, fg=fg,
                        image=icon if icon else '', compound='left',
                        activebackground=over, activeforeground=fg,
                        font=SMALL if small else MED, bd=0, relief='flat',
                        highlightthickness=1, highlightbackground=BLACK if primary else BORDER,
                        highlightcolor=BLACK, cursor='hand2',
                        padx=9 if small else 11, pady=5 if small else 7,
                        takefocus=True)
        if width:
            btn.configure(width=width)
        btn.bind('<Enter>', lambda e, b=btn: b.configure(bg=over))
        btn.bind('<Leave>', lambda e, b=btn: b.configure(bg=bg))
        return btn

    def _build_styles(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass
        style.configure('Veloura.TCombobox', foreground=INK, fieldbackground=WHITE,
                        background=WHITE, bordercolor=BORDER, arrowcolor=BLACK,
                        padding=6, relief='flat', font=F)
        style.map('Veloura.TCombobox', fieldbackground=[('readonly', WHITE)],
                  foreground=[('readonly', INK), ('disabled', MUTED)],
                  selectbackground=[('readonly', WHITE)], selectforeground=[('readonly', INK)])
        style.configure('Veloura.Treeview', background=WHITE, fieldbackground=WHITE,
                        foreground=INK, font=F, rowheight=30, borderwidth=0)
        style.map('Veloura.Treeview', background=[('selected', ACTIVE)], foreground=[('selected', INK)])
        style.configure('Veloura.Treeview.Heading', font=MED, background=SOFT,
                        foreground=INK, relief='flat', padding=(8, 8))
        style.configure('Veloura.Vertical.TScrollbar', troughcolor=WHITE, background='#C5C5C5',
                        borderwidth=0, width=11, arrowcolor=BLACK)
        style.configure('Veloura.Horizontal.TScrollbar', troughcolor=WHITE, background='#C5C5C5',
                        borderwidth=0, arrowcolor=BLACK)
        style.configure('Veloura.TCheckbutton', foreground=INK, background=WHITE, font=F)
        style.map('Veloura.TCheckbutton', background=[('active', WHITE)])
        style.configure('Veloura.TRadiobutton', foreground=INK, background=WHITE, font=F)
        style.map('Veloura.TRadiobutton', background=[('active', WHITE)])

    def _surface(self, parent):
        return tk.Frame(parent, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)

    def _section_title(self, parent, title, number=None, note=None, icon_name=None):
        row = tk.Frame(parent, bg=WHITE)
        icon = self._get_icon(icon_name)
        if icon:
            tk.Label(row, image=icon, bg=WHITE).pack(side='left', padx=(0, 7))
        self.txt(row, title, 12, INK, True).pack(side='left')
        if note:
            self.txt(row, note, 9, MUTED).pack(side='left', padx=(9, 0))
        return row

    def _field(self, parent, textvariable=None, width=None):
        entry = tk.Entry(parent, textvariable=textvariable, font=F, fg=INK,
                         bg=FIELD, relief='flat', bd=0, highlightthickness=1,
                         highlightbackground=BORDER, highlightcolor=BLACK,
                         insertbackground=INK, width=width or 20)
        return entry

    def _scroll_area(self, parent, background=BG, auto_hide=False):
        wrap = tk.Frame(parent, bg=background)
        canvas = tk.Canvas(wrap, bd=0, highlightthickness=0, bg=background)
        scroll = ttk.Scrollbar(wrap, orient='vertical', command=canvas.yview,
                               style='Veloura.Vertical.TScrollbar')
        scroll.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        canvas.configure(yscrollcommand=scroll.set)
        inner = tk.Frame(canvas, bg=background)
        win = canvas.create_window((0, 0), window=inner, anchor='nw')
        def update_scroll(e=None):
            canvas.configure(scrollregion=canvas.bbox('all'))
            if auto_hide:
                need = inner.winfo_reqheight() > canvas.winfo_height() + 2
                if need and not scroll.winfo_manager():
                    scroll.pack(side='right', fill='y', before=canvas)
                elif not need and scroll.winfo_manager():
                    scroll.pack_forget()
        inner.bind('<Configure>', update_scroll)
        def canvas_resize(e):
            canvas.itemconfigure(win, width=e.width)
            update_scroll()
        canvas.bind('<Configure>', canvas_resize)
        # Scroll only while pointer is over this scroll area, never globally.
        def wheel(e):
            delta = -int(e.delta / 120) if e.delta else 0
            canvas.yview_scroll(delta, 'units')
        for widget in (canvas, inner):
            widget.bind('<MouseWheel>', wheel)
            widget.bind('<Button-4>', lambda e: canvas.yview_scroll(-1, 'units'))
            widget.bind('<Button-5>', lambda e: canvas.yview_scroll(1, 'units'))
        return wrap, canvas, inner

    @staticmethod
    def _is_descendant(widget, parent):
        while widget is not None:
            if widget is parent:
                return True
            widget = getattr(widget, 'master', None)
        return False

    def _workspace_wheel_router(self, event):
        if self.current_page != 'workspace' or not hasattr(self, 'main_inner'):
            return None
        widget = event.widget
        if not self._is_descendant(widget, self.main_inner) and widget is not self.workspace_scroll:
            return None
        # Do not steal the prompt's own scrolling, Treeview, selectors or scrollbars.
        if isinstance(widget, (tk.Text, tk.Listbox, ttk.Treeview, ttk.Combobox,
                               ttk.Scrollbar, tk.Scrollbar)):
            return None
        if getattr(event, 'num', None) == 4:
            step = -1
        elif getattr(event, 'num', None) == 5:
            step = 1
        else:
            delta = getattr(event, 'delta', 0)
            if not delta:
                return None
            step = (-1 if delta > 0 else 1) * max(1, abs(int(delta / 120)))
        self.workspace_scroll.yview_scroll(step, 'units')
        return 'break'

    def _install_workspace_wheel_router(self):
        # Tk's "all" binding receives events from dynamically generated cards,
        # but our handler acts ONLY on Workspace descendants.
        if getattr(self, '_workspace_wheel_installed', False):
            return
        self._workspace_wheel_installed = True
        for event_name in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
            self.root.bind_all(event_name, self._workspace_wheel_router, add='+')

    def _build_layout(self):
        self.root.title(APP_TITLE)
        self.root.configure(bg=WHITE)
        self.root.minsize(1040, 690)
        # Respect persisted user geometry, already restored by the base app.
        self.reference_paths = []
        self.reference_assignments = {}
        self._chosen_reference = None
        self.reference_thumb_refs = []
        self._gallery_page_index = 0
        self._gallery_columns = 4
        self._gallery_selected = None
        self._gallery_multi_selected = {}  # RAM-only {filename.casefold(): IconFile}
        self._gallery_selection_scope = None
        self._gallery_batch_running = False
        self._gallery_resize_job = None
        self._gallery_render_key = None
        self._gallery_render_ticket = 0
        self._gallery_render_pending = False
        self._thumbnail_cache = ThumbnailCache(48)
        self.thumbnail_placeholder = tk.PhotoImage(width=1,height=1)
        self._responsive_job = None
        self._template_loading = False
        self.template_enabled = tk.BooleanVar(value=False)

        shell = tk.Frame(self.root, bg=WHITE)
        shell.pack(fill='both', expand=True)
        shell.grid_columnconfigure(1, weight=1)
        shell.grid_rowconfigure(0, weight=1)
        self.drawer = tk.Frame(shell, bg=WHITE, width=196, highlightbackground=BORDER, highlightthickness=1)
        self.drawer.grid(row=0, column=0, sticky='ns')
        self.drawer.pack_propagate(False)
        self._build_navigation_drawer()
        self.content_host = tk.Frame(shell, bg=BG)
        self.content_host.grid(row=0, column=1, sticky='nsew')
        self.workspace_page = tk.Frame(self.content_host, bg=BG)
        self.gallery_page = tk.Frame(self.content_host, bg=BG)
        self.projects_page = tk.Frame(self.content_host, bg=BG)
        self.extra_pages = {}
        for page in (self.workspace_page, self.gallery_page, self.projects_page):
            page.place(relx=0, rely=0, relwidth=1, relheight=1)
        self._build_workspace_shell(self.workspace_page)
        self._build_gallery_page(self.gallery_page)
        self._build_projects_page(self.projects_page)
        self._build_extra_pages()
        self._template_loading = True
        self._set_template_text(str(self.project_store.active.get('prompt_template') or ''))
        self.template_enabled.set(bool(self.project_store.active.get('template_enabled', False)))
        self._template_loading = False
        self.root.bind('<Control-o>', lambda e: self.choose_picture())
        self.root.bind('<Control-e>', lambda e: self.open_source())
        self.root.bind('<Control-Shift-V>', lambda e: self.paste_source_path())
        self.root.bind('<Control-v>', self.paste_image_from_clipboard)
        self.root.bind('<Control-Return>', lambda e: self.select_next())
        self.root.bind('<Control-s>', lambda e: self.choose_picture())
        self.root.bind('<Control-Shift-C>', lambda e: self.copy_prompt())
        self.root.bind('<Control-Shift-I>', lambda e: self.copy_reference())
        self.root.bind('<F5>', lambda e: self.refresh_from_disk())
        self._restore_reference()  # Show the active project's references on first paint.
        self.show_page('workspace')

    def _build_navigation_drawer(self):
        self.nav_project_name = self.txt(self.drawer, self.project_store.active['name'][:22], 9, MUTED,
                                         bg=WHITE, justify='center', wraplength=160)
        self.nav_project_name.pack(side='bottom', pady=(0, 10))
        wrap, _, nav_host = self._scroll_area(self.drawer, WHITE, auto_hide=True)
        wrap.pack(fill='both', expand=True)
        brand = tk.Frame(nav_host, bg=WHITE)
        brand.pack(fill='x', padx=16, pady=(16, 16))
        logo = self.ui_icons.get('logo')
        if logo:
            tk.Label(brand, image=logo, bg=WHITE).pack(side='left', padx=(0, 8))
        names = tk.Frame(brand, bg=WHITE)
        names.pack(side='left')
        self.txt(names, 'Veloura', 17, INK, True).pack(anchor='w')
        self.txt(names, 'Resource Manager', 9, MUTED).pack(anchor='w')
        self.nav_buttons = {}
        navs = [
            ('projects', 'Dự án', 'nav_projects'),
            ('workspace', 'Làm việc', 'nav_workspace'),
            ('gallery', 'Thư viện ảnh', 'nav_gallery'),
            ('progress', 'Tiến độ', 'nav_progress'),
            ('references', 'Ảnh mẫu', 'nav_references'),
            ('prompt_templates', 'Mẫu Prompt', 'nav_prompt_templates'),
        ]
        for page, title, ico in navs:
            btn = self._create_nav_button(nav_host, title, self._get_icon(ico), lambda p=page: self.show_page(p))
            btn.pack(fill='x', padx=10, pady=2)
            self.nav_buttons[page] = btn
        tk.Frame(nav_host, bg=BORDER, height=1).pack(fill='x', padx=16, pady=(12, 8))
        for page, title, ico in [('history', 'Lịch sử', 'nav_history'),
                                 ('settings', 'Cài đặt', 'nav_settings'),
                                 ('about', 'Giới thiệu', 'nav_about')]:
            btn = self._create_nav_button(nav_host, title, self._get_icon(ico), lambda p=page: self.show_page(p))
            btn.pack(fill='x', padx=10, pady=2)
            self.nav_buttons[page] = btn

    def _create_nav_button(self, parent, title, icon, command):
        btn = tk.Button(parent, image=icon if icon else '', text='   ' + title, compound='left',
                        command=command, anchor='w', bg=WHITE, fg=INK,
                        activebackground=HOVER, activeforeground=INK, font=MED,
                        bd=0, relief='flat', highlightthickness=0, padx=12, pady=9,
                        cursor='hand2')
        btn.bind('<Enter>', lambda e, b=btn: b.configure(bg=ACTIVE if b is self.nav_buttons.get(self.current_page) else HOVER))
        btn.bind('<Leave>', lambda e: self._set_nav_button_state(btn,
                  next((key for key, value in self.nav_buttons.items() if value is btn), '')))
        return btn

    def _set_nav_button_state(self, button, page_name):
        button.configure(bg=ACTIVE if self.current_page == page_name else WHITE)

    def show_page(self, page_name):
        pages = {'workspace': self.workspace_page, 'gallery': self.gallery_page,
                 'projects': self.projects_page, **self.extra_pages}
        self.current_page = page_name if page_name in pages else 'workspace'
        pages[self.current_page].lift()
        if self.current_page != 'gallery' and getattr(self, '_gallery_render_pending', False):
            self._gallery_render_ticket += 1
            self._gallery_render_pending = False
            # An unfinished incremental pass must restart on next Gallery visit.
            self._gallery_render_key = None
        for name, btn in self.nav_buttons.items():
            self._set_nav_button_state(btn, name)
        if page_name == 'gallery':
            self.refresh_gallery()
        elif page_name == 'projects':
            self.refresh_projects_page()
        elif page_name == 'references':
            self._refresh_reference_page()
        elif page_name == 'progress':
            self._refresh_progress_page()
        elif page_name == 'history':
            self._refresh_history_page()
        elif page_name == 'settings':
            self._refresh_settings_page()
        elif page_name == 'prompt_templates':
            self._refresh_template_page()

    def _project_bar(self, parent):
        bar = self._surface(parent)
        bar.pack(fill='x', pady=(0, 10))
        self.txt(bar, 'Dự án hiện tại', 10, INK, True).pack(side='left', padx=(12, 10), pady=10)
        self.project_choice = ttk.Combobox(bar, textvariable=self.project_choice_var,
                            values=[p['name'] for p in self.project_store.projects],
                            state='readonly', width=22, style='Veloura.TCombobox', font=F)
        self.project_choice.pack(side='left', fill='x', expand=True)
        self.project_choice.bind('<<ComboboxSelected>>', self._on_project_selected)
        self.button(bar, 'Mở thư mục', self.open_destination, icon_name='project_open_folder', small=True).pack(side='right', padx=9)
        self.button(bar, 'Sửa', lambda: self.edit_project(), icon_name='project_edit', small=True).pack(side='right')
        self.button(bar, 'Dự án mới', self.new_project, primary=True, icon_name='project_create', small=True).pack(side='right', padx=(8, 0))
        return bar

    def _build_workspace_shell(self, parent):
        self._project_bar(parent)
        workspace = tk.Frame(parent, bg=BG)
        workspace.pack(fill='both', expand=True)
        workspace.grid_columnconfigure(1, weight=1)
        workspace.grid_rowconfigure(0, weight=1)
        self.left = self._surface(workspace)
        self.left.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        self.left.configure(width=272)
        self.left.pack_propagate(False)
        self._build_sidebar()
        self.right_frame = tk.Frame(workspace, bg=BG)
        self.right_frame.grid(row=0, column=1, sticky='nsew')
        self._build_main_panel()
        self.right_frame.bind('<Configure>', self._responsive_workspace)

