"""Small cross-process file lock used by both Windows GUI and local MCP.

Lock files live outside the user's image folders, in the Veloura config area.
The lock is advisory and coordinates Veloura processes (not arbitrary editors).
"""
from __future__ import annotations

import os
import threading
import time
from contextlib import contextmanager
from pathlib import Path

_local = threading.RLock()


@contextmanager
def file_lock(path: str | Path, timeout: float = 15.0):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with _local:
        with target.open('a+b') as handle:
            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b'\0')
                handle.flush()
            until = time.monotonic() + timeout
            while True:
                try:
                    if os.name == 'nt':
                        import msvcrt
                        handle.seek(0)
                        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except (OSError, BlockingIOError) as exc:
                    if time.monotonic() >= until:
                        raise TimeoutError('Đang có thao tác Veloura khác sử dụng dữ liệu này') from exc
                    time.sleep(0.05)
            try:
                yield
            finally:
                if os.name == 'nt':
                    import msvcrt
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
