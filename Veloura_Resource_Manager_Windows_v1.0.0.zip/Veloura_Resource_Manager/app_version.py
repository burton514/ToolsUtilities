"""Single release version shared by the desktop GUI and local MCP server."""

APP_NAME = "Veloura Resource Manager"
APP_VERSION = "1.0.0"
APP_TITLE = f"{APP_NAME} v{APP_VERSION}"
MCP_SERVER_NAME = "veloura-resource-manager"
