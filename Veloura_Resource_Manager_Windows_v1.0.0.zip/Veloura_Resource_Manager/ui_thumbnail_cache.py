"""Bounded, metadata-aware in-memory thumbnail cache.

Only UI thread code creates Tk photos. The cache never copies image files into
application storage and never caches anything across application launches.
"""
from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Callable, Any


class ThumbnailCache:
    def __init__(self, max_entries: int = 96):
        self.max_entries = max(1, int(max_entries))
        self._entries: OrderedDict[tuple, Any] = OrderedDict()
        self.hits = 0
        self.misses = 0

    def get(self, path: str | Path, dimensions: tuple[int, int],
            fingerprint: tuple, factory: Callable[[], Any]):
        """Return cached thumbnail, rebuilding it when the source file changes."""
        key = (str(path), tuple(dimensions), tuple(fingerprint))
        if key in self._entries:
            self.hits += 1
            self._entries.move_to_end(key)
            return self._entries[key]
        value = factory()  # May raise; failures must NOT poison the cache.
        self.misses += 1
        # Do not retain multiple decoded copies of an overwritten PNG.
        file_key, dimensions_key = key[:2]
        for stale in list(self._entries):
            if stale[0] == file_key and stale[1] == dimensions_key:
                del self._entries[stale]
        self._entries[key] = value
        self._entries.move_to_end(key)
        if len(self._entries) > self.max_entries:
            self._entries.popitem(last=False)
        return value

    def invalidate_file(self, path: str | Path):
        """Release every thumbnail for a changed/deleted/renamed file."""
        import os
        target = os.path.normcase(os.path.abspath(os.fspath(path)))
        for key in list(self._entries):
            if os.path.normcase(os.path.abspath(key[0])) == target:
                del self._entries[key]

    def clear(self):
        self._entries.clear()

    def __len__(self):
        return len(self._entries)
