"""GUI-independent Veloura business API shared with the local MCP agent.

Never import Tkinter here. Project metadata stays in projects.json; PNGs remain
in the configured project folders. Every write names an explicit project ID.
"""
from __future__ import annotations

import os
import io
import base64
from pathlib import Path

from PIL import Image

from folder_live import scan_png_folder
from imageflow_core import (DEFAULTS, ExportOptions, export_png,
                            get_column_options, load_name_source, load_settings,
                            normalized_name, normalize_source_path,
                            read_names_with_prompts, validate_name, SUPPORTED_EXTENSIONS,
                            assemble_prompt, OUTPUT_FORMATS)
from project_store import ProjectStore, REGISTRY_PATH
from reference_library import enabled_references, unique_paths, set_reference_selection


class CoreService:
    def __init__(self, registry_path: str | Path | None = None):
        self.registry_path = Path(registry_path) if registry_path is not None else REGISTRY_PATH
        self._selected_project_id: str | None = None

    def _store(self) -> ProjectStore:
        # The store is freshly read for each operation: never use a stale Agent
        # snapshot when a GUI may have edited projects in the meantime.
        return ProjectStore(load_settings(), self.registry_path)

    def _project(self, store: ProjectStore, project_id: str | None = None) -> dict:
        # Read-only tools may omit an ID and use the Agent's current selection.
        # An *explicit* empty/blank ID is never treated as "use default".
        if project_id is not None and (not isinstance(project_id, str) or not project_id.strip()):
            raise ValueError('project_id phải là ID project không rỗng')
        identifier = project_id if project_id is not None else (self._selected_project_id or store.active_id)
        try:
            return store.get(identifier)
        except KeyError as exc:
            raise ValueError('Không tìm thấy project; hãy chọn lại project_id') from exc

    def _write_project(self, store: ProjectStore, project_id: str) -> dict:
        """Never silently redirect mutating actions to the GUI's active project."""
        if not isinstance(project_id, str) or not project_id.strip():
            raise ValueError('Thao tác ghi cần project_id hợp lệ, không được để trống')
        return self._project(store, project_id)

    @staticmethod
    def _summary(project: dict) -> dict:
        return {
            'id': project['id'], 'name': project['name'],
            'description': project.get('description', ''),
            'source_file': project.get('last_source', ''),
            'output_folder': project['destination'],
            'output_format': project.get('output_format', 'png'),
        }

    def list_projects(self) -> dict:
        store = self._store()
        return {'projects': [self._summary(p) for p in store.projects],
                'agent_selected_project_id': self._selected_project_id or store.active_id,
                'gui_default_project_id': store.active_id}

    def select_project(self, project_id: str) -> dict:
        store = self._store()
        project = self._project(store, project_id)
        self._selected_project_id = project['id']
        return {'project': self._summary(project), 'note': 'Đã chọn cho Agent; không chuyển project trong GUI'}

    def get_project(self, project_id: str | None = None) -> dict:
        store = self._store()
        project = self._project(store, project_id)
        return {'project': self._summary(project), 'name_column': project.get('last_column', 0),
                'prompt_column': project.get('last_prompt_column', 0),
                'sheet': project.get('last_sheet', ''), 'has_header': bool(project.get('has_header', True)),
                'output_format': project.get('output_format', 'png'),
                'resize': {'enabled': bool(project.get('resize_enabled', False)),
                           'width': int(project.get('resize_width', 1024)),
                           'height': int(project.get('resize_height', 1024)),
                           'mode': project.get('resize_mode', 'contain')},
                'reference_count': len(project.get('reference_paths', []))}

    def _check_project_fields(self, source_file: str, output_folder: str):
        if not source_file or not Path(normalize_source_path(source_file)).is_file():
            raise ValueError('Hãy chọn file Excel/CSV có thật trên máy')
        source_file = str(Path(normalize_source_path(source_file)).expanduser().resolve())
        if Path(source_file).suffix.lower() not in ('.xlsx', '.xlsm', '.csv'):
            raise ValueError('File dữ liệu phải là CSV hoặc XLSX/XLSM')
        if not output_folder or not Path(output_folder).expanduser().is_dir():
            raise ValueError('Thư mục lưu PNG phải tồn tại')
        return source_file, str(Path(output_folder).expanduser().resolve())

    def _suggest_source_columns(self, source_file: str) -> dict:
        """Apply GUI-style column inference once when Agent chooses a new file.

        A deliberate prompt_column=0 set later remains respected by _names().
        """
        book = load_name_source(source_file)
        try:
            sheet_name = book.sheetnames[0]
            options = get_column_options(book[sheet_name], True)
            name_col, prompt_col = self._infer_columns(options)
            return {'last_sheet': sheet_name, 'last_column': name_col,
                    'last_prompt_column': prompt_col, 'has_header': True}
        finally:
            book.close()

    def create_project(self, name: str, source_file: str, output_folder: str, description: str = '') -> dict:
        src, dest = self._check_project_fields(source_file, output_folder)
        suggested = self._suggest_source_columns(src)
        store = self._store()
        project = store.add(name, dest, description, src, source_defaults=suggested)
        return {'created': self._summary(project),
                'source_columns': {'sheet': suggested['last_sheet'],
                                   'name_column': suggested['last_column'],
                                   'prompt_column': suggested['last_prompt_column']}}

    def update_project(self, project_id: str, name: str | None = None,
                       description: str | None = None, source_file: str | None = None,
                       output_folder: str | None = None,
                       output_format: str | None = None) -> dict:
        if output_format is not None and output_format not in OUTPUT_FORMATS:
            raise ValueError('Định dạng xuất phải là png, jpg, webp, bmp hoặc tiff')
        store = self._store()
        project = self._write_project(store, project_id)
        source, dest = self._check_project_fields(source_file if source_file is not None else project.get('last_source', ''),
                                                  output_folder if output_folder is not None else project['destination'])
        suggested = (self._suggest_source_columns(source) if source != project.get('last_source', '') else None)
        store.edit(project_id, name if name is not None else project['name'], dest, description, source,
                   source_defaults=suggested)
        if output_format is not None:
            store.get(project_id)['output_format'] = output_format
            store.save()
        return {'updated': self._summary(store.get(project_id))}

    def delete_project(self, project_id: str, confirm: bool = False) -> dict:
        if not confirm:
            raise ValueError('Phải đặt confirm=true. Chỉ xóa cấu hình, không xóa file PNG hoặc Excel/CSV.')
        store = self._store()
        project = self._write_project(store, project_id)
        summary = self._summary(project)
        store.remove(project_id)
        if self._selected_project_id == project_id:
            self._selected_project_id = None
        return {'removed': summary, 'physical_files_deleted': False}

    @staticmethod
    def _infer_columns(options):
        labels = [(int(idx), str(label).casefold()) for idx, label in options]
        names = ('tên image gen', 'ten image gen', 'image gen name', 'tên icon', 'tên ảnh', 'ten icon', 'ten anh', 'tên file', 'filename', 'file name', 'icon name', 'image name')
        prompts = ('prompt', 'promt', 'câu lệnh', 'cau lenh')
        name = next((idx for idx, label in labels if any(word in label for word in names)), 1)
        prompt = next((idx for idx, label in labels if any(word in label for word in prompts)), 0)
        return name, prompt

    def get_source_columns(self, project_id: str | None = None) -> dict:
        store = self._store()
        p = self._project(store, project_id)
        book, sheet, sheet_name = self._open_source(p)
        try:
            opts = get_column_options(sheet, bool(p.get('has_header', True)))
            auto = self._infer_columns(opts)
            return {'sheet': sheet_name, 'sheets': list(book.sheetnames),
                    'columns': [{'index': idx, 'label': label} for idx, label in opts],
                    'configured_name_column': int(p.get('last_column', 0) or 0),
                    'configured_prompt_column': int(p.get('last_prompt_column', 0) or 0),
                    'suggested_name_column': auto[0], 'suggested_prompt_column': auto[1]}
        finally:
            book.close()

    def set_source_columns(self, project_id: str, name_column: int,
                           prompt_column: int = 0, sheet: str | None = None,
                           has_header: bool | None = None) -> dict:
        store = self._store()
        p = self._write_project(store, project_id)
        if not 1 <= int(name_column) <= 150 or not 0 <= int(prompt_column) <= 150:
            raise ValueError('Cột tên từ 1 đến 150, cột Prompt từ 0 đến 150')
        book = load_name_source(p['last_source'])
        try:
            chosen = sheet if sheet is not None else (p.get('last_sheet') or book.sheetnames[0])
            if chosen not in book.sheetnames:
                raise ValueError('Sheet không tồn tại')
            available = len(get_column_options(book[chosen], bool(p.get('has_header', True) if has_header is None else has_header)))
            if int(name_column) > available or int(prompt_column) > available:
                raise ValueError('Cột không tồn tại trong file nguồn')
        finally:
            book.close()
        p.update({'last_sheet': chosen, 'last_column': int(name_column),
                  'last_prompt_column': int(prompt_column)})
        if has_header is not None:
            p['has_header'] = has_header
        store.save()
        return {'project_id': project_id, 'sheet': chosen, 'name_column': name_column, 'prompt_column': prompt_column}

    @staticmethod
    def _open_source(project: dict):
        source = project.get('last_source', '')
        if not source or not Path(normalize_source_path(source)).is_file():
            raise FileNotFoundError('Chưa có Excel/CSV hợp lệ cho project')
        book = load_name_source(source)
        desired = project.get('last_sheet') or book.sheetnames[0]
        name = desired if desired in book.sheetnames else book.sheetnames[0]
        return book, book[name], name

    def _names(self, project: dict):
        book, sheet, _ = self._open_source(project)
        try:
            opts = get_column_options(sheet, bool(project.get('has_header', True)))
            name_idx, prompt_idx = self._infer_columns(opts)
            configured = int(project.get('last_column', 0) or 0)
            name_idx = configured if 1 <= configured <= len(opts) else name_idx
            configured_prompt = int(project.get('last_prompt_column', 0) or 0)
            # 0 is an intentional 'Không chọn' selection, not a signal to
            # infer a Prompt column automatically.
            prompt_idx = configured_prompt if 0 <= configured_prompt <= len(opts) else 0
            return read_names_with_prompts(sheet, name_idx, prompt_idx, bool(project.get('has_header', True)))
        finally:
            book.close()

    def _inventory(self, project: dict, prune_marks: bool = True):
        items, duplicates = self._names(project)
        folder = scan_png_folder(project['destination'])
        if folder.error or not folder.available:
            raise OSError('Thư mục PNG không truy cập được; giữ nguyên các dấu Cần xem xét.'
                          + (' ' + folder.error if folder.error else ''))
        marks = {str(n).casefold() for n in project.get('review_marks', [])}
        records = []
        for item in items:
            preferred = project.get('output_format', 'png')
            valid = folder.for_icon(item.name, preferred)
            invalid = folder.invalid_for_icon(item.name, preferred)
            status = ('invalid_name' if item.state == 'invalid' else
                      'needs_review' if valid is not None and item.name.casefold() in marks else
                      'existing' if valid is not None else
                      'corrupt' if invalid is not None else 'missing')
            records.append({'name': item.name, 'row': item.excel_row, 'status': status,
                            'prompt': item.prompt, 'file_path': str(valid.path) if valid else None,
                            'error': item.detail})
        # When GUI is closed, Agent reads still reconcile manual review flags
        # after external PNG deletion. Do not re-mark a file re-added later.
        stale = marks - {row['name'].casefold() for row in records
                         if row['status'] in ('existing','needs_review')}
        if stale and prune_marks:
            store = self._store()
            latest = store.get(project['id'])
            original = latest.get('review_marks', [])
            latest['review_marks'] = [name for name in original if str(name).casefold() not in stale]
            if latest['review_marks'] != original:
                store.save()
        return records, duplicates

    def list_icons(self, project_id: str | None = None, status: str = 'all',
                   query: str = '', offset: int = 0, limit: int = 100, include_prompt: bool = False) -> dict:
        if status not in ('all','existing','missing','needs_review','corrupt','invalid_name'):
            raise ValueError('Bộ lọc trạng thái không hợp lệ')
        if offset < 0 or not 1 <= limit <= 500:
            raise ValueError('offset ≥ 0 và limit từ 1 đến 500')
        project = self._project(self._store(), project_id)
        rows, duplicates = self._inventory(project)
        filtered = [r for r in rows if (status == 'all' or r['status'] == status)
                    and query.casefold() in r['name'].casefold()]
        data = [dict(r) if include_prompt else {k: v for k,v in r.items() if k != 'prompt'} for r in filtered[offset:offset+limit]]
        return {'project_id': project['id'], 'total': len(filtered), 'offset': offset, 'limit': limit,
                'duplicates_ignored': duplicates, 'icons': data}

    def get_icon(self, name: str, project_id: str | None = None) -> dict:
        project = self._project(self._store(), project_id)
        records, _ = self._inventory(project)
        matching = next((r for r in records if r['name'].casefold() == normalized_name(name).casefold()), None)
        if matching is None:
            raise ValueError('Tên Image Gen không nằm trong Excel/CSV của project')
        if matching['file_path']:
            with Image.open(matching['file_path']) as img:
                matching['dimensions'] = [img.width, img.height]
        matching['effective_prompt'] = assemble_prompt(
            matching['prompt'], matching['name'], project.get('prompt_template',''),
            bool(project.get('template_enabled',False)))
        matching['references'] = self._references(project, matching['name'])
        matching['project_id'] = project['id']
        return matching

    def _references(self, project: dict, icon_name: str | None = None):
        paths = unique_paths(project.get('reference_paths', []))
        mapping = project.get('reference_assignments') or {}
        enabled = enabled_references(paths, mapping, icon_name) if icon_name else paths
        return [{'path': p, 'name': Path(p).name, 'exists': Path(p).is_file(),
                 'selected': p in enabled} for p in paths]

    def list_references(self, project_id: str | None = None, icon_name: str | None = None) -> dict:
        project = self._project(self._store(), project_id)
        return {'project_id': project['id'], 'icon': icon_name, 'references': self._references(project, icon_name)}

    def add_reference(self, project_id: str, image_path: str) -> dict:
        store = self._store(); p = self._write_project(store, project_id)
        image = Path(image_path).expanduser().resolve()
        if not image.is_file() or image.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise ValueError('Ảnh mẫu phải là một file ảnh hỗ trợ đang tồn tại')
        with Image.open(image) as img:
            img.verify()
        p['reference_paths'] = unique_paths(p.get('reference_paths', []) + [str(image)])
        store.save()
        return self.list_references(project_id)

    def assign_reference(self, project_id: str, icon_name: str,
                         image_path: str, selected: bool) -> dict:
        store = self._store(); p = self._write_project(store, project_id)
        rows, _ = self._inventory(p)
        match = next((r for r in rows if r['name'].casefold() == icon_name.casefold()), None)
        if match is None:
            raise ValueError('Tên Image Gen không nằm trong Excel/CSV')
        paths = unique_paths(p.get('reference_paths', []))
        if image_path not in paths:
            raise ValueError('Ảnh chưa được thêm vào thư viện ảnh mẫu của project')
        p['reference_assignments'] = set_reference_selection(paths, p.get('reference_assignments') or {},
                                                              match['name'], image_path, selected)
        store.save()
        return self.list_references(project_id, match['name'])

    def scan_project(self, project_id: str | None = None) -> dict:
        p = self._project(self._store(), project_id)
        rows, dup = self._inventory(p)
        counts = {name: sum(r['status'] == name for r in rows)
                  for name in ('existing','missing','needs_review','corrupt','invalid_name')}
        return {'project_id': p['id'], 'total': len(rows), 'duplicates_ignored': dup,
                'counts': counts, 'available_png': counts['existing'] + counts['needs_review'],
                'output_folder': p['destination']}

    def set_review(self, project_id: str, icon_name: str, enabled: bool) -> dict:
        store = self._store(); p = self._write_project(store, project_id)
        rows, _ = self._inventory(p, prune_marks=False)
        record = next((r for r in rows if r['name'].casefold() == icon_name.casefold()), None)
        if record is None:
            raise ValueError('Tên Image Gen không nằm trong Excel/CSV')
        if enabled and record['status'] not in ('existing','needs_review'):
            raise ValueError('Chỉ ảnh PNG hợp lệ mới được đánh dấu cần xem xét')
        marks = {str(n) for n in p.get('review_marks', [])}
        marks = {n for n in marks if n.casefold() != record['name'].casefold()}
        if enabled:
            marks.add(record['name'])
        p['review_marks'] = sorted(marks, key=str.casefold)
        store.save()
        return {'project_id': p['id'], 'name': record['name'], 'needs_review': enabled}

    def import_image(self, project_id: str, icon_name: str, image_path: str,
                     overwrite: bool = False, move: bool = False,
                     resize: bool | None = None, width: int | None = None,
                     height: int | None = None, mode: str | None = None,
                     output_format: str | None = None) -> dict:
        store = self._store(); p = self._write_project(store, project_id)
        rows, _ = self._inventory(p)
        record = next((r for r in rows if r['name'].casefold() == normalized_name(icon_name).casefold()), None)
        if record is None or record['status'] == 'invalid_name':
            raise ValueError('Image Gen không tồn tại hoặc tên không hợp lệ trong Excel/CSV')
        fmt = p.get('output_format', 'png') if output_format is None else output_format
        if fmt not in OUTPUT_FORMATS:
            raise ValueError('Định dạng xuất phải là png, jpg, webp, bmp hoặc tiff')
        target = Path(p['destination']) / (record['name'] + OUTPUT_FORMATS[fmt][0])
        if target.exists() and not overwrite:
            raise FileExistsError('Ảnh cùng định dạng đã tồn tại; chỉ ghi đè khi overwrite=true')
        source = Path(image_path).expanduser().resolve()
        if not source.is_file() or source.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise ValueError('Nguồn phải là file ảnh hỗ trợ đang tồn tại')
        do_resize = bool(p.get('resize_enabled', False)) if resize is None else resize
        w = int(width if width is not None else p.get('resize_width', 1024))
        h = int(height if height is not None else p.get('resize_height', 1024))
        resize_mode = mode if mode is not None else str(p.get('resize_mode', 'contain'))
        options = ExportOptions(Path(p['destination']), 'move' if move else 'copy', do_resize,
                                w, h, resize_mode, overwrite, fmt)
        result = export_png(source, record['name'], options)
        return {'project_id': p['id'], 'name': record['name'],
                'output_path': str(result.destination), 'width': result.width,
                'height': result.height, 'moved_source': result.moved,
                'bytes': result.bytes}

    def rename_png(self, project_id: str, old_name: str, new_name: str,
                   overwrite: bool = False) -> dict:
        """Rename PNG in project folder; intentionally NEVER edits Excel/CSV."""
        from imageflow_core import APP_DIR
        from storage_lock import file_lock
        import hashlib
        p = self._write_project(self._store(), project_id)
        old = normalized_name(old_name); new = normalized_name(new_name)
        for name in (old, new):
            if validate_name(name):
                raise ValueError('Tên PNG không hợp lệ: ' + name)
        folder = Path(p['destination']).expanduser().resolve()
        key = hashlib.sha256(os.path.normcase(str(folder)).encode('utf-8')).hexdigest()
        with file_lock(APP_DIR / 'locks' / (key + '.lock')):
            snapshot = scan_png_folder(folder)
            source = snapshot.for_icon(old, p.get('output_format', 'png'))
            if source is None:
                raise FileNotFoundError('Không tìm thấy ảnh gốc hợp lệ trong project')
            dest = folder / (new + source.path.suffix)
            if source.path.resolve() == dest.resolve():
                return {'changed': False, 'path': str(dest)}
            if dest.exists() and not overwrite:
                raise FileExistsError('Tên PNG mới đã tồn tại')
            if dest.exists() and not dest.is_file():
                raise IsADirectoryError('Tên mới trùng thư mục')
            if not overwrite:
                # Atomic no-replace rename on Windows; os.rename fails if the
                # target exists on Windows but replaces on POSIX. Use hardlink
                # + unlink on POSIX for atomic no-clobber semantics.
                if os.name == 'nt':
                    source.path.rename(dest)
                else:
                    os.link(source.path, dest)
                    source.path.unlink()
            else:
                os.replace(source.path, dest)
        return {'changed': True, 'source_path': str(source.path), 'output_path': str(dest),
                'spreadsheet_updated': False}

    def view_image(self, project_id: str, icon_name: str, source: str = 'output',
                   reference_path: str | None = None):
        """Read a bounded image for MCP vision (never write/copy a source file)."""
        p = self._project(self._store(), project_id)
        rows, _ = self._inventory(p)
        record = next((r for r in rows if r['name'].casefold() == normalized_name(icon_name).casefold()), None)
        if not record:
            raise ValueError('Image Gen không nằm trong Excel/CSV')
        if source == 'output':
            if not record['file_path']:
                raise FileNotFoundError('Chưa có ảnh hợp lệ cho tên này')
            file = Path(record['file_path'])
        elif source == 'reference':
            available = [entry for entry in self._references(p,record['name']) if entry['selected'] and entry['exists']]
            if not available:
                raise ValueError('Image Gen chưa có ảnh mẫu được chọn')
            if reference_path:
                path = Path(reference_path).resolve()
                entry = next((row for row in available if Path(row['path']).resolve() == path), None)
                if entry is None:
                    raise PermissionError('Ảnh không thuộc các ảnh mẫu được chọn của Image Gen')
            else:
                entry = available[0]
            file = Path(entry['path'])
        else:
            raise ValueError('source chỉ nhận output hoặc reference')
        with Image.open(file) as img:
            img.load()
            preview = img.convert('RGBA')
            preview.thumbnail((768,768), Image.Resampling.LANCZOS)
            stream = io.BytesIO()
            preview.save(stream, 'PNG', optimize=True)
            size = [img.width, img.height]
        if stream.tell() > 5_000_000:
            raise ValueError('Ảnh quá lớn để gửi qua MCP')
        return {'image_base64': base64.b64encode(stream.getvalue()).decode('ascii'),
                'mime_type': 'image/png', 'original_size': size,
                'source_path': str(file), 'name': record['name']}
