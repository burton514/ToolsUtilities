import tempfile
import unittest
from pathlib import Path
from PIL import Image
from openpyxl import Workbook

from imageflow_core import (
    ExportOptions, export_png, load_excel_sheets, read_names, get_column_options,
    normalized_name, validate_name, resized_image,
)


class ImageFlowTests(unittest.TestCase):
    def test_excel_names_and_duplicates(self):
        example = Path(__file__).resolve().parent / 'fixtures' / 'EXCEL_MAU.xlsx'
        wb = load_excel_sheets(str(example))
        self.assertEqual(wb.sheetnames, ['Tên ảnh'])
        cols = get_column_options(wb.active, True)
        self.assertIn('Tên ảnh đích', cols[1][1])
        rows, dup = read_names(wb.active, 2, True)
        self.assertEqual(dup, 1)
        self.assertEqual(len(rows), 7)
        self.assertEqual(rows[3].name, 'veloura_soft_pink_04')
        self.assertEqual(sum(i.state == 'invalid' for i in rows), 1)
        wb.close()

    def test_names_and_reserved(self):
        self.assertEqual(normalized_name(' Hello.PNG '), 'Hello')
        for bad in ['CON', 'COM1.txt', 'flower/star', '  ', 'bad.', 'a|b']:
            self.assertIsNotNone(validate_name(bad.strip()))
        self.assertIsNone(validate_name('Lá tím 23'))

    def test_png_copy_no_resize_is_byte_exact(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / 'source.png'
            with Image.new('RGBA', (25, 41), (13, 22, 33, 77)) as im:
                im.save(src)
            result = export_png(src, 'Tên ảnh', ExportOptions(root / 'out'))
            self.assertTrue(src.exists())
            self.assertTrue(result.destination.exists())
            self.assertEqual(src.read_bytes(), result.destination.read_bytes())
            self.assertEqual((result.width, result.height), (25, 41))

    def test_move_resize_produces_alpha_and_removes_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / 'original.jpg'
            with Image.new('RGB', (240, 120), (155, 33, 50)) as im:
                im.save(src)
            opts = ExportOptions(root / 'result', 'move', True, 100, 100, 'contain')
            result = export_png(src, 'new_name', opts)
            self.assertFalse(src.exists())
            self.assertTrue(result.moved)
            with Image.open(result.destination) as im:
                self.assertEqual(im.size, (100, 100))
                self.assertEqual(im.mode, 'RGBA')
                self.assertEqual(im.getpixel((0, 0))[3], 0)
                self.assertEqual(im.getpixel((50, 50))[3], 255)

    def test_cover_and_stretch(self):
        img = Image.new('RGB', (150, 70), 'yellow')
        for mode in ('cover', 'stretch'):
            out = resized_image(img, 66, 91, mode)
            self.assertEqual(out.size, (66, 91))
            out.close()

    def test_no_overwrite_by_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with Image.new('RGB', (18, 18), 'blue') as im:
                im.save(root / 'a.jpg')
            opts = ExportOptions(root / 'out')
            export_png(root / 'a.jpg', 'result', opts)
            with self.assertRaises(FileExistsError):
                export_png(root / 'a.jpg', 'result', opts)
            self.assertTrue((root / 'a.jpg').exists())

    def test_failure_does_not_delete_move_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / 'broken.jpg'
            src.write_text('not-image')
            with self.assertRaises(Exception):
                export_png(src, 'result', ExportOptions(root / 'out', operation='move'))
            self.assertTrue(src.exists())

    def test_numeric_leading_zeros(self):
        wb = Workbook()
        sheet = wb.active
        sheet['A1'] = 'ID'
        sheet['A2'] = 7
        sheet['A2'].number_format = '00000'
        items, _ = read_names(sheet, 1, True)
        self.assertEqual(items[0].name, '00007')


if __name__ == '__main__':
    unittest.main()
