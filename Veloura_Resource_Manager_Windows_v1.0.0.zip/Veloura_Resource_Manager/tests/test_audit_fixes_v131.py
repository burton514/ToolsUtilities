"""Regressions for issues found in the independent v1.3.0 refactor audit.

Tests use a temporary project registry, never the user's actual project files.
"""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import tkinter as tk
from tkinter import ttk

import pytest
from openpyxl import Workbook

from app import ImageManager
from core_service import CoreService
from imageflow_core import load_name_source
from mcp_stdio import MCPServer
from veloura.controllers.source import SourceController


def _clipboard_manager(widget):
    manager = object.__new__(ImageManager)
    manager.root = SimpleNamespace(focus_get=lambda: widget)
    manager.processing = False
    manager.selected_index = None
    return manager


@pytest.mark.parametrize('widget_type', [tk.Entry, ttk.Entry, ttk.Combobox])
def test_ctrl_v_preserves_native_text_paste(widget_type):
    # Widget type checks do not require a Tk display or a running window.
    widget = object.__new__(widget_type)
    manager = _clipboard_manager(widget)
    with patch('app.messagebox.showinfo') as notice, patch('app.ImageGrab') as grab:
        result = manager.paste_image_from_clipboard(event=object())
    assert result is None
    notice.assert_not_called()
    assert not grab.grabclipboard.called


def test_ctrl_v_on_image_area_uses_existing_image_paste_path():
    manager = _clipboard_manager(object.__new__(tk.Canvas))
    with patch('app.messagebox.showinfo') as notice:
        result = manager.paste_image_from_clipboard(event=object())
    assert result is None
    notice.assert_called_once()
    assert 'Chưa chọn' in notice.call_args.args[0]


def test_ctrl_v_without_key_event_keeps_button_behavior():
    manager = _clipboard_manager(object.__new__(tk.Entry))
    with patch('app.messagebox.showinfo') as notice:
        manager.paste_image_from_clipboard(event=None)
    notice.assert_called_once()


@pytest.mark.parametrize('header', ['Tên Image Gen', 'TÊN IMAGE GEN', 'Image Gen Name'])
def test_agent_detects_image_gen_name_column_on_new_csv_project(tmp_path, header):
    csv = tmp_path / 'names.csv'
    csv.write_text(f'STT,{header},Prompt\n1,im_first,Tạo một ảnh\n', encoding='utf-8-sig')
    out = tmp_path / 'output'; out.mkdir()
    service = CoreService(tmp_path / 'config' / 'projects.json')
    created = service.create_project('Test Image Gen', str(csv), str(out))
    pid = created['created']['id']
    assert created['source_columns']['name_column'] == 2
    assert created['source_columns']['prompt_column'] == 3
    assert service.get_source_columns(pid)['suggested_name_column'] == 2
    assert [entry['name'] for entry in service.list_icons(pid)['icons']] == ['im_first']
    assert service.get_icon('im_first', pid)['prompt'] == 'Tạo một ảnh'
    # The MCP transport exposes the same persisted project mapping.
    server = MCPServer(service)
    initialized = server.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {}})
    assert initialized['result']['capabilities']['tools']


def test_agent_detects_image_gen_name_column_in_xlsx(tmp_path):
    path = tmp_path / 'names.xlsx'
    wb = Workbook(); sheet = wb.active
    sheet.append(['STT', 'Tên Image Gen', 'Prompt'])
    sheet.append([1, 'im_xlsx', 'Xây dựng hình ảnh'])
    wb.save(path); wb.close()
    out = tmp_path / 'output'; out.mkdir()
    service = CoreService(tmp_path / 'config' / 'projects.json')
    pid = service.create_project('Test Excel', str(path), str(out))['created']['id']
    assert service.get_project(pid)['name_column'] == 2
    assert [entry['name'] for entry in service.list_icons(pid)['icons']] == ['im_xlsx']


def test_gui_inference_prioritizes_image_gen_heading_over_early_generic_image_column(tmp_path):
    source = tmp_path / 'names.csv'
    source.write_text('STT,Image Preview,Tên Image Gen,Prompt\n1,x.png,im_correct,tạo\n', encoding='utf-8-sig')
    workbook = load_name_source(str(source))
    tcl = tk.Tcl()  # headless: no UI window is created
    captured = []
    dummy = SimpleNamespace(
        workbook=workbook,
        sheet_var=tk.StringVar(master=tcl, value=workbook.sheetnames[0]),
        has_header=tk.BooleanVar(master=tcl, value=True),
        settings={},
        source_path=source,
        columns=[],
        column_combo=SimpleNamespace(configure=lambda **k: captured.append(('name', k))),
        prompt_column_combo=SimpleNamespace(configure=lambda **k: captured.append(('prompt', k))),
        column_var=tk.StringVar(master=tcl),
        prompt_column_var=tk.StringVar(master=tcl),
        load_selected_column=lambda: captured.append(('load', None)),
    )
    try:
        with patch('veloura.controllers.source.messagebox.showerror', side_effect=AssertionError('GUI inference failed')):
            SourceController.on_sheet_changed(dummy)
        assert dummy.column_var.get().endswith('Tên Image Gen')
        assert dummy.prompt_column_var.get().endswith('Prompt')
        assert captured[-1][0] == 'load'
    finally:
        workbook.close()


def test_legacy_icon_name_columns_remain_compatible():
    assert CoreService._infer_columns([(1, 'A · STT'), (2, 'B · Tên icon'), (3, 'C · Prompt')]) == (2, 3)
    assert CoreService._infer_columns([(1, 'A · STT'), (2, 'B · Tên ảnh đích'), (3, 'C · Prompt')]) == (2, 3)


def test_mcp_creates_and_reads_project_with_image_gen_column(tmp_path):
    source = tmp_path / 'generated.csv'
    source.write_text('STT,Tên Image Gen,Prompt\n1,im_from_mcp,Ảnh minh họa\n', encoding='utf-8-sig')
    out = tmp_path / 'out'; out.mkdir()
    server = MCPServer(CoreService(tmp_path / 'cfg' / 'projects.json'))
    server.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {}})
    server.handle({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
    created = server.handle({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {
        'name': 'veloura_create_project', 'arguments': {
            'name': 'Agent project', 'source_file': str(source), 'output_folder': str(out)}}})
    assert created['result']['isError'] is False
    body = created['result']['structuredContent']
    assert body['source_columns']['name_column'] == 2
    pid = body['created']['id']
    result = server.handle({'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {
        'name': 'veloura_list_icons', 'arguments': {'project_id': pid}}})
    assert result['result']['isError'] is False
    assert [item['name'] for item in result['result']['structuredContent']['icons']] == ['im_from_mcp']
