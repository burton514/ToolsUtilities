"""Regression tests for 8 audit findings in Veloura Resource Manager 2.7."""
import json
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from PIL import Image

import app as app_module
import imageflow_core
import folder_live
from app import ImageManager
from imageflow_core import DEFAULTS, ExportOptions, export_png
from folder_live import scan_png_folder
from project_store import ProjectStore


def save_png(path, width=16, height=12, color='blue'):
    Image.new('RGBA', (width, height), color).save(path)


def test_a1_corrupted_registry_kept_before_recovery(tmp_path):
    path = tmp_path/'projects.json'
    corrupt = b'{"projects": [BROKEN'
    path.write_bytes(corrupt)
    store = ProjectStore({**DEFAULTS, 'destination': str(tmp_path/'default')}, path)
    assert store.recovery_warning
    backups = list(tmp_path.glob('projects.corrupt.*.json'))
    assert len(backups) == 1 and backups[0].read_bytes() == corrupt
    assert store.active['name'] == 'Project mặc định'
    assert json.loads(path.read_text())['projects']


def test_a1_recovers_valid_backup_without_discarding_corruption(tmp_path):
    path = tmp_path/'projects.json'
    store = ProjectStore(DEFAULTS, path)
    store.add('Keep', str(tmp_path/'keep'))
    backup = path.with_suffix('.bak')
    assert backup.exists()
    previous_names = [p['name'] for p in json.loads(backup.read_text())['projects']]
    path.write_text('damaged file', encoding='utf-8')
    recovered = ProjectStore(DEFAULTS, path)
    assert recovered.recovery_warning and 'sao lưu' in recovered.recovery_warning
    assert [p['name'] for p in recovered.projects] == previous_names
    assert list(tmp_path.glob('projects.corrupt.*.json'))


def test_a1_backup_failure_does_not_overwrite_bad_file(tmp_path, monkeypatch):
    path = tmp_path/'projects.json'
    path.write_bytes(b'[BROKEN')
    def fail(*args, **kwargs):
        raise PermissionError('no backup permissions')
    monkeypatch.setattr('project_store.shutil.copy2', fail)
    with pytest.raises(PermissionError):
        ProjectStore(DEFAULTS, path)
    assert path.read_bytes() == b'[BROKEN'


def test_a2_inplace_resize_requires_overwrite(tmp_path):
    out = tmp_path/'out'; out.mkdir()
    original = out/'my_icon.png'
    save_png(original, 45, 32)
    before = original.read_bytes()
    with pytest.raises(FileExistsError):
        export_png(original, 'my_icon', ExportOptions(out, resize_enabled=True, width=12, height=12, overwrite=False))
    assert original.read_bytes() == before
    export_png(original, 'my_icon', ExportOptions(out, resize_enabled=True, width=12, height=12, overwrite=True))
    with Image.open(original) as img:
        assert img.size == (12, 12)


def test_a3_competitor_cannot_be_overwritten(tmp_path, monkeypatch):
    src = tmp_path/'source.png'; save_png(src)
    out = tmp_path/'out'; out.mkdir()
    dest = out/'target.png'
    original_link = imageflow_core.os.link
    def competitor(src_temp, destination):
        dest.write_bytes(b'COMPETITOR')
        return original_link(src_temp, destination)
    monkeypatch.setattr(imageflow_core.os, 'link', competitor)
    with pytest.raises(FileExistsError):
        export_png(src, 'target', ExportOptions(out, overwrite=False))
    assert dest.read_bytes() == b'COMPETITOR'
    assert not list(out.glob('.veloura_*'))
    assert src.exists()


def test_a3_multiple_writers_only_one_claims_destination(tmp_path):
    sources=[]
    for i in range(8):
        path=tmp_path/f'in_{i}.png'; save_png(path, 12+i, 10+i); sources.append(path)
    out=tmp_path/'out'; out.mkdir()
    def write(source):
        try:
            export_png(source, 'same', ExportOptions(out, overwrite=False))
            return True
        except FileExistsError:
            return False
    with ThreadPoolExecutor(max_workers=8) as pool:
        results=list(pool.map(write, sources))
    assert sum(results)==1
    with Image.open(out/'same.png') as im:
        im.verify()


def test_a5_clipboard_skip_cleans_temporary_file(tmp_path, monkeypatch):
    seen=[]
    def skip_processing(path, transient_source=False):
        assert transient_source
        seen.append(path)
    fake=SimpleNamespace(processing=False, selected_index=0, process_image=skip_processing)
    monkeypatch.setattr(app_module, 'ImageGrab', SimpleNamespace(grabclipboard=lambda: Image.new('RGBA',(20,20),'red')))
    monkeypatch.setattr(app_module.tempfile, 'gettempdir', lambda: str(tmp_path))
    for _ in range(3):
        ImageManager.paste_image_from_clipboard(fake)
    assert len(seen)==3
    assert not list((tmp_path/'veloura_image_manager').glob('clipboard_*.png'))


def test_a6_canonical_folder_alias_is_rejected(tmp_path):
    first=tmp_path/'icons'; first.mkdir()
    other=tmp_path/'bridge'; other.mkdir()
    store=ProjectStore(DEFAULTS, tmp_path/'projects.json')
    store.add('Alpha',str(first))
    with pytest.raises(ValueError, match='thư mục riêng'):
        store.add('Beta',str(other/'..'/'icons'))
    alias=tmp_path/'alias'; alias.symlink_to(first, target_is_directory=True)
    with pytest.raises(ValueError, match='thư mục riêng'):
        store.add('Gamma',str(alias))


def test_a6_windows_spellings_are_equivalent(tmp_path):
    store=ProjectStore(DEFAULTS, tmp_path/'projects.json')
    store.add('Alpha',r'D:\Projects\icons')
    with pytest.raises(ValueError, match='thư mục riêng'):
        store.add('Beta',r'd:/Projects/other/../icons/')


def test_a7_png_bytes_are_verified_and_rechecked_when_modified(tmp_path):
    folder=tmp_path/'output'; folder.mkdir()
    bad=folder/'broken.png'; bad.write_bytes(b'not-a-png')
    first=scan_png_folder(folder)
    assert first.for_icon('broken') is None
    assert first.files['broken.png'].valid is False
    save_png(bad, 42, 42)
    second=scan_png_folder(folder)
    assert second.for_icon('broken') is not None
    assert second.files['broken.png'].valid
    assert first.files != second.files
    bad.write_bytes(b'invalid-again')
    assert scan_png_folder(folder).for_icon('broken') is None


def test_a7_unchanged_files_are_not_decoded_each_scan(tmp_path, monkeypatch):
    folder = tmp_path / 'out'; folder.mkdir()
    file = folder / 'okay.png'; save_png(file)
    validations = []
    original = folder_live._is_valid_png

    def trace(path, size):
        validations.append(path)
        return original(path, size)

    monkeypatch.setattr(folder_live, '_is_valid_png', trace)
    first = scan_png_folder(folder)
    scan_png_folder(folder, previous=first)
    assert len(validations) == 1  # A monitored folder reuses only unchanged bytes.
    # An explicit standalone scan is always authoritative, not a cross-run cache.
    scan_png_folder(folder)
    assert len(validations) == 2


def test_a8_persistence_failure_is_reported_and_retried(monkeypatch):
    class V:
        def __init__(self, value): self.value=value
        def get(self): return self.value
    class Root:
        def __init__(self): self.calls=[]
        def after(self, ms, cb): self.calls.append((ms, cb)); return 'job'
        def after_cancel(self, id): pass
    vars={name: V(value) for name,value in dict(destination='D:/icons', operation='copy', resize_enabled=False,
           width_var='512', height_var='512', resize_mode='Giữ tỷ lệ · thêm nền trong suốt',
           conflict='Hỏi trước khi ghi đè', advance=True, has_header=True, sheet_var='', reference_path='').items()}
    fake=SimpleNamespace(**vars, _changing_project=False, save_task=None, source_path=None,
          settings={}, _save_error_reported=False, _save_retry_count=0, _closing=False,
          selected_col_index=lambda:1, selected_prompt_col_index=lambda:0,
          _status=lambda msg:None, root=Root(), project_store=SimpleNamespace(update_active=lambda settings:None))
    fake.persist_settings = lambda: ImageManager.persist_settings(fake)
    def fail(_): raise PermissionError('simulated read-only config')
    warnings=[]
    monkeypatch.setattr(app_module, 'save_settings', fail)
    monkeypatch.setattr(app_module.messagebox, 'showwarning', lambda *args, **kw: warnings.append(args))
    assert ImageManager.persist_settings(fake) is False
    assert warnings and 'không' in warnings[0][0].lower()
    assert fake.root.calls and fake.root.calls[0][0]==2500
    assert fake._save_retry_count==1


def test_a2_ui_skip_strategy_checks_even_when_source_is_destination(tmp_path):
    from imageflow_core import NameItem
    class V:
        def __init__(self, val): self.val=val
        def get(self): return self.val
    folder=tmp_path/'icons'; folder.mkdir()
    existing=folder/'icon.png'; save_png(existing)
    log=[]
    fake=SimpleNamespace(processing=False, selected_index=0,
                         items=[NameItem('icon', 1, 'existing')],
                         destination=V(str(folder)), width_var=V('24'), height_var=V('24'),
                         resize_enabled=V(True), conflict=V('Bỏ qua nếu đã có'),
                         _append_activity=log.append, _status=log.append)
    before=existing.read_bytes()
    assert ImageManager.process_image(fake, existing) is None
    assert existing.read_bytes()==before
    assert any('Bỏ qua' in msg for msg in log)


def test_a3_failed_move_does_not_delete_original(tmp_path, monkeypatch):
    src=tmp_path/'source.png'; save_png(src)
    folder=tmp_path/'out'; folder.mkdir()
    dest=folder/'icon.png'
    original_link=imageflow_core.os.link
    def another_writer(temp, target):
        dest.write_bytes(b'COMPETING FILE')
        return original_link(temp,target)
    monkeypatch.setattr(imageflow_core.os,'link',another_writer)
    with pytest.raises(FileExistsError):
        export_png(src,'icon',ExportOptions(folder,operation='move',overwrite=False))
    assert src.is_file()
    assert dest.read_bytes()==b'COMPETING FILE'


def test_a5_failed_clipboard_encoding_does_not_leave_empty_file(tmp_path, monkeypatch):
    class FailImage:
        def save(self,path,format):
            Path(path).write_bytes(b'partial')
            raise OSError('Encoding failed')
    fake=SimpleNamespace(processing=False,selected_index=0)
    monkeypatch.setattr(app_module, 'ImageGrab', SimpleNamespace(grabclipboard=lambda: FailImage()))
    monkeypatch.setattr(app_module.tempfile, 'gettempdir', lambda: str(tmp_path))
    errors=[]
    monkeypatch.setattr(app_module.messagebox,'showerror',lambda *a,**kw:errors.append(a))
    ImageManager.paste_image_from_clipboard(fake)
    assert errors
    assert not list((tmp_path/'veloura_image_manager').glob('*.png'))


def test_a6_loaded_duplicate_registries_report_warning(tmp_path):
    folder=tmp_path/'icon'; folder.mkdir()
    store=ProjectStore(DEFAULTS,tmp_path/'projects.json')
    store.add('Alpha',str(folder))
    content=json.loads(store.path.read_text())
    additional=dict(content['projects'][-1]); additional['id']='another_project_id'; additional['name']='Alias'
    additional['destination']=str(tmp_path/'other'/'..'/'icon')
    content['projects'].append(additional)
    store.path.write_text(json.dumps(content),encoding='utf-8')
    reloaded=ProjectStore(DEFAULTS,store.path)
    assert any('trỏ cùng thư mục' in s for s in reloaded.load_warnings)
    assert len(reloaded.projects)==3  # Preserve both entries for user repair.


def test_a7_webp_payload_named_png_does_not_count(tmp_path):
    folder=tmp_path/'out'; folder.mkdir()
    Image.new('RGB',(20,20),'red').save(folder/'fake.png',format='WEBP')
    snapshot=scan_png_folder(folder)
    assert snapshot.for_icon('fake') is None
    assert snapshot.files['fake.png'].valid is False


def test_a4_nested_workspace_wheel_uses_workspace_only():
    from modern_ui import MonoUI
    main=SimpleNamespace(master=None)
    card=SimpleNamespace(master=main)
    image=SimpleNamespace(master=card)
    actions=[]
    canvas=SimpleNamespace(yview_scroll=lambda units, unit_type: actions.append((units,unit_type)))
    owner=SimpleNamespace(current_page='workspace', main_inner=main, workspace_scroll=canvas,
                          _is_descendant=MonoUI._is_descendant)
    ev=SimpleNamespace(widget=image,delta=-120,num=None)
    assert MonoUI._workspace_wheel_router(owner,ev)=='break'
    assert actions==[(1,'units')]
    owner.current_page='gallery'
    assert MonoUI._workspace_wheel_router(owner,ev) is None
    assert actions==[(1,'units')]


def test_a8_recovered_persistence_clears_pending_error(monkeypatch):
    # The retry state is reset on the first successful save.
    class V:
        def __init__(self, value): self.value=value
        def get(self): return self.value
    vals={name:V(value) for name,value in dict(destination='D:/icons', operation='copy', resize_enabled=False,
             width_var='512',height_var='512',resize_mode='Giữ tỷ lệ · thêm nền trong suốt',
             conflict='Hỏi trước khi ghi đè',advance=True,has_header=True,sheet_var='',reference_path='').items()}
    fake=SimpleNamespace(**vals, _changing_project=False, save_task=None, source_path=None,
         settings={},_save_error_reported=True,_save_retry_count=2,_closing=False,
         selected_col_index=lambda:1,selected_prompt_col_index=lambda:0,
         _status=lambda msg:None, project_store=SimpleNamespace(update_active=lambda settings:None))
    monkeypatch.setattr(app_module,'save_settings',lambda settings:None)
    assert ImageManager.persist_settings(fake) is True
    assert fake._save_retry_count==0 and not fake._save_error_reported


def test_review_marks_are_persisted_in_project_store(tmp_path):
    store = ProjectStore(DEFAULTS, tmp_path/'projects.json')
    store.active['review_marks'] = ['icon_b', 'icon_a']
    store.save()
    again = ProjectStore(DEFAULTS, tmp_path/'projects.json')
    assert again.active['review_marks'] == ['icon_a', 'icon_b']


def test_review_state_requires_real_png_and_clears_when_missing(tmp_path):
    from imageflow_core import NameItem
    folder = tmp_path/'png'; folder.mkdir()
    save_png(folder/'ok.png')
    snap = scan_png_folder(folder)
    fake = SimpleNamespace(items=[NameItem('ok', 1, 'pending'), NameItem('missing', 2, 'pending')],
                           review_marks={'ok', 'missing'}, _folder_snapshot=snap, settings={},
                           project_store=SimpleNamespace(active={}), _changing_project=False,
                           persist_settings=lambda : True)
    fake._is_reviewed_name = lambda name: app_module.ImageManager._is_reviewed_name(fake, name)
    fake._store_review_marks = lambda persist=True: app_module.ImageManager._store_review_marks(fake, persist=False)
    assert app_module.ImageManager._prune_review_marks(fake, snap) is True
    changed = app_module.ImageManager._apply_png_states(fake, snap)
    assert changed == [0]
    assert fake.items[0].state == 'review'
    assert fake.items[1].state == 'pending'
    assert fake.review_marks == {'ok'}


def test_toggle_review_only_when_existing():
    from imageflow_core import NameItem
    events = []
    class Tree:
        def exists(self, iid):
            return iid == '0'
        def set(self, iid, column, value):
            events.append(('status', iid, column, value))
        def item(self, iid, **options):
            events.append(('row', iid, options))
    fake = SimpleNamespace(selected_index=0, items=[NameItem('icon', 1, 'existing')], review_marks=set(),
                           _folder_snapshot=SimpleNamespace(), current_page='workspace',
                           filter_var=SimpleNamespace(get=lambda: 'Tất cả'), tree=Tree(),
                           _update_counter=lambda: events.append('counter'),
                           draw_items=lambda: events.append('draw'),
                           _refresh_target=lambda: events.append('refresh'),
                           refresh_gallery=lambda: events.append('gallery'),
                           _status=lambda msg: events.append(msg), _gallery_selected=None)
    fake._can_mark_review = lambda item: app_module.ImageManager._can_mark_review(fake, item)
    fake._is_reviewed_name = lambda name: app_module.ImageManager._is_reviewed_name(fake, name)
    fake._store_review_marks = lambda persist=True: None
    fake._set_review_mark = lambda name, enabled, persist=True: app_module.ImageManager._set_review_mark(fake, name, enabled, persist=False)
    fake._apply_png_states = lambda snapshot, changed_names=None: app_module.ImageManager._apply_png_states(
        fake, SimpleNamespace(files={}, for_icon=lambda name, preferred="png": object(), invalid_for_icon=lambda name, preferred="png": None), changed_names)
    fake._refresh_review_rows = lambda changed_indices: app_module.ImageManager._refresh_review_rows(fake, changed_indices)
    app_module.ImageManager.toggle_review_for_selected(fake)
    assert 'icon' in fake.review_marks
    assert fake.items[0].state == 'review'
    assert ('status', '0', 'status', 'Cần xem xét') in events
    assert 'draw' not in events
    assert any('Đã đánh dấu cần xem xét' in e for e in events if isinstance(e, str))
