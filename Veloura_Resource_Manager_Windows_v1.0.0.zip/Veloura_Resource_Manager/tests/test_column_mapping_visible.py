"""Regression: source mapping must remain accessible after loading names.

Tk layout is also exercised in GUI smoke tests at 1060x700/1450x890.
These tests intentionally don't require an active display server.
"""
from modern_ui import MonoUI


class FakeSourceFrame:
    def __init__(self, visible=False):
        self.visible = visible
        self.pack_calls = []

    def winfo_manager(self):
        return 'pack' if self.visible else ''

    def pack(self, **kwargs):
        self.pack_calls.append(kwargs)
        self.visible = True


class FakeOwner:
    def __init__(self, visible):
        self.source_options_frame = FakeSourceFrame(visible)
        self.counter = object()


def test_auto_collapse_request_does_not_hide_selectors():
    owner = FakeOwner(True)
    MonoUI.toggle_source_details(owner, expanded=False)
    assert owner.source_options_frame.visible
    assert not owner.source_options_frame.pack_calls


def test_restores_selectors_when_they_were_hidden():
    owner = FakeOwner(False)
    MonoUI.toggle_source_details(owner, expanded=False)
    assert owner.source_options_frame.visible
    assert owner.source_options_frame.pack_calls[0]['before'] is owner.counter
