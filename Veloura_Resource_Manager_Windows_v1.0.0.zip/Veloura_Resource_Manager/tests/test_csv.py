import tempfile
import unittest
from pathlib import Path

from imageflow_core import (
    get_column_options,
    load_csv_names,
    load_name_source,
    read_names,
)


class CSVImportTests(unittest.TestCase):
    def _load(self, content: str, encoding="utf-8-sig"):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        filename = Path(tmp.name) / "Tên ảnh.csv"
        filename.write_text(content, encoding=encoding)
        return load_name_source(str(filename))

    def test_utf8_bom_comma_and_column_selection(self):
        wb = self._load('STT,Tên ảnh đích,Ghi chú\n1,rose_01,đỏ\n2,hoa_tím_02,tím\n3,rose_01,trùng\n')
        self.assertTrue(wb.is_csv)
        self.assertEqual(wb.sheetnames, ["Dữ liệu CSV"])
        self.assertIn('Tên ảnh đích', get_column_options(wb.active, True)[1][1])
        items, dup = read_names(wb.active, 2, True)
        self.assertEqual([item.name for item in items], ['rose_01', 'hoa_tím_02'])
        self.assertEqual([item.excel_row for item in items], [2, 3])
        self.assertEqual(dup, 1)
        wb.close()

    def test_semicolon_excel_sep_directive_and_quotes(self):
        wb = self._load('sep=;\nID;Tên ảnh đích;Ghi chú\n001;"nắng, vàng";"ghi chú; có dấu"\n002;hoa.webp;x\n')
        self.assertEqual(wb.active.delimiter, ';')
        items, duplicates = read_names(wb.active, 2, True)
        self.assertEqual([i.name for i in items], ['nắng, vàng', 'hoa'])
        self.assertEqual(items[0].excel_row, 2)
        self.assertEqual(duplicates, 0)

    def test_tab_delimiter_and_no_header(self):
        wb = self._load('0001\ticon_first\n0002\ticon_second\n', encoding='utf-8')
        self.assertEqual(wb.active.max_column, 2)
        items, _ = read_names(wb.active, 2, False)
        self.assertEqual([i.name for i in items], ['icon_first', 'icon_second'])

    def test_quoted_newline_and_unicode(self):
        wb = self._load('Tên ảnh đích,Thông tin\n"hoa\nxanh",mô tả\n"Lá tím",ok\n')
        items, dup = read_names(wb.active, 1, True)
        self.assertEqual(items[0].state, 'invalid')
        self.assertEqual(items[1].name, 'Lá tím')
        self.assertEqual(dup, 0)

    def test_cp1258_windows_ansi_fallback(self):
        wb = self._load('Ten anh;Ghi chu\nMùa hè;màu xanh\n', encoding='cp1258')
        self.assertEqual(wb.active.encoding, 'cp1258')
        items, _ = read_names(wb.active, 1, True)
        self.assertEqual(items[0].name, 'Mùa hè')

    def test_utf16_with_bom(self):
        wb = self._load('ID,Tên ảnh đích\n1,hồng_01\n', encoding='utf-16')
        items, _ = read_names(wb.active, 2, True)
        self.assertEqual(items[0].name, 'hồng_01')

    def test_empty_csv(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'empty.csv'
            path.touch()
            with self.assertRaisesRegex(ValueError, 'trống'):
                load_csv_names(str(path))

    def test_unsupported_extension(self):
        with self.assertRaises(ValueError):
            load_name_source('abc.txt')

    def test_streaming_wide_and_missing_fields(self):
        wb = self._load('A;B;C\na;one;x\nb;\nc;three;z\n')
        rows, _ = read_names(wb.active, 2, True)
        self.assertEqual([x.name for x in rows], ['one', 'three'])
        self.assertEqual([x.excel_row for x in rows], [2, 4])


if __name__ == '__main__':
    unittest.main()
