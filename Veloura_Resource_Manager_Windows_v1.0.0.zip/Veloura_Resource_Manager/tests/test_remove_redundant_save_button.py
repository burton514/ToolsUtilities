"""Keep image input paths while removing the redundant full-width action."""
from pathlib import Path


def test_only_redundant_save_action_is_removed():
    ui = (Path(__file__).resolve().parents[1] / 'veloura/gui/workspace.py').read_text(encoding='utf-8')
    assert 'Chọn ảnh để lưu (Ctrl+S)' not in ui
    assert "'Chọn ảnh', self.choose_picture" in ui
    assert "'Dán ảnh (Ctrl+V)', self.paste_image_from_clipboard" in ui
    assert "self.drop_canvas.bind('<Button-1>', lambda e: self.choose_picture())" in ui
    shell = (Path(__file__).resolve().parents[1] / 'modern_ui.py').read_text(encoding='utf-8')
    assert "self.root.bind('<Control-s>', lambda e: self.choose_picture())" in shell
