"""Regression checks for the native caption button's full/compact states."""
from types import SimpleNamespace

from compact_view import CompactWindowActions


class Window:
    def __init__(self, state='normal'):
        self.current_state = state
        self.current_geometry = '1200x800+40+50'
        self.idle = []
        self.delayed = []
        self.min_size = (1040, 690)

    def state(self, new=None):
        if new is not None:
            self.current_state = new
        return self.current_state

    def geometry(self, new=None):
        if new is not None:
            self.current_geometry = new
        return self.current_geometry

    def minsize(self, width, height):
        self.min_size = (width, height)

    def winfo_width(self):
        return 1200

    def winfo_height(self):
        return 800

    def after_idle(self, action):
        self.idle.append(action)
        return len(self.idle)

    def after(self, duration, action):
        self.delayed.append((duration, action))
        return len(self.delayed)


class CaptionHarness(CompactWindowActions):
    def __init__(self, state='normal', compact=False):
        self.root = Window(state)
        self._closing = False
        self._compact_switching = False
        self._compact_toggle_job = None
        self._compact_caption_target = None
        self._compact_last_window_state = state
        self._compact_minimized = False
        self._compact_active = compact
        self._full_window_geometry = '1200x800+40+50'
        self.entered = 0
        self.exited = 0

    def _compact_enter(self):
        self.entered += 1
        self._compact_active = True
        self.root.state('normal')
        self._compact_last_window_state = 'normal'

    def _compact_exit(self):
        self.exited += 1
        self._compact_active = False
        self.root.state('zoomed')
        self._compact_last_window_state = 'zoomed'

    def notify(self, new_state):
        self.root.state(new_state)
        self._compact_window_state_changed(SimpleNamespace(widget=self.root))

    def run_idle(self):
        if self.root.idle:
            self.root.idle.pop(0)()


def test_middle_caption_alternates_compact_and_maximized_desktop():
    app = CaptionHarness()
    app.notify('zoomed')  # Normal desktop -> compact
    app.run_idle()
    assert app.entered == 1 and app._compact_active

    app.notify('zoomed')  # Compact -> native maximized desktop
    app.run_idle()
    assert app.exited == 1 and not app._compact_active
    assert app.root.state() == 'zoomed'

    app.notify('normal')  # Native restore button in maximized desktop
    app.run_idle()
    assert app.entered == 2 and app._compact_active


def test_minimize_and_restore_from_taskbar_never_toggle_layout():
    app = CaptionHarness(state='zoomed', compact=False)
    app.notify('iconic')
    app.notify('zoomed')
    app.run_idle()
    assert app.entered == app.exited == 0
    assert not app.root.idle
    assert not app._compact_active

    quick = CaptionHarness(state='normal', compact=True)
    quick.notify('iconic')
    quick.notify('normal')
    quick.run_idle()
    assert quick.entered == quick.exited == 0
    assert quick._compact_active


def test_repeated_configure_while_maximized_does_not_toggle_layout():
    app = CaptionHarness(state='zoomed')
    app.notify('zoomed')
    assert not app.root.idle
    assert not app._compact_active


def test_compact_exit_calls_native_zoomed_not_just_geometry_restore():
    app = CaptionHarness(compact=True)
    # Invoke the production method, not the small stub used for caption tests.
    app._compact_pin = SimpleNamespace(get=lambda: False)
    app._compact_hide_tooltip = lambda: None
    app._compact_resize_job = None
    app.compact_host = SimpleNamespace(pack_forget=lambda: None)
    app._desktop_shell = SimpleNamespace(pack=lambda **kwargs: None)
    app.compact_preview_canvas = SimpleNamespace(delete=lambda arg: None)
    CompactWindowActions._compact_exit(app)
    assert not app._compact_active
    assert app.root.state() == 'zoomed'
    assert app.root.min_size == (1040, 690)
    assert app.root.geometry() == app._full_window_geometry
    assert app.root.delayed and app.root.delayed[0][0] == 100
