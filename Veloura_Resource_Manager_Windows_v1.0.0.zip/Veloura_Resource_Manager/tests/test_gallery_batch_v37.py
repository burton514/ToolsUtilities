"""Regression tests for folder-first multi-selection, resize, and conversion."""
from pathlib import Path
from types import SimpleNamespace
import os

from PIL import Image
import pytest

import gallery_batch
from gallery_batch import BatchJob, run_batch, validated_source
from folder_live import scan_png_folder
from modern_ui import MonoUI


def png(path, size=(30, 24), alpha=255):
    Image.new('RGBA', size, (255, 0, 0, alpha)).save(path)


def make_job(directory, operation, *, files=None, **kwargs):
    snapshot = scan_png_folder(directory)
    assert snapshot.available
    return BatchJob(str(directory), 'project-A', tuple(files if files is not None else snapshot.files.values()), operation, **kwargs)


def test_resize_inplace_preserves_filename_and_alpha(tmp_path, monkeypatch):
    monkeypatch.setattr(gallery_batch, 'APP_DIR', tmp_path / '_config')
    path = tmp_path / 'one.png'
    png(path, alpha=35)
    report = run_batch(make_job(tmp_path, 'resize', width=64, height=64, mode='contain'))
    assert (report.succeeded, report.failed) == (1, 0)
    assert sorted(p.name for p in tmp_path.iterdir() if p.is_file()) == ['one.png']
    with Image.open(path) as im:
        assert im.size == (64, 64)
        assert im.getchannel('A').getextrema()[0] < 255


def test_resize_jpeg_alias_preserves_exact_file_extension(tmp_path, monkeypatch):
    monkeypatch.setattr(gallery_batch, 'APP_DIR', tmp_path / '_config')
    path = tmp_path / 'one.JPEG'
    Image.new('RGB', (32, 28), 'blue').save(path, format='JPEG')
    assert run_batch(make_job(tmp_path, 'resize', width=16, height=16, mode='stretch')).succeeded == 1
    assert path.is_file() and not (tmp_path / 'one.jpg').exists()
    with Image.open(path) as im:
        assert im.format == 'JPEG' and im.size == (16, 16)


def test_convert_transparency_to_white_jpg_retains_original(tmp_path, monkeypatch):
    monkeypatch.setattr(gallery_batch, 'APP_DIR', tmp_path / '_config')
    path = tmp_path / 'one.png'
    png(path, alpha=0)
    report = run_batch(make_job(tmp_path, 'convert', output_format='jpg'))
    assert report.succeeded == 1 and path.exists()
    with Image.open(tmp_path / 'one.jpg') as im:
        assert im.mode == 'RGB'
        assert im.getpixel((10, 10)) == (255, 255, 255)


def test_convert_existing_target_skips_without_overwriting(tmp_path, monkeypatch):
    monkeypatch.setattr(gallery_batch, 'APP_DIR', tmp_path / '_config')
    png(tmp_path / 'one.png')
    target = tmp_path / 'one.webp'
    Image.new('RGBA', (7, 8), 'blue').save(target)
    originals = (tmp_path / 'one.png',)
    job = make_job(tmp_path, 'convert', files=tuple(scan_png_folder(tmp_path).files['one.png'] for _ in range(1)), output_format='webp')
    report = run_batch(job)
    assert report.skipped == 1 and not report.failed
    with Image.open(target) as im:
        assert im.size == (7, 8)
    report = run_batch(BatchJob(job.folder, job.project_id, job.files, 'convert', output_format='webp', overwrite=True))
    assert report.succeeded == 1
    with Image.open(target) as im:
        assert im.size == (30, 24)
    assert originals[0].exists()


def test_conversion_can_remove_original_only_after_success(tmp_path, monkeypatch):
    monkeypatch.setattr(gallery_batch, 'APP_DIR', tmp_path / '_config')
    png(tmp_path / 'one.png')
    report = run_batch(make_job(tmp_path, 'convert', output_format='webp', remove_original=True))
    assert report.succeeded == 1
    assert not (tmp_path / 'one.png').exists()
    assert (tmp_path / 'one.webp').exists()


def test_stale_selection_does_not_mutate_file(tmp_path, monkeypatch):
    monkeypatch.setattr(gallery_batch, 'APP_DIR', tmp_path / '_config')
    path = tmp_path / 'one.png'
    png(path)
    job = make_job(tmp_path, 'resize', width=20, height=20, mode='stretch')
    png(path, size=(40, 40))
    report = run_batch(job)
    assert report.failed == 1 and report.succeeded == 0
    with Image.open(path) as im:
        assert im.size == (40, 40)


def test_symlink_source_rejected(tmp_path, monkeypatch):
    monkeypatch.setattr(gallery_batch, 'APP_DIR', tmp_path / '_config')
    outside = tmp_path.parent / (tmp_path.name + '_outside.png')
    png(outside)
    link = tmp_path / 'one.png'
    try:
        link.symlink_to(outside)
    except (OSError, NotImplementedError):
        pytest.skip('Symlinks not permitted')
    snapshot = scan_png_folder(tmp_path)
    meta = snapshot.files.get('one.png')
    if meta is not None:
        report = run_batch(make_job(tmp_path, 'resize', files=[meta], width=10, height=10))
        assert report.failed == 1
    with Image.open(outside) as im:
        assert im.size == (30, 24)
    outside.unlink()


def test_resize_fails_fast_on_invalid_dimensions(tmp_path):
    png(tmp_path / 'one.png')
    with pytest.raises(ValueError):
        run_batch(make_job(tmp_path, 'resize', width=20000, height=20))


def test_select_all_includes_other_pages_but_excludes_missing(tmp_path):
    for i in range(30):
        png(tmp_path / f'img_{i:02}.png')
    snapshot = scan_png_folder(tmp_path)
    state = SimpleNamespace(
        project_store=SimpleNamespace(active_id='p'),
        destination=SimpleNamespace(get=lambda: str(tmp_path)),
        _folder_snapshot=snapshot,
        output_format=SimpleNamespace(get=lambda: 'png'),
        items=[SimpleNamespace(name=f'img_{i:02}', state='existing' if i < 30 else 'pending') for i in range(31)],
        gallery_search_var=SimpleNamespace(get=lambda: ''),
        gallery_filter_var=SimpleNamespace(get=lambda: 'Tất cả'),
        _gallery_multi_selected={}, _gallery_selection_scope=None,
        _gallery_batch_running=False,
        _gallery_repaint_selections=lambda: None,
        _gallery_update_batch_toolbar=lambda: None,
    )
    state._gallery_scope=lambda: MonoUI._gallery_scope(state)
    state._gallery_prune_selection=lambda: MonoUI._gallery_prune_selection(state)
    state._gallery_display_items=lambda: MonoUI._gallery_display_items(state)
    MonoUI._gallery_select_all(state)
    assert len(state._gallery_multi_selected) == 30
    assert 'img_30.png' not in state._gallery_multi_selected

@pytest.mark.parametrize('format_key,expected_format', [
    ('png','PNG'),('jpg','JPEG'),('webp','WEBP'),('bmp','BMP'),('tiff','TIFF')])
def test_bulk_conversion_supported_formats(tmp_path, monkeypatch, format_key, expected_format):
    monkeypatch.setattr(gallery_batch, 'APP_DIR', tmp_path / '_config')
    source = tmp_path / 'input.webp'
    Image.new('RGBA', (17, 19), (50, 150, 90, 120)).save(source)
    report = run_batch(make_job(tmp_path, 'convert', output_format=format_key))
    if format_key == 'webp':
        assert report.skipped == 1
        assert source.exists()
    else:
        assert report.succeeded == 1
        extension = '.jpg' if format_key == 'jpg' else '.tiff' if format_key == 'tiff' else '.'+format_key
        with Image.open(tmp_path / ('input' + extension)) as im:
            assert im.format == expected_format and im.size == (17, 19)
        assert source.exists()

def test_folder_monitor_pauses_rescans_during_batch(tmp_path):
    """No costly full-folder scans for every temporary write in a batch."""
    import queue
    import threading
    import time
    from folder_live import FolderLiveMonitor
    from tests.test_folder_event_performance_v32 import FakeNativeWatcher

    watcher = FakeNativeWatcher(str(tmp_path))
    updates = queue.Queue()
    monitor = FolderLiveMonitor(lambda gen, snap: updates.put(snap),
                                interval=0.2, reconcile_interval=30,
                                watcher_factory=lambda path: watcher)
    try:
        monitor.watch(tmp_path)
        updates.get(timeout=2)
        monitor.pause()
        png(tmp_path / 'new.png')
        watcher.signal.set()
        time.sleep(0.55)
        assert updates.empty()
        monitor.resume()
        watcher.signal.set()
        assert updates.get(timeout=3).for_icon('new') is not None
    finally:
        monitor.stop()
