"""Filesystem is authoritative, even when changes happen outside Veloura."""
import os
import queue
import time
from pathlib import Path
from PIL import Image

from folder_live import FolderLiveMonitor, scan_png_folder


def await_snapshot(events, predicate, timeout=4):
    until = time.monotonic() + timeout
    while time.monotonic() < until:
        try:
            gen, snapshot = events.get(timeout=min(0.3, max(0.01, until-time.monotonic())))
        except queue.Empty:
            continue
        if predicate(gen, snapshot):
            return snapshot
    raise AssertionError("Folder did not report filesystem update")


def test_real_folder_scan_and_case_insensitive_matching(tmp_path):
    folder = tmp_path / "icons"
    folder.mkdir()
    Image.new('RGBA',(8,8),'red').save(folder / "ic_upload.PNG")
    (folder / "ignored.jpg").write_bytes(b"data")
    (folder / "subdir.png").mkdir()
    initial = scan_png_folder(folder)
    assert len(initial.files) == 2  # Invalid JPG is recorded as corrupt, not counted as an image.
    assert not initial.files['ignored.jpg'].valid
    assert initial.for_icon("IC_UPLOAD").path.name == "ic_upload.PNG"
    assert initial.for_icon("ignored") is None
    assert initial.for_icon("subdir") is None
    Image.new('RGBA',(12,9),'blue').save(folder / "ic_upload.PNG")
    replaced = scan_png_folder(folder)
    assert initial.files != replaced.files  # overwritten externally
    (folder / "ic_upload.PNG").rename(folder / "ic_download.png")
    renamed = scan_png_folder(folder)
    assert renamed.for_icon("ic_upload") is None
    assert renamed.for_icon("ic_download") is not None
    (folder / "ic_download.png").unlink()
    assert scan_png_folder(folder).for_icon('ic_download') is None


def test_missing_folder_becomes_available_without_restart(tmp_path):
    folder = tmp_path / "not_yet_created"
    assert not scan_png_folder(folder).files
    folder.mkdir()
    Image.new('RGB',(8,8),'blue').save(folder / "new.png")
    assert scan_png_folder(folder).for_icon("new") is not None


def test_live_monitor_reports_external_add_delete_overwrite(tmp_path):
    folder = tmp_path / "images"
    folder.mkdir()
    events = queue.Queue()
    monitor = FolderLiveMonitor(lambda gen, snap: events.put((gen, snap)), interval=0.2)
    try:
        generation = monitor.watch(folder)
        await_snapshot(events, lambda gen, snap: gen == generation)
        path = folder / "example.png"
        Image.new('RGB',(8,8),'green').save(path)
        first = await_snapshot(events, lambda gen, snap: gen == generation and snap.for_icon("example") is not None)
        Image.new('RGBA',(14,13),'magenta').save(path)
        second = await_snapshot(events, lambda gen, snap: gen == generation and snap.for_icon("example") is not None and snap.files != first.files)
        assert second.for_icon("example").size > first.for_icon("example").size
        path.unlink()
        last = await_snapshot(events, lambda gen, snap: gen == generation and snap.for_icon("example") is None)
        assert last.files == {}
    finally:
        monitor.stop()


def test_switching_project_uses_new_directory_and_generation(tmp_path):
    a, b = tmp_path / "one", tmp_path / "two"
    a.mkdir(); b.mkdir()
    Image.new('RGB',(8,8),'red').save(a / "one.png")
    Image.new('RGB',(8,8),'blue').save(b / "two.png")
    events = queue.Queue()
    monitor = FolderLiveMonitor(lambda gen, snap: events.put((gen, snap)), interval=0.2)
    try:
        gen1 = monitor.watch(a)
        await_snapshot(events, lambda gen, snap: gen == gen1 and snap.for_icon("one") is not None)
        gen2 = monitor.watch(b)
        assert gen2 > gen1
        fresh = await_snapshot(events, lambda gen, snap: gen == gen2)
        assert fresh.for_icon("one") is None
        assert fresh.for_icon("two") is not None
        Image.new('RGB',(8,8),'white').save(a / "old_project.png")
        time.sleep(0.4)
        assert not any(s.for_icon("old_project") for gen, s in _drain(events) if gen == gen2)
    finally:
        monitor.stop()


def _drain(queue_obj):
    values = []
    while True:
        try:
            values.append(queue_obj.get_nowait())
        except queue.Empty:
            return values


def test_ui_reconciliation_does_not_trust_previous_done_state(tmp_path):
    from types import SimpleNamespace
    from app import ImageManager
    from imageflow_core import NameItem

    folder = tmp_path / "target"
    folder.mkdir()
    Image.new('RGBA',(8,8),'red').save(folder / "icon_b.PNG")
    view_model = SimpleNamespace(items=[
        NameItem(name="icon_a", excel_row=2, state="done"),
        NameItem(name="icon_b", excel_row=3, state="pending"),
        NameItem(name="bad:name", excel_row=4, state="invalid"),
    ])
    changed = ImageManager._apply_png_states(view_model, scan_png_folder(folder))
    assert changed == [0, 1]
    assert [x.state for x in view_model.items] == ["pending", "existing", "invalid"]

    (folder / "icon_b.PNG").unlink()
    Image.new('RGBA',(8,8),'blue').save(folder / "icon_a.png")
    ImageManager._apply_png_states(view_model, scan_png_folder(folder))
    assert [x.state for x in view_model.items] == ["existing", "pending", "invalid"]
