"""End-to-end output-format regression: encode, folder scan, GUI and Agent safety."""
from pathlib import Path
from types import SimpleNamespace

from PIL import Image
import pytest

from imageflow_core import ExportOptions, export_png, OUTPUT_FORMATS
from folder_live import scan_png_folder
from output_preview import resolve_selected_output
from imageflow_core import NameItem
from core_service import CoreService
import app as app_module


def source_image(tmp_path):
    src = tmp_path / 'source.png'
    img = Image.new('RGBA', (30, 22), (0, 0, 0, 0))
    for x in range(5, 25):
        for y in range(4, 18):
            img.putpixel((x, y), (20, 80, 210, 255))
    img.save(src)
    return src


@pytest.mark.parametrize('fmt,ext,pillow', [
    ('png', '.png', 'PNG'), ('jpg', '.jpg', 'JPEG'),
    ('webp', '.webp', 'WEBP'), ('bmp', '.bmp', 'BMP'),
    ('tiff', '.tiff', 'TIFF'),
])
def test_actual_format_bytes_and_scan(tmp_path, fmt, ext, pillow):
    source = source_image(tmp_path)
    result = export_png(source, 'alpha', ExportOptions(tmp_path / 'output', output_format=fmt))
    assert result.destination.suffix == ext
    assert source.is_file()
    with Image.open(result.destination) as img:
        assert img.format == pillow and img.size == (30, 22)
        if fmt in ('jpg', 'bmp'):
            assert all(channel >= 245 for channel in img.getpixel((0, 0))[:3])
        if fmt in ('png', 'webp', 'tiff'):
            assert img.convert('RGBA').getpixel((0, 0))[3] == 0
    snapshot = scan_png_folder(tmp_path / 'output')
    assert snapshot.for_icon('alpha', fmt).path == result.destination
    assert resolve_selected_output(snapshot, str(tmp_path / 'output'), [NameItem('alpha', 1)], 0, fmt).path == result.destination


def test_coexisting_formats_prefer_configured_choice_and_delete_one(tmp_path, monkeypatch):
    source = source_image(tmp_path)
    folder = tmp_path / 'out'
    png = export_png(source, 'alpha', ExportOptions(folder)).destination
    webp = export_png(source, 'alpha', ExportOptions(folder, output_format='webp')).destination
    snapshot = scan_png_folder(folder)
    assert snapshot.for_icon('alpha').path == png
    assert snapshot.for_icon('alpha', 'webp').path == webp
    assert snapshot.for_icon('alpha', 'jpg').path == png  # selected format missing -> fallback
    state = SimpleNamespace(destination=SimpleNamespace(get=lambda: str(folder)),
                            output_format=SimpleNamespace(get=lambda: 'webp'),
                            project_store=SimpleNamespace(active_id='p1'),
                            _folder_snapshot=snapshot, _live_generation=5,
                            root=object(), items=[NameItem('alpha', 1, 'existing')])
    updates = []
    state._status=lambda message: None
    state._on_live_folder_snapshot=lambda generation,snap: updates.append(snap)
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *a, **k: True)
    assert app_module.ImageManager.delete_gallery_png(state, 0, 'alpha')
    assert png.exists() and not webp.exists()
    assert updates[0].for_icon('alpha', 'webp').path == png


def test_other_format_does_not_block_new_export_and_no_overwrite(tmp_path):
    source = source_image(tmp_path); folder = tmp_path / 'out'
    export_png(source, 'alpha', ExportOptions(folder))
    jpg_opts = ExportOptions(folder, output_format='jpg')
    export_png(source, 'alpha', jpg_opts)
    with pytest.raises(FileExistsError):
        export_png(source, 'alpha', jpg_opts)
    assert (folder / 'alpha.png').exists() and (folder / 'alpha.jpg').exists()


def test_invalid_format_never_creates_file_or_moves_original(tmp_path):
    source = source_image(tmp_path)
    with pytest.raises(ValueError):
        export_png(source, 'alpha', ExportOptions(tmp_path / 'out', operation='move', output_format='pdf'))
    assert source.exists()
    if (tmp_path / 'out').exists():
        assert not list((tmp_path / 'out').glob('*'))


def test_no_temp_file_left_on_conversion_failure(tmp_path):
    bad = tmp_path / 'bad.png'; bad.write_bytes(b'not real')
    with pytest.raises(Exception):
        export_png(bad, 'alpha', ExportOptions(tmp_path / 'out', output_format='jpg'))
    assert not list((tmp_path / 'out').glob('.veloura_*'))


def test_move_after_jpg_success_and_white_background(tmp_path):
    source = source_image(tmp_path)
    dest = export_png(source, 'alpha', ExportOptions(tmp_path / 'out', operation='move',
                resize_enabled=True, width=100, height=100, mode='contain', output_format='jpg'))
    assert dest.moved and not source.exists()
    with Image.open(dest.destination) as img:
        assert img.mode == 'RGB' and img.size == (100,100)
        assert all(c >= 250 for c in img.getpixel((0,0)))


def test_mislabelled_image_is_not_treated_as_valid(tmp_path):
    source = source_image(tmp_path)
    p = tmp_path / 'fake.jpg'
    p.write_bytes(source.read_bytes())
    snapshot = scan_png_folder(tmp_path)
    assert snapshot.for_icon('fake', 'jpg') is None
    assert snapshot.invalid_for_icon('fake', 'jpg') is not None


def test_agent_import_respects_format_and_preserves_png(tmp_path):
    from project_store import ProjectStore
    from imageflow_core import DEFAULTS
    from openpyxl import Workbook
    source = source_image(tmp_path)
    dest = tmp_path / 'out'; dest.mkdir()
    book = Workbook(); book.active.append(['Tên ảnh', 'Prompt']); book.active.append(['alpha','Draw'])
    excel = tmp_path / 'icons.xlsx'; book.save(excel)
    registry = tmp_path / 'projects.json'
    store = ProjectStore(DEFAULTS, registry)
    project = store.add('format-test', str(dest), '', str(excel))
    pid=project['id']
    service = CoreService(registry)
    result = service.import_image(pid, 'alpha', str(source), output_format='webp')
    assert Path(result['output_path']).suffix == '.webp'
    assert service.get_icon('alpha', pid)['file_path'].endswith('.webp')
    service.update_project(pid, output_format='jpg')
    assert service.get_project(pid)['output_format'] == 'jpg'
    result2 = service.import_image(pid, 'alpha', str(source))
    assert Path(result2['output_path']).suffix == '.jpg'
    assert Path(result['output_path']).exists()
    with pytest.raises(FileExistsError):
        service.import_image(pid, 'alpha', str(source))
