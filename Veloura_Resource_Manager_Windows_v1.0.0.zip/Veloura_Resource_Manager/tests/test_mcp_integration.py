"""Local Agent and GUI share folders/settings safely without Tkinter dependency."""
import copy
import io
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
from PIL import Image

from core_service import CoreService
from mcp_stdio import MCPServer, TOOLS
from project_store import ProjectStore
from imageflow_core import DEFAULTS


def png(path: Path, color='blue', size=(24, 20)):
    Image.new('RGBA', size, color).save(path)


def fixture(tmp_path):
    root = tmp_path / 'project'; root.mkdir()
    out = root / 'icons'; out.mkdir()
    csv = root / 'items.csv'
    csv.write_text('STT,Tên icon hiện tại,Prompt\n1,ic_alpha,Đổi màu đỏ\n2,ic_beta,Thêm dấu cộng\n', encoding='utf-8-sig')
    registry = tmp_path/'conf'/'projects.json'
    store = ProjectStore(DEFAULTS, registry)
    profile = store.add('Alpha',str(out),'Kiểm thử',str(csv))
    store.edit(profile['id'],'Alpha',str(out),'Kiểm thử',str(csv))
    service = CoreService(registry)
    service.set_source_columns(profile['id'],2,3)
    return service, profile['id'], root, out, registry


def test_mcp_lifecycle_and_schemas(tmp_path):
    srv = MCPServer(CoreService(tmp_path/'projects.json'))
    no_init = srv.handle({'jsonrpc':'2.0','id':1,'method':'tools/list'})
    assert no_init['error']['code'] == -32000
    handshake = srv.handle({'jsonrpc':'2.0','id':2,'method':'initialize','params':{'protocolVersion':'2025-11-25'}})
    assert handshake['result']['capabilities']['tools']
    assert srv.handle({'jsonrpc':'2.0','method':'notifications/initialized'}) is None
    tools = srv.handle({'jsonrpc':'2.0','id':3,'method':'tools/list'})['result']['tools']
    assert len(tools) >= 15
    assert all(t['inputSchema']['additionalProperties'] is False for t in tools)
    assert {'veloura_set_review','veloura_import_image','veloura_get_icon'} <= {t['name'] for t in tools}
    assert srv.handle({'jsonrpc':'2.0','id':4,'method':'tools/call','params':{
        'name':'veloura_import_image','arguments':{'project_id':'x'}}})['error']['code'] == -32602
    assert srv.handle({'jsonrpc':'2.0','id':5,'method':'tools/call','params':{
        'name':'veloura_set_review','arguments':{'project_id':'x','icon_name':'y','enabled':'true'}}})['error']['code'] == -32602


def test_agent_reads_excel_prompt_exports_review_and_scans(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    assert service.get_source_columns(pid)['configured_name_column'] == 2
    found = service.list_icons(pid)['icons']
    assert [x['name'] for x in found] == ['ic_alpha','ic_beta']
    assert found[0]['status'] == 'missing'
    assert service.get_icon('ic_alpha',pid)['prompt'] == 'Đổi màu đỏ'
    src = root/'source.webp'; Image.new('RGB',(22,44),'red').save(src)
    with pytest.raises(ValueError,match='Chỉ ảnh PNG hợp lệ'):
        service.set_review(pid,'ic_alpha',True)
    result = service.import_image(pid,'ic_alpha',str(src),resize=True,width=512,height=512)
    assert Path(result['output_path']).is_file()
    with Image.open(result['output_path']) as im:
        assert im.size == (512,512) and im.format == 'PNG'
    assert src.exists()  # default is copy
    with pytest.raises(FileExistsError):
        service.import_image(pid,'ic_alpha',str(src))
    assert service.set_review(pid,'ic_alpha',True)['needs_review']
    assert service.get_icon('ic_alpha',pid)['status'] == 'needs_review'
    assert service.scan_project(pid)['counts']['needs_review'] == 1
    assert service.list_icons(pid,status='needs_review')['total'] == 1
    service.set_review(pid,'ic_alpha',False)
    assert service.get_icon('ic_alpha',pid)['status'] == 'existing'
    assert not list(root.glob('*.png'))  # output only in correct folder
    assert not (out/'ic_beta.png').exists()


def test_agent_selections_are_session_local(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    before = ProjectStore(DEFAULTS,registry).active_id
    service.select_project(pid)
    assert service.get_project()['project']['id'] == pid
    assert ProjectStore(DEFAULTS,registry).active_id == before
    assert CoreService(registry).list_projects()['agent_selected_project_id'] == before


def test_agent_references_are_project_scoped(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    a = root/'sample.png'; png(a)
    res = service.add_reference(pid,str(a))
    assert len(res['references']) == 1
    assert res['references'][0]['selected']
    service.assign_reference(pid,'ic_beta',str(a),False)
    assert service.list_references(pid,'ic_beta')['references'][0]['selected'] is False
    assert service.list_references(pid,'ic_alpha')['references'][0]['selected'] is True
    with pytest.raises(ValueError):
        service.assign_reference(pid,'unknown',str(a),True)


def test_agent_png_rename_avoids_overwrite_and_spreadsheet(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    png(out/'ic_alpha.png')
    png(out/'target.png','red')
    original=(out/'target.png').read_bytes()
    with pytest.raises(FileExistsError):
        service.rename_png(pid,'ic_alpha','target')
    assert (out/'target.png').read_bytes()==original
    result = service.rename_png(pid,'ic_alpha','renamed')
    assert result['changed'] and not result['spreadsheet_updated']
    assert (out/'renamed.png').exists() and not (out/'ic_alpha.png').exists()
    with pytest.raises(ValueError):
        service.rename_png(pid,'renamed','../escape')
    assert 'ic_alpha' in (root/'items.csv').read_text(encoding='utf-8-sig')


def test_gui_and_agent_fields_three_way_merge_and_conflict(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    gui = ProjectStore(DEFAULTS,registry)
    external = ProjectStore(DEFAULTS,registry)
    gui.get(pid)['resize_width'] = 768
    external.get(pid)['review_marks'] = ['ic_alpha']
    external.save()
    gui.save()
    merged = ProjectStore(DEFAULTS,registry).get(pid)
    assert merged['resize_width'] == 768 and merged['review_marks'] == ['ic_alpha']

    gui = ProjectStore(DEFAULTS,registry)
    agent = ProjectStore(DEFAULTS,registry)
    gui.get(pid)['resize_width'] = 800
    agent.get(pid)['resize_width'] = 512
    agent.save()
    with pytest.raises(ValueError,match='tiến trình khác'):
        gui.save()
    assert ProjectStore(DEFAULTS,registry).get(pid)['resize_width'] == 512


def test_agent_project_delete_requires_confirmation_and_preserves_images(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    png(out/'ic_beta.png')
    with pytest.raises(ValueError,match='confirm'):
        service.delete_project(pid)
    with pytest.raises(ValueError):
        service.create_project('Another',str(root/'items.csv'),str(out))
    response = service.delete_project(pid,confirm=True)
    assert response['physical_files_deleted'] is False
    assert (out/'ic_beta.png').exists()
    assert service.get_project()['project']['name'] == 'Project mặc định'


def test_mcp_tool_calls_with_real_service(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    srv=MCPServer(service)
    srv.handle({'jsonrpc':'2.0','id':1,'method':'initialize','params':{}})
    srv.handle({'jsonrpc':'2.0','method':'notifications/initialized'})
    resp=srv.handle({'jsonrpc':'2.0','id':2,'method':'tools/call',
        'params':{'name':'veloura_list_icons','arguments':{'project_id':pid,'include_prompt':True}}})
    assert not resp['result']['isError']
    assert 'Đổi màu đỏ' in resp['result']['content'][0]['text']
    assert resp['result']['structuredContent']['total'] == 2


def test_real_stdio_subprocess(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    # subprocess reads the same LOCALAPPDATA path as the desktop app.
    local = tmp_path/'local'; local.mkdir()
    config = local/'VelouraImageManager'; config.mkdir()
    (config/'projects.json').write_bytes(registry.read_bytes())
    import mcp_stdio
    env=os.environ.copy(); env['LOCALAPPDATA']=str(local)
    here=Path(mcp_stdio.__file__).parent
    messages=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25'}},
              {'jsonrpc':'2.0','method':'notifications/initialized'},
              {'jsonrpc':'2.0','id':2,'method':'tools/list'},
              {'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'veloura_get_icon',
                   'arguments':{'project_id':pid,'name':'ic_beta'}}}]
    proc=subprocess.run([sys.executable,'-u',str(here/'mcp_stdio.py')],
          input='\n'.join(json.dumps(m) for m in messages)+'\n',text=True,
          capture_output=True,env=env,timeout=15,cwd=here)
    assert proc.returncode == 0,proc.stderr
    lines=[json.loads(s) for s in proc.stdout.splitlines()]
    assert len(lines) == 3
    assert lines[1]['result']['tools']
    assert lines[2]['result']['structuredContent']['name'] == 'ic_beta'
    assert not proc.stderr


def test_status_does_not_trust_corrupted_png(tmp_path):
    service,pid,root,out,registry=fixture(tmp_path)
    (out/'ic_alpha.png').write_bytes(b'not a valid PNG')
    assert service.get_icon('ic_alpha',pid)['status'] == 'corrupt'
    with pytest.raises(ValueError):
        service.set_review(pid,'ic_alpha',True)


def test_save_backup_does_not_drop_second_project_on_stale_save(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    gui=ProjectStore(DEFAULTS,registry)
    other=root/'second';other.mkdir()
    external=ProjectStore(DEFAULTS,registry)
    second=external.add('Second',str(other),last_source=str(root/'items.csv'))
    gui.get(pid)['resize_width']=1024
    gui.save()
    names={p['name'] for p in ProjectStore(DEFAULTS,registry).projects}
    assert 'Second' in names and 'Alpha' in names


def test_mcp_image_content_and_reference_access(tmp_path):
    import base64
    service,pid,root,out,registry = fixture(tmp_path)
    png(out/'ic_alpha.png')
    ref = root/'reference.webp'; Image.new('RGB',(20,10),'green').save(ref)
    service.add_reference(pid,str(ref))
    server = MCPServer(service)
    server.handle({'jsonrpc':'2.0','id':1,'method':'initialize','params':{}})
    server.handle({'jsonrpc':'2.0','method':'notifications/initialized'})
    def ask(source):
        return server.handle({'jsonrpc':'2.0','id':2,'method':'tools/call','params':{
            'name':'veloura_view_image','arguments':{'project_id':pid,'icon_name':'ic_alpha','source':source}}})['result']
    for source in ('output','reference'):
        result=ask(source)
        assert result['isError'] is False
        block=result['content'][1]
        assert block['type']=='image' and block['mimeType']=='image/png'
        with Image.open(io.BytesIO(base64.b64decode(block['data']))) as image:
            assert image.format == 'PNG'
    service.assign_reference(pid,'ic_alpha',str(ref),False)
    assert ask('reference')['isError'] is True


def test_agent_overwrite_is_explicit_in_wire_protocol(tmp_path):
    service,pid,root,out,registry=fixture(tmp_path)
    source=root/'image.png'; png(source)
    server=MCPServer(service)
    server.handle({'jsonrpc':'2.0','id':1,'method':'initialize','params':{}})
    server.handle({'jsonrpc':'2.0','method':'notifications/initialized'})
    msg={'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'veloura_import_image',
         'arguments':{'project_id':pid,'icon_name':'ic_beta','image_path':str(source)}}}
    first=server.handle(msg)
    assert first['result']['isError'] is False
    second=server.handle(msg)
    assert second['result']['isError'] is True
    assert 'tồn tại' in second['result']['content'][0]['text']


def test_registry_sync_keeps_agent_changes(tmp_path):
    service,pid,root,out,registry=fixture(tmp_path)
    gui=ProjectStore(DEFAULTS,registry)
    service.set_source_columns(pid,2,0)
    assert gui.sync_from_disk() is True
    assert gui.get(pid)['last_prompt_column'] == 0
    assert gui.sync_from_disk() is False


def test_modern_mcp_2026_discovery_and_direct_tool_call(tmp_path):
    service,pid,root,out,registry=fixture(tmp_path)
    server=MCPServer(service)
    env={'io.modelcontextprotocol/protocolVersion':'2026-07-28',
         'io.modelcontextprotocol/clientInfo':{'name':'test','version':'1.0'}}
    discover=server.handle({'jsonrpc':'2.0','id':1,'method':'server/discover','params':{'_meta':env}})
    assert discover['result']['supportedVersions']==['2026-07-28']
    assert discover['result']['resultType']=='complete'
    listed=server.handle({'jsonrpc':'2.0','id':2,'method':'tools/list','params':{'_meta':env}})
    assert listed['result']['resultType']=='complete'
    assert 'ttlMs' in listed['result']
    called=server.handle({'jsonrpc':'2.0','id':3,'method':'tools/call','params':{
        '_meta':env, 'name':'veloura_get_icon', 'arguments':{'project_id':pid,'name':'ic_alpha'}}})
    assert called['result']['structuredContent']['name']=='ic_alpha'
    assert called['result']['resultType']=='complete'
    assert called['result']['_meta']['io.modelcontextprotocol/serverInfo']['name']=='veloura-resource-manager'


def test_agent_scan_clears_manual_flag_after_external_deletion(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    png(out/'ic_alpha.png')
    service.set_review(pid,'ic_alpha',True)
    (out/'ic_alpha.png').unlink()
    assert service.list_icons(pid)['icons'][0]['status'] == 'missing'
    assert ProjectStore(DEFAULTS,registry).get(pid)['review_marks'] == []
    png(out/'ic_alpha.png')
    assert service.get_icon('ic_alpha',pid)['status'] == 'existing'


def test_prompt_column_zero_disables_prompt_even_when_source_has_one(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    service.set_source_columns(pid,2,0)
    assert service.get_icon('ic_alpha',pid)['prompt'] == ''


def test_modern_mcp_stdio_subprocess_without_initialize(tmp_path):
    service,pid,root,out,registry = fixture(tmp_path)
    local = tmp_path/'local'; local.mkdir()
    config = local/'VelouraImageManager'; config.mkdir()
    (config/'projects.json').write_bytes(registry.read_bytes())
    import mcp_stdio
    env=os.environ.copy(); env['LOCALAPPDATA']=str(local)
    here=Path(mcp_stdio.__file__).parent
    meta={'io.modelcontextprotocol/protocolVersion':'2026-07-28',
          'io.modelcontextprotocol/clientInfo':{'name':'test','version':'1.0'}}
    messages=[{'jsonrpc':'2.0','id':1,'method':'server/discover','params':{'_meta':meta}},
              {'jsonrpc':'2.0','id':2,'method':'tools/list','params':{'_meta':meta}},
              {'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'_meta':meta,
                  'name':'veloura_get_icon', 'arguments':{'project_id':pid,'name':'ic_alpha'}}}]
    proc=subprocess.run([sys.executable,'-u',str(here/'mcp_stdio.py')],
        input='\n'.join(json.dumps(m) for m in messages)+'\n',text=True,
        capture_output=True,env=env,timeout=15,cwd=here)
    assert proc.returncode==0,proc.stderr
    response=[json.loads(row) for row in proc.stdout.splitlines()]
    assert len(response)==3
    assert response[0]['result']['supportedVersions']==['2026-07-28']
    assert response[1]['result']['resultType']=='complete'
    assert response[2]['result']['structuredContent']['prompt']=='Đổi màu đỏ'


def test_gui_agent_share_identical_prompt_template_rules(tmp_path):
    from imageflow_core import assemble_prompt
    service,pid,root,out,registry=fixture(tmp_path)
    store=ProjectStore(DEFAULTS,registry)
    store.get(pid)['template_enabled']=True
    store.get(pid)['prompt_template']='Tên: {name}; {prompt}'
    store.save()
    detail=service.get_icon('ic_alpha',pid)
    assert detail['effective_prompt']==assemble_prompt(detail['prompt'],'ic_alpha','Tên: {name}; {prompt}',True)
    assert detail['effective_prompt']=='Tên: ic_alpha; Đổi màu đỏ'
