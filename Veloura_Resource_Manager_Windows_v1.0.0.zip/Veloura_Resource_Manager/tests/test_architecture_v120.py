"""Architecture regression: explicit method ownership without legacy UI inheritance."""
import ast
from pathlib import Path

from app import ImageManager, ModernResourceManager
from modern_ui import MonoUI
from veloura.controllers.projects import ProjectController
from veloura.controllers.source import SourceController
from veloura.controllers.folder import FolderController
from veloura.controllers.images import ImageController
from veloura.controllers.activity import ActivityController
from veloura.gui.workspace import WorkspaceUI
from veloura.gui.gallery import GalleryUI
from veloura.gui.projects import ProjectsUI
from veloura.gui.other_pages import OtherPagesUI
from veloura.gui import theme
import modern_ui
from compact_view import CompactWindowActions
from mcp_stdio import TOOLS

ROOT = Path(__file__).resolve().parents[1]


def test_gui_and_controllers_use_explicit_single_inheritance():
    assert ImageManager.__bases__ == (object,)
    assert MonoUI.__bases__ == (object,)
    assert ModernResourceManager.__bases__ == (ImageManager,)
    assert not (ROOT / 'veloura/controllers/legacy_layout.py').exists()
    assert not (ROOT / 'veloura/controllers/legacy_theme.py').exists()


def test_public_entry_points_still_dispatch_to_correct_implementations():
    assert ImageManager._install_project is ProjectController._install_project
    assert ImageManager.import_source is SourceController.import_source
    assert ImageManager.delete_gallery_png is FolderController.delete_gallery_png
    assert ImageManager.process_image is ImageController.process_image
    assert ImageManager._poll is ActivityController._poll
    assert MonoUI._build_gallery_page is GalleryUI._build_gallery_page
    assert MonoUI._build_main_panel is WorkspaceUI._build_main_panel
    assert MonoUI._build_projects_page is ProjectsUI._build_projects_page
    assert MonoUI._build_extra_pages is OtherPagesUI._build_extra_pages
    assert MonoUI._build_layout.__module__ == 'modern_ui'
    assert ImageManager.paste_image_from_clipboard.__module__ == 'app'
    assert ModernResourceManager._build_layout is CompactWindowActions._build_layout
    assert ModernResourceManager._refresh_target is CompactWindowActions._refresh_target
    assert ModernResourceManager._refresh_workspace_target is WorkspaceUI._refresh_target
    assert ModernResourceManager._refresh_source_target is SourceController._refresh_target
    assert ModernResourceManager.persist_settings is WorkspaceUI.persist_settings
    assert ModernResourceManager._persist_controller_settings is ImageManager.persist_settings
    assert ModernResourceManager._install_project is WorkspaceUI._install_project
    assert ModernResourceManager._install_controller_project is ProjectController._install_project
    assert ModernResourceManager._open_external is GalleryUI._open_external
    assert ModernResourceManager._select_project_from_page is ProjectsUI._select_project_from_page


def test_theme_has_one_canonical_main_window_source():
    assert modern_ui.BG == theme.BG == '#F6F6F6'
    assert modern_ui.F == theme.F


def test_no_implicit_star_imports_or_entrypoint_cycles():
    for directory in ('gui', 'controllers'):
        for file in (ROOT / 'veloura' / directory).glob('*.py'):
            tree = ast.parse(file.read_text('utf-8'))
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    assert node.module not in {'app', 'modern_ui', 'compact_view', 'mcp_stdio'}, file
                    assert all(alias.name != '*' for alias in node.names), file
                elif isinstance(node, ast.Import):
                    assert all(x.name not in {'app', 'modern_ui', 'compact_view', 'mcp_stdio'} for x in node.names), file
    for file in (ROOT / 'app.py', ROOT / 'modern_ui.py'):
        tree = ast.parse(file.read_text('utf-8'))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                assert all(alias.name != '*' for alias in node.names), file


def test_mcp_contract_and_root_entrypoints_preserved():
    assert len(TOOLS) == 18
    assert (ROOT / 'app.py').exists()
    assert (ROOT / 'mcp_stdio.py').exists()
    assert (ROOT / 'START_WINDOWS.cmd').exists()
    assert (ROOT / 'CAI_EXE_RA_DESKTOP.cmd').exists()
