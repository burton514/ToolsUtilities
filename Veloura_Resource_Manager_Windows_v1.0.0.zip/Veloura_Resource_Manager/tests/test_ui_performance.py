"""UI performance regressions (no physical Windows display required)."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from modern_ui import MonoUI
from ui_thumbnail_cache import ThumbnailCache


def test_thumbnail_cache_reuses_unmodified_image_without_calling_factory_twice():
    cache = ThumbnailCache(max_entries=3)
    calls = []

    def factory():
        calls.append(len(calls))
        return object()

    first = cache.get('a.png', (112, 105), (100, 123, 9), factory)
    second = cache.get('a.png', (112, 105), (100, 123, 9), factory)
    assert first is second
    assert len(calls) == 1
    assert cache.hits == 1 and cache.misses == 1


def test_thumbnail_cache_invalidates_on_metadata_or_size_change():
    cache = ThumbnailCache(4)
    factory = object
    a = cache.get('a.png', (100, 100), (10, 1, 0), factory)
    b = cache.get('a.png', (100, 100), (10, 2, 0), factory)
    c = cache.get('a.png', (120, 100), (10, 2, 0), factory)
    assert a is not b and b is not c
    # Old decoded versions of the same size are discarded, not retained.
    assert len(cache) == 2


def test_thumbnail_cache_bounds_memory_with_lru():
    cache = ThumbnailCache(3)
    for n in range(15):
        cache.get(f'{n}.png', (140, 140), (n, n), object)
    assert len(cache) == 3
    assert cache.misses == 15
    original_misses = cache.misses
    cache.get('0.png', (140, 140), (0, 0), object)
    assert cache.misses == original_misses + 1
    assert len(cache) == 3


def test_thumbnail_failed_decode_is_not_cached():
    cache = ThumbnailCache(4)
    with pytest.raises(OSError):
        cache.get('bad.png', (32, 32), (1,), lambda: (_ for _ in ()).throw(OSError('corrupt')))
    assert len(cache) == 0
    assert cache.misses == 0


def test_lazy_icons_do_not_preload_all_variants():
    fake = SimpleNamespace()
    with patch('modern_ui.ImageTk.PhotoImage', side_effect=lambda im: object()) as make_photo:
        MonoUI._prepare_icons(fake)
        assert len(fake.ui_icons) <= 1  # logo only
        fake._get_icon = lambda name, variant='black': MonoUI._get_icon(fake, name, variant)
        black = fake._get_icon('nav_gallery')
        assert black is not None
        assert fake._get_icon('nav_gallery') is black
        white = fake._get_icon('nav_gallery', 'white')
        assert white is not None and white is not black
        assert len(fake.ui_icons) <= 3
        assert make_photo.call_count <= 3


def test_missing_icon_is_cached_as_missing():
    fake = SimpleNamespace()
    with patch('modern_ui.ImageTk.PhotoImage', side_effect=lambda im: object()):
        MonoUI._prepare_icons(fake)
        fake._get_icon = lambda name, variant='black': MonoUI._get_icon(fake, name, variant)
        assert fake._get_icon('not_a_real_icon_12345') is None
        assert fake._get_icon('not_a_real_icon_12345') is None
        assert 'black/not_a_real_icon_12345' in fake._missing_ui_icons
