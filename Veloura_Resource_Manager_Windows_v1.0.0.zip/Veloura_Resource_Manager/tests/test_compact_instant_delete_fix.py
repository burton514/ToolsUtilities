"""Quick Workspace instant deletion resolves the current on-disk image safely."""
from pathlib import Path
from types import SimpleNamespace

from PIL import Image
import pytest

from app import ImageManager
from compact_view import CompactWindowActions
from folder_live import scan_png_folder
from veloura.controllers.folder import FolderController


class Var:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value


def save_png(path, color):
    Image.new('RGBA', (40, 40), color).save(path)


class CompactDeleteOwner:
    _compact_delete_output = CompactWindowActions._compact_delete_output
    delete_gallery_png = FolderController.delete_gallery_png

    def __init__(self, folder):
        self.destination = Var(str(folder))
        self.output_format = Var('png')
        self.project_store = SimpleNamespace(active_id='project_A')
        self._folder_snapshot = scan_png_folder(folder)
        self._live_generation = 12
        self.items = [SimpleNamespace(name='demo', state='existing')]
        self.selected_index = 0
        self.processing = False
        self._gallery_batch_running = False
        self.root = object()
        self.statuses = []
        self.updates = []

    def _status(self, text):
        self.statuses.append(text)

    def _on_live_folder_snapshot(self, generation, snapshot):
        self._folder_snapshot = snapshot
        self.updates.append((generation, snapshot))


@pytest.mark.parametrize('replace', [False, True])
def test_compact_delete_has_no_confirmation_and_deletes_latest_valid_image(tmp_path, monkeypatch, replace):
    target = tmp_path / 'demo.png'
    save_png(target, (5, 30, 60))
    other = tmp_path / 'other.png'
    save_png(other, (9, 10, 11))
    source = tmp_path / 'names.csv'
    source.write_text('demo,sample prompt', encoding='utf-8')
    app = CompactDeleteOwner(tmp_path)
    if replace:
        # Re-export under exactly the same name after the UI snapshot.
        save_png(target, (201, 35, 50))
    import veloura.controllers.folder as folder_module
    import compact_view
    monkeypatch.setattr(folder_module.messagebox, 'askyesno',
                        lambda *a, **k: pytest.fail('Confirmation must not appear'))
    monkeypatch.setattr(folder_module.messagebox, 'showwarning',
                        lambda *a, **k: pytest.fail('Unexpected warning'))
    monkeypatch.setattr(compact_view.messagebox, 'showinfo',
                        lambda *a, **k: pytest.fail('Unexpected info dialog'))
    assert app._compact_delete_output() is True
    assert not target.exists()
    assert other.exists()
    assert source.read_text(encoding='utf-8') == 'demo,sample prompt'
    assert app.items[0].name == 'demo'
    assert app.updates[0][0] == 12
    assert app.updates[0][1].for_icon('demo') is None
    assert app.updates[0][1].for_icon('other') is not None
    assert app.statuses[-1] == 'Đã xóa ảnh: demo.png'


def test_compact_refuses_invalid_replacement_without_deleting(tmp_path, monkeypatch):
    target = tmp_path / 'demo.png'
    save_png(target, (1, 2, 3))
    app = CompactDeleteOwner(tmp_path)
    target.write_text('not actually a PNG image', encoding='utf-8')
    import veloura.controllers.folder as folder_module
    errors = []
    monkeypatch.setattr(folder_module.messagebox, 'showwarning', lambda *a, **kw: errors.append(a))
    monkeypatch.setattr(folder_module.messagebox, 'askyesno',
                        lambda *a, **kw: pytest.fail('Should not show confirmation'))
    assert app._compact_delete_output() is False
    assert target.exists()
    assert not app.updates
    assert errors


def test_compact_refuses_changed_symlink_outside_project(tmp_path, monkeypatch):
    folder = tmp_path / 'project'
    folder.mkdir()
    external = tmp_path / 'external.png'
    save_png(external, (1, 2, 3))
    inside = folder / 'demo.png'
    save_png(inside, (4, 5, 6))
    app = CompactDeleteOwner(folder)
    inside.unlink()
    try:
        inside.symlink_to(external)
    except (OSError, NotImplementedError):
        pytest.skip('Symlinks unavailable')
    import veloura.controllers.folder as folder_module
    monkeypatch.setattr(folder_module.messagebox, 'showwarning', lambda *a, **kw: None)
    assert app._compact_delete_output() is False
    assert inside.is_symlink() and external.exists()
    assert not app.updates


def test_compact_does_not_delete_during_processing(tmp_path, monkeypatch):
    target = tmp_path / 'demo.png'
    save_png(target, (1, 2, 3))
    app = CompactDeleteOwner(tmp_path)
    app.processing = True
    import compact_view
    infos = []
    monkeypatch.setattr(compact_view.messagebox, 'showinfo', lambda *a, **k: infos.append(a))
    assert app._compact_delete_output() is False
    assert target.exists() and infos


def test_gallery_and_app_retain_shared_delete_method():
    assert ImageManager.delete_gallery_png is FolderController.delete_gallery_png
