"""Regression tests for Windows paths pasted into the CSV/Excel import flow."""
import ntpath
import tempfile
import unittest
from pathlib import Path

from imageflow_core import load_name_source, normalize_source_path, read_names


class PathImportTests(unittest.TestCase):
    def test_windows_drive_with_unwanted_leading_slash(self):
        source = "/C:/Users/Admin/Desktop/Androiddemo/LUMII/LUMII_REFACTOR_V3/design/icon-inventory/danh-sach-icon.csv"
        fixed = normalize_source_path(source)
        self.assertEqual(fixed, source[1:])
        self.assertTrue(ntpath.isabs(fixed))

    def test_windows_path_uri_and_wrapping_quotes(self):
        self.assertEqual(normalize_source_path('"file:///C:/My%20Files/danh-sach-icon.csv"'),
                         'C:/My Files/danh-sach-icon.csv')
        self.assertEqual(normalize_source_path(r"'\C:\Users\Admin\danh-sach-icon.csv'"),
                         r'C:\Users\Admin\danh-sach-icon.csv')

    def test_unc_path_is_not_mangled(self):
        path = r'\\SERVER\share\danh-sach-icon.csv'
        self.assertEqual(normalize_source_path(path), path)
        self.assertEqual(normalize_source_path('file://SERVER/share/danh-sach-icon.csv'),
                         '//SERVER/share/danh-sach-icon.csv')

    def test_regular_paths_are_not_modified(self):
        self.assertEqual(normalize_source_path('C:/Files/danh-sach-icon.csv'),
                         'C:/Files/danh-sach-icon.csv')
        self.assertEqual(normalize_source_path('/home/user/danh-sach-icon.csv'),
                         '/home/user/danh-sach-icon.csv')

    def test_direct_csv_import_still_works(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp) / 'danh-sach-icon.csv'
            file.write_text('ID;Tên ảnh đích\n1;icon_one\n2;hoa_tím\n', encoding='utf-8-sig')
            workbook = load_name_source(f'"{file}"')
            try:
                names, duplicates = read_names(workbook.active, 2, True)
                self.assertEqual([item.name for item in names], ['icon_one', 'hoa_tím'])
                self.assertEqual(duplicates, 0)
            finally:
                workbook.close()


if __name__ == '__main__':
    unittest.main()
