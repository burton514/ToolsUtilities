"""Native-event and folder-first behavior: no project filesystem mutations."""
from __future__ import annotations

import queue
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image

import folder_live
from app import ImageManager
from folder_live import FolderLiveMonitor, scan_png_folder
from imageflow_core import NameItem
from ui_thumbnail_cache import ThumbnailCache


def _png(path: Path, color='blue', size=(28, 32)):
    Image.new('RGBA', size, color).save(path)


def _event_of(q, predicate, timeout=5):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            gen, snap = q.get(timeout=min(0.3, deadline - time.monotonic()))
        except queue.Empty:
            continue
        if predicate(gen, snap):
            return snap
    raise AssertionError('Không nhận được thay đổi folder')


class FakeNativeWatcher:
    def __init__(self, folder: str):
        self.folder = folder
        self.signal = threading.Event()
        self.closed = False

    def wait(self, timeout):
        value = self.signal.wait(timeout)
        if value:
            self.signal.clear()
        return value

    def close(self):
        self.closed = True
        self.signal.set()


def test_folder_events_do_not_scan_when_idle(tmp_path, monkeypatch):
    folder = tmp_path / 'output'; folder.mkdir()
    _png(folder / 'first.png')
    originals = folder_live.scan_png_folder
    scans = []
    watchers = []

    def tracer(*args, **kwargs):
        scans.append(time.monotonic())
        return originals(*args, **kwargs)

    def factory(path):
        if not path:
            return None
        obj = FakeNativeWatcher(path)
        watchers.append(obj)
        return obj

    monkeypatch.setattr(folder_live, 'scan_png_folder', tracer)
    q = queue.Queue()
    mon = FolderLiveMonitor(lambda gen, snap: q.put((gen, snap)), interval=0.2,
                            reconcile_interval=20, watcher_factory=factory)
    try:
        gen = mon.watch(folder)
        _event_of(q, lambda g, s: g == gen and s.for_icon('first') is not None)
        scans_before = len(scans)
        time.sleep(0.75)
        assert len(scans) == scans_before  # no periodic scandir on Windows
        _png(folder / 'second.png')
        watchers[0].signal.set()
        _event_of(q, lambda g, s: g == gen and s.for_icon('second') is not None)
        assert len(scans) == scans_before + 1
        (folder / 'first.png').rename(folder / 'renamed.png')
        watchers[0].signal.set()
        _event_of(q, lambda g, s: g == gen and s.for_icon('renamed') is not None and s.for_icon('first') is None)
        (folder / 'second.png').unlink()
        watchers[0].signal.set()
        _event_of(q, lambda g, s: g == gen and s.for_icon('second') is None)
    finally:
        mon.stop()
    assert watchers[0].closed


def test_unchanged_pictures_are_not_decoded_when_another_changes(tmp_path, monkeypatch):
    folder = tmp_path / 'png'; folder.mkdir()
    for i in range(30):
        _png(folder / f'icon_{i:03d}.png')
    first = scan_png_folder(folder)
    calls = []
    original = folder_live._is_valid_png

    def counting(path, size):
        calls.append(Path(path).name)
        return original(path, size)

    monkeypatch.setattr(folder_live, '_is_valid_png', counting)
    _png(folder / 'icon_005.png', 'red', size=(40, 44))
    second = scan_png_folder(folder, previous=first)
    assert calls == ['icon_005.png']
    assert second.for_icon('icon_005') is not None
    assert len(second.files) == len(first.files)
    (folder / 'icon_007.png').unlink()
    third = scan_png_folder(folder, previous=second)
    assert len(calls) == 1 and third.for_icon('icon_007') is None


def test_temporary_uncommitted_png_is_not_visible(tmp_path):
    folder = tmp_path / 'output'; folder.mkdir()
    (folder / '.veloura_abc123.png').write_bytes(b'partial PNG bytes')
    _png(folder / 'final.png')
    snapshot = scan_png_folder(folder)
    assert list(snapshot.files) == ['final.png']


def test_changed_thumbnail_eviction_and_small_ram_cache(tmp_path):
    cache = ThumbnailCache(max_entries=48)
    path = tmp_path / 'icon.png'
    image = cache.get(path, (112, 105), (1,), object)
    replacement = cache.get(path, (112, 105), (2,), object)
    assert image is not replacement and len(cache) == 1
    cache.get(path, (174, 168), (2,), object)
    assert len(cache) == 2
    cache.invalidate_file(path)
    assert len(cache) == 0


def test_changed_name_only_updates_matching_gui_item(tmp_path):
    folder = tmp_path / 'out'; folder.mkdir()
    _png(folder / 'one.png')
    snapshot = scan_png_folder(folder)
    vm = SimpleNamespace(items=[NameItem('one', 2, state='pending'), NameItem('two', 3, state='done')],
                         review_marks={'one'})
    changes = ImageManager._apply_png_states(vm, snapshot, changed_names={'one'})
    assert changes == [0]
    assert vm.items[0].state == 'review'
    assert vm.items[1].state == 'done'  # untouched, no full list reconciliation


def test_source_fingerprint_updates_only_after_file_change(tmp_path):
    source = tmp_path / 'icons.csv'
    source.write_text('Tên icon,Prompt\nfirst,hello\n', encoding='utf-8')
    original = ImageManager._source_fingerprint(source)
    assert original is not None
    assert ImageManager._source_fingerprint(source) == original
    source.write_text('Tên icon,Prompt\nfirst,hello\nsecond,world\n', encoding='utf-8')
    assert ImageManager._source_fingerprint(source) != original


def test_csv_auto_reload_requires_stable_file_and_preserves_selected_name(tmp_path):
    from imageflow_core import NameItem
    source = tmp_path / 'names.csv'
    source.write_text('Tên icon,Prompt\nfirst,hello\n', encoding='utf-8-sig')
    calls = []
    original = ImageManager._source_fingerprint(source)
    fake = SimpleNamespace(source_path=source, workbook=object(), items=[NameItem('first', 2)],
                           selected_index=0, _source_disk_signature=original,
                           _source_change_pending=None,
                           _source_fingerprint=ImageManager._source_fingerprint,
                           import_source=lambda path, preserve_selection=None: calls.append((path, preserve_selection)))
    ImageManager._reload_source_if_changed(fake)
    assert not calls
    source.write_text('Tên icon,Prompt\nfirst,hello\nsecond,world\n', encoding='utf-8-sig')
    ImageManager._reload_source_if_changed(fake)
    assert not calls  # first observation, maybe writer still running
    ImageManager._reload_source_if_changed(fake)
    assert calls == [(str(source), 'first')]


def test_windows_change_notification_api_contract(monkeypatch):
    """Simulated Win32 kernel calls; actual Windows execution still needs testing."""
    import ctypes
    import folder_live

    class WinFunc:
        def __init__(self, outputs):
            self.outputs = list(outputs)
            self.argtypes = None
            self.restype = None

        def __call__(self, *args):
            return self.outputs.pop(0)

    kernel = SimpleNamespace(
        FindFirstChangeNotificationW=WinFunc([212]),
        FindNextChangeNotification=WinFunc([1]),
        FindCloseChangeNotification=WinFunc([1]),
        WaitForSingleObject=WinFunc([0, 0x102]),
    )
    monkeypatch.setattr(ctypes, 'WinDLL', lambda *args, **kwargs: kernel, raising=False)
    watcher = folder_live._WindowsFolderWatcher(r'C:\\Images')
    assert watcher.wait(0.1)
    assert not watcher.wait(0.1)
    watcher.close()
    assert watcher._handle is None
