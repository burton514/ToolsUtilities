"""Output preview is derived from disk and selected row, never activity history."""
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image

from folder_live import scan_png_folder
from imageflow_core import NameItem
from modern_ui import MonoUI


class FakeLabel:
    def __init__(self):
        self.options = {}

    def configure(self, **kwargs):
        self.options.update(kwargs)


class FakeVariable:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value


class FakeOwner:
    def __init__(self, folder):
        self.destination = FakeVariable(str(folder))
        self.project_store = SimpleNamespace(active_id="one")
        self.items = [NameItem(name="first", excel_row=2), NameItem(name="second", excel_row=3)]
        self.selected_index = 0
        self._folder_snapshot = scan_png_folder(folder)
        self.preview_img = FakeLabel()
        self.preview_title = FakeLabel()
        self.preview_sub = FakeLabel()
        self.preview_empty = object()
        self.preview_ref = None


def test_ui_preview_changes_with_selection_folder_and_overwrite(tmp_path):
    a = tmp_path / 'one'; a.mkdir()
    b = tmp_path / 'two'; b.mkdir()
    first = a / 'first.png'
    Image.new('RGBA', (512, 512), (199, 55, 90, 255)).save(first)
    owner = FakeOwner(a)
    calls = []

    def fake_photo(img):
        photo = SimpleNamespace(size=img.size, sequence=len(calls))
        calls.append(photo)
        return photo

    with patch('modern_ui.ImageTk.PhotoImage', side_effect=fake_photo):
        MonoUI._refresh_selected_output_preview(owner)
        assert owner.preview_title.options['text'] == 'first.png'
        assert owner.preview_sub.options['text'].startswith('512 × 512')
        assert len(calls) == 1

        # Repeated 0.7s snapshots with unchanged file should not re-decode it.
        MonoUI._refresh_selected_output_preview(owner)
        assert len(calls) == 1

        # Pick an icon without an output, and ensure the previous photo is gone.
        owner.selected_index = 1
        MonoUI._refresh_selected_output_preview(owner)
        assert owner.preview_ref is None
        assert 'Chưa có ảnh' in owner.preview_title.options['text']

        # New externally-created PNG is shown after the filesystem scan.
        Image.new('RGBA', (72, 96), (50, 80, 180, 255)).save(a / 'second.png')
        owner._folder_snapshot = scan_png_folder(a)
        MonoUI._refresh_selected_output_preview(owner)
        assert owner.preview_title.options['text'] == 'second.png'
        assert owner.preview_sub.options['text'].startswith('72 × 96')

        # Overwrite file, name and status unchanged; thumbnail updates.
        Image.new('RGB', (37, 19), (23, 90, 30)).save(a / 'second.png')
        owner._folder_snapshot = scan_png_folder(a)
        MonoUI._refresh_selected_output_preview(owner)
        assert owner.preview_sub.options['text'].startswith('37 × 19')
        assert len(calls) == 3

        # Old project snapshot cannot leak into the new project.
        owner.project_store.active_id = 'two'
        owner.destination.value = str(b)
        MonoUI._refresh_selected_output_preview(owner)
        assert owner.preview_ref is None
        Image.new('RGBA', (83, 67), 'blue').save(b / 'second.png')
        owner._folder_snapshot = scan_png_folder(b)
        MonoUI._refresh_selected_output_preview(owner)
        assert owner.preview_sub.options['text'].startswith('83 × 67')
        assert len(calls) == 4
        assert first.exists()  # The app never moves or saves output previews.


def test_unreadable_png_does_not_keep_previous_thumbnail(tmp_path):
    folder = tmp_path / 'icons'; folder.mkdir()
    (folder / 'first.png').write_bytes(b'not a valid png')
    owner = FakeOwner(folder)
    MonoUI._refresh_selected_output_preview(owner)
    assert owner.preview_ref is None
    owner.items[0].state = 'corrupt'
    MonoUI._refresh_selected_output_preview(owner)
    assert owner.preview_title.options['text'] == 'first.png'
    assert 'Ảnh bị lỗi' in owner.preview_sub.options['text']
