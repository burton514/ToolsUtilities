import json
import pytest
from project_store import ProjectStore
from imageflow_core import DEFAULTS


def settings(dest="C:/icons/one"):
    return {**DEFAULTS, "destination": dest, "last_source": "C:/icons/list.csv", "last_prompt_column": 3,
            "reference_path": "C:/icons/ref.png"}


def test_legacy_migration_and_persistence(tmp_path):
    file = tmp_path / "projects.json"
    store = ProjectStore(settings(), file)
    assert len(store.projects) == 1
    assert store.active["destination"] == "C:/icons/one"
    assert store.active["last_prompt_column"] == 3
    assert json.loads(file.read_text(encoding="utf-8"))["active_id"] == store.active_id
    assert ProjectStore(settings("C:/other"), file).active["destination"] == "C:/icons/one"


def test_project_isolation_and_switching(tmp_path):
    file = tmp_path / "projects.json"
    store = ProjectStore(settings(), file)
    original = store.active_id
    other = store.add("Veloura", "D:/Veloura/res/drawable")
    store.select(other["id"])
    store.update_active({"last_source": "D:/Veloura/icons.csv", "last_prompt_column": 4,
                         "resize_width": 512, "reference_path": "D:/Veloura/style.png"})
    store.select(original)
    assert store.active["last_source"] == "C:/icons/list.csv"
    assert store.active["reference_path"] == "C:/icons/ref.png"
    assert store.active["resize_width"] == 1024
    reloaded = ProjectStore(settings(), file)
    reloaded.select(other["id"])
    assert reloaded.active["destination"] == "D:/Veloura/res/drawable"
    assert reloaded.active["last_source"] == "D:/Veloura/icons.csv"
    assert reloaded.active["resize_width"] == 512


def test_create_edit_delete_do_not_touch_project_folders(tmp_path):
    store = ProjectStore(settings(), tmp_path / "projects.json")
    root = tmp_path / "project_assets"
    root.mkdir()
    icon = root / "my_icon.png"
    icon.write_bytes(b"keep")
    new = store.add("Alpha", str(root))
    store.edit(new["id"], "Beta", str(root))
    assert store.get(new["id"])["name"] == "Beta"
    with pytest.raises(ValueError, match="trùng tên"):
        store.add("BETA", "D:/stuff")
    store.remove(new["id"])
    assert icon.read_bytes() == b"keep"
    with pytest.raises(ValueError, match="ít nhất một"):
        store.remove(store.active_id)


def test_invalid_registry_recovers_with_legacy(tmp_path):
    file = tmp_path / "projects.json"
    file.write_text("invalid json", encoding="utf-8")
    store = ProjectStore(settings(), file)
    assert len(store.projects) == 1
    assert store.active["destination"] == "C:/icons/one"


def test_duplicate_output_folder_is_rejected(tmp_path):
    store = ProjectStore(settings(), tmp_path / "projects.json")
    with pytest.raises(ValueError, match="thư mục riêng"):
        store.add("Another", "c:\\icons\\one\\")
    first = store.add("Second", "D:/unique")
    with pytest.raises(ValueError, match="thư mục riêng"):
        store.edit(first["id"], "Second", "C:/icons/one")
