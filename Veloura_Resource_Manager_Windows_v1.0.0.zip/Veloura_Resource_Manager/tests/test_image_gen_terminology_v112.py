"""UI-only rename: Image Gen must not break legacy data/MCP contracts."""
import ast
from pathlib import Path

from mcp_stdio import TOOLS
from core_service import CoreService

ROOT = Path(__file__).resolve().parents[1]


def test_user_facing_labels_use_image_gen():
    ui = '\n'.join(p.read_text(encoding='utf-8') for p in (ROOT / 'modern_ui.py', *(ROOT / 'veloura/gui').glob('*.py')))
    app = '\n'.join(p.read_text(encoding='utf-8') for p in (ROOT / 'app.py', *(ROOT / 'veloura/controllers').glob('*.py')))
    for expected in ('Danh sách Image Gen', 'Cột tên Image Gen', 'Tên Image Gen',
                     'Thư viện Image Gen', 'Tổng số Image Gen'):
        assert expected in ui
    for forbidden in ('Danh sách icon', 'Cột tên icon', 'Tên icon',
                      'Gallery icon', 'Tổng số icon', 'Chọn icon để xem'):
        assert forbidden not in ui
    assert 'Chưa chọn Image Gen' in app
    # The obsolete layout which contained this heading was removed;
    # current headers are checked from the active GUI modules above.
    assert 'Gallery icon' not in app


def test_mcp_tool_names_and_parameter_names_unchanged():
    assert len(TOOLS) == 18
    for name in ('veloura_list_icons', 'veloura_get_icon', 'veloura_assign_reference',
                 'veloura_set_review', 'veloura_view_image', 'veloura_import_image'):
        assert name in TOOLS
    for tool in TOOLS.values():
        assert 'icon' not in tool.description.casefold()
    assert 'icon_name' in TOOLS['veloura_import_image'].properties


def test_legacy_excel_column_synonyms_remain_supported():
    # Synonyms are data contracts: existing users' spreadsheets are not renamed.
    source = (ROOT / 'core_service.py').read_text('utf-8')
    assert "'tên icon'" in source
    assert "'icon name'" in source


def test_readme_only_and_merged_mcp_manual():
    docs = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*.md')
                  if not any(part.startswith('.') for part in p.relative_to(ROOT).parts))
    assert docs == ['README_HUONG_DAN.md']
    readme = (ROOT / docs[0]).read_text('utf-8')
    assert 'Agent trên cùng máy Windows' in readme
    assert 'veloura_list_projects' in readme
    assert 'veloura_import_image' in readme
    assert 'MCP_AGENT_SETUP.md' not in readme
    assert not (ROOT / 'MCP_AGENT_SETUP.md').exists()
