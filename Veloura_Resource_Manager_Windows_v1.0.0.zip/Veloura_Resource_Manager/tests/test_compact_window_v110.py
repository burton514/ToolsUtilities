"""Regression tests for the native middle caption button / compact workspace."""
from types import SimpleNamespace
from pathlib import Path

from compact_view import CompactWindowActions
from app import ModernResourceManager


class FakeRoot:
    def __init__(self):
        self.current_state = 'normal'
        self.geometry_value = '1200x800+45+55'
        self.idle = []
        self.later = []

    def state(self, value=None):
        if value is not None:
            self.current_state = value
        return self.current_state

    def geometry(self, value=None):
        if value is not None:
            self.geometry_value = value
        return self.geometry_value

    def winfo_width(self):
        return int(self.geometry_value.split('x')[0])

    def winfo_height(self):
        return int(self.geometry_value.split('x')[1].split('+')[0])

    def after_idle(self, callback):
        self.idle.append(callback)
        return len(self.idle)

    def after(self, milliseconds, callback):
        self.later.append((milliseconds, callback))
        return len(self.later)


class FakeCompact(CompactWindowActions):
    def __init__(self):
        self.root = FakeRoot()
        self._compact_switching = False
        self._compact_active = False
        self._compact_toggle_job = None
        self._closing = False
        self._full_window_geometry = '1200x800+45+55'
        self.enter_count = 0
        self.exit_count = 0

    def _compact_enter(self):
        self.enter_count += 1
        self._compact_active = True
        self.root.state('normal')

    def _compact_exit(self):
        self.exit_count += 1
        self._compact_active = False
        self.root.state('normal')


def test_middle_caption_zoom_state_toggles_compact_twice():
    app = FakeCompact()
    app.root.current_state = 'zoomed'
    app._compact_window_state_changed(SimpleNamespace(widget=app.root))
    assert len(app.root.idle) == 1
    app.root.idle.pop()()
    assert app.enter_count == 1 and app._compact_active
    app.root.current_state = 'zoomed'
    app._compact_window_state_changed(SimpleNamespace(widget=app.root))
    app.root.idle.pop()()
    assert app.exit_count == 1 and not app._compact_active


def test_minimize_does_not_switch_or_shrink_window():
    app = FakeCompact()
    app.root.current_state = 'iconic'
    app._compact_window_state_changed(SimpleNamespace(widget=app.root))
    assert not app.root.idle
    assert not app._compact_active


def test_normal_window_geometry_recorded_before_maximize():
    app = FakeCompact()
    app.root.geometry('1180x770+62+90')
    app._compact_window_state_changed(SimpleNamespace(widget=app.root))
    assert app._full_window_geometry == '1180x770+62+90'


def test_caption_handler_does_not_react_to_child_configure_events():
    app = FakeCompact()
    app.root.current_state = 'zoomed'
    app._compact_window_state_changed(SimpleNamespace(widget=object()))
    assert not app.root.idle


def test_compact_preserves_existing_file_io_logic_and_native_middle_button():
    # Static integration contract: the compact frame delegates all IO to the
    # existing ImageManager rather than implementing parallel disk/clipboard code.
    text = (Path(__file__).resolve().parents[1] / 'compact_view.py').read_text('utf-8')
    for action in ('self.choose_picture', 'self.paste_image_from_clipboard', 'self.on_drop'):
        assert action in text
    assert "state == 'zoomed'" in text
    assert "attributes('-topmost', pinned)" in text
    assert 'resolve_selected_output' in text
    assert ModernResourceManager._build_layout is CompactWindowActions._build_layout
    assert ModernResourceManager._compact_enter is CompactWindowActions._compact_enter
