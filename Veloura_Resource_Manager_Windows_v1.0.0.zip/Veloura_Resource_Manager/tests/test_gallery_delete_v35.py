"""Deleting a Gallery PNG is confirmed, folder-scoped and updates only its card."""
from pathlib import Path
from types import SimpleNamespace

from PIL import Image
import pytest

import app as app_module
from folder_live import scan_png_folder
from modern_ui import MonoUI


class Var:
    def __init__(self, value): self.value = value
    def get(self): return self.value


def make_png(path: Path, color=(4, 55, 100)):
    Image.new('RGBA', (40, 40), color).save(path)


def owner_for_folder(folder):
    snap = scan_png_folder(folder)
    assert snap.available and snap.for_icon('demo')
    state = SimpleNamespace(
        destination=Var(str(folder)),
        project_store=SimpleNamespace(active_id='p1'),
        _folder_snapshot=snap,
        _live_generation=7,
        root=object(),
        items=[app_module.NameItem('demo', 1, state='existing')],
        events=[],
        updates=[],
    )
    state._status=lambda text: state.events.append(text)
    state._on_live_folder_snapshot=lambda gen, s: state.updates.append((gen, s))
    return state


def test_delete_existing_png_updates_single_snapshot_and_preserves_other_files(tmp_path, monkeypatch):
    png = tmp_path / 'demo.png'
    make_png(png)
    other = tmp_path / 'other.png'
    make_png(other)
    unrelated = tmp_path / 'untouched.txt'
    unrelated.write_text('KEEP')
    state = owner_for_folder(tmp_path)
    questions = []
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *a, **kw: questions.append((a,kw)) or True)
    monkeypatch.setattr(app_module.messagebox, 'showwarning', lambda *a, **kw: pytest.fail('Unexpected warning'))
    assert app_module.ImageManager.delete_gallery_png(state, 0, 'demo') is True
    assert not png.exists()
    assert other.exists() and unrelated.read_text() == 'KEEP'
    assert questions[0][1]['icon'] == 'warning'
    assert state.updates[0][0] == 7
    assert state.updates[0][1].for_icon('demo') is None
    assert state.updates[0][1].for_icon('other') is not None


def test_cancel_keeps_png_and_does_not_emit_updates(tmp_path, monkeypatch):
    png = tmp_path / 'demo.png'
    make_png(png)
    state = owner_for_folder(tmp_path)
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *a, **kw: False)
    assert app_module.ImageManager.delete_gallery_png(state, 0, 'demo') is False
    assert png.exists() and not state.updates


def test_changed_png_never_deleted_from_stale_thumbnail(tmp_path, monkeypatch):
    png = tmp_path / 'demo.png'
    make_png(png)
    state = owner_for_folder(tmp_path)
    make_png(png, (205, 98, 4))
    warnings = []
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *a, **kw: True)
    monkeypatch.setattr(app_module.messagebox, 'showwarning', lambda *a, **kw: warnings.append(str(a)))
    assert not app_module.ImageManager.delete_gallery_png(state, 0, 'demo')
    assert png.exists() and not state.updates and warnings


def test_rejects_offline_folder_without_purging_marks(tmp_path, monkeypatch):
    png = tmp_path / 'demo.png'
    make_png(png)
    state = owner_for_folder(tmp_path)
    state._folder_snapshot.available = False
    warnings = []
    monkeypatch.setattr(app_module.messagebox, 'showwarning', lambda *a, **kw: warnings.append(a))
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *a, **kw: pytest.fail('Unexpected confirm'))
    assert not app_module.ImageManager.delete_gallery_png(state, 0, 'demo')
    assert png.exists() and not state.updates and warnings


def test_project_change_while_confirming_prevents_wrong_delete(tmp_path, monkeypatch):
    png = tmp_path / 'demo.png'
    make_png(png)
    state = owner_for_folder(tmp_path)
    def switch(*args, **kwargs):
        state.project_store.active_id = 'another'
        return True
    monkeypatch.setattr(app_module.messagebox, 'askyesno', switch)
    monkeypatch.setattr(app_module.messagebox, 'showwarning', lambda *a, **kw: None)
    assert not app_module.ImageManager.delete_gallery_png(state, 0, 'demo')
    assert png.exists() and not state.updates


def test_rejects_symlink_target(tmp_path, monkeypatch):
    external = tmp_path/'external'
    external.mkdir()
    target = external/'target.png'
    make_png(target)
    images = tmp_path/'images'
    images.mkdir()
    link = images/'demo.png'
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError):
        pytest.skip('Symlinks not supported')
    state = owner_for_folder(images)
    warnings = []
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *a, **kw: True)
    monkeypatch.setattr(app_module.messagebox, 'showwarning', lambda *a, **kw: warnings.append(a))
    assert not app_module.ImageManager.delete_gallery_png(state, 0, 'demo')
    assert target.exists() and link.is_symlink() and warnings


class Card:
    def __init__(self, meta):
        self._gallery_meta = meta
        self._gallery_photo = object()
        self.destroyed = False
        self.grids = []
    def destroy(self): self.destroyed = True
    def grid_configure(self, **kwargs): self.grids.append(kwargs)

class Label:
    def __init__(self, title): self.title = title
    def cget(self, name): return self.title
    def configure(self, **kw): self.title = kw.get('text', self.title)


def test_delete_updates_one_card_without_rebuilding_siblings():
    old = ('p', '/images', 3, 0, '', 'Tất cả',
           ((0, 'one', 'existing', False, False, ('one.png', 13, 10, 0, 2, 'A')),
            (1, 'two', 'existing', False, False, ('two.png', 13, 10, 0, 2, 'B'))))
    updated = ('p', '/images', 3, 0, '', 'Tất cả',
           ((0, 'one', 'pending', False, False, None),
            (1, 'two', 'existing', False, False, ('two.png', 13, 10, 0, 2, 'B'))))
    same_meta = object()
    one, two = Card('old-file'), Card(same_meta)
    old_photo_two = two._gallery_photo
    owner = SimpleNamespace(
        _gallery_render_pending=False,
        _gallery_render_key=old,
        _gallery_card_widgets={(0, 'one'):(one,Label('✓ Đã có ảnh'),one._gallery_photo),
                               (1, 'two'):(two,Label('✓ Đã có ảnh'),old_photo_two)},
        _gallery_empty_widget=None,
        gallery_thumb_refs=[],
        _gallery_can_reconcile_cards=MonoUI._gallery_can_reconcile_cards,
        _gallery_status_text=MonoUI._gallery_status_text,
        _bind_gallery_wheel_children=lambda _:None,
    )
    calls=[]
    def update_card(card, idx, name, meta):
        calls.append((name, meta))
        card._gallery_meta=meta
        card._gallery_photo=None
        return None
    owner._update_gallery_card_image=update_card
    result=MonoUI._reconcile_gallery_cards(owner,
       [(0,'one',None,False,False), (1,'two',same_meta,False,False)],updated,3)
    assert result
    assert calls == [('one',None)]
    assert not one.destroyed and not two.destroyed
    assert owner._gallery_card_widgets[(0, 'one')][2] is None
    assert owner._gallery_card_widgets[(1, 'two')][2] is old_photo_two


def test_source_row_changes_during_confirmation_keeps_png(tmp_path, monkeypatch):
    png = tmp_path / 'demo.png'
    make_png(png)
    state = owner_for_folder(tmp_path)
    def change_source(*args, **kwargs):
        state.items = [app_module.NameItem('renamed', 1)]
        return True
    monkeypatch.setattr(app_module.messagebox, 'askyesno', change_source)
    monkeypatch.setattr(app_module.messagebox, 'showwarning', lambda *a, **kw: None)
    assert not app_module.ImageManager.delete_gallery_png(state, 0, 'demo')
    assert png.exists() and not state.updates
