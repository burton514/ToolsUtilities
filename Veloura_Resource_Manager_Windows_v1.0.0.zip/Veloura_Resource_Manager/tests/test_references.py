from pathlib import Path
from PIL import Image
from reference_library import (unique_paths, enabled_references, set_reference_selection,
                               remove_reference, contact_sheet)


def test_unique_paths():
    assert unique_paths(['a.png','a.png','b.png','','A.PNG']) == ['a.png','b.png']


def test_selection_per_icon_and_remove():
    refs=['ref1.png','ref2.png','ref3.png']
    assignments={}
    assert enabled_references(refs,assignments,'ic_one') == refs
    assignments=set_reference_selection(refs,assignments,'ic_one','ref2.png',False)
    assert enabled_references(refs,assignments,'ic_one') == ['ref1.png','ref3.png']
    assert enabled_references(refs,assignments,'ic_two') == refs
    refs,assignments=remove_reference(refs,assignments,'ref1.png')
    assert refs == ['ref2.png','ref3.png']
    assert enabled_references(refs,assignments,'ic_one') == ['ref3.png']


def test_contact_sheet(tmp_path):
    paths=[]
    for i in range(3):
        path=tmp_path/f'ref{i}.png'
        Image.new('RGBA',(150+i*15,120),(30*i,80,200,255)).save(path)
        paths.append(str(path))
    image=contact_sheet(paths,tile=100,margin=10)
    assert image.mode == 'RGBA'
    assert image.width >= 240 and image.height >= 240
    assert image.getbbox()
    single=contact_sheet(paths[:1])
    assert single.size == (150,120)


def test_legacy_reference_migration(tmp_path):
    from project_store import ProjectStore
    initial={'destination': str(tmp_path/'out'), 'reference_path': str(tmp_path/'old.png')}
    db=ProjectStore(initial, path=tmp_path/'projects.json')
    assert db.active['reference_paths']==[str(tmp_path/'old.png')]
    assert db.active['reference_assignments']=={}
    assert db.active['prompt_template']==''
    db.active['reference_paths']=['ref1.png','ref2.png']
    db.active['reference_assignments']={'icon_a':['ref1.png']}
    db.save()
    reloaded=ProjectStore(initial,path=tmp_path/'projects.json')
    assert reloaded.active['reference_paths']==['ref1.png','ref2.png']
    assert reloaded.active['reference_assignments']['icon_a']==['ref1.png']
