"""Regression tests for the custom source-file browser introduced in v1.4."""
import tempfile
import unittest
from pathlib import Path

from file_picker import SOURCE_EXTENSIONS, list_source_entries, source_file_path
from imageflow_core import normalize_source_path


class SourceChooserTests(unittest.TestCase):
    def test_filter_folders_excel_csv_only(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            (folder / "Z Folder").mkdir()
            for name in ("icon.csv", "anh.xlsx", "other.xlsm", "ignore.jpg", "note.txt"):
                (folder / name).touch()
            self.assertEqual(list_source_entries(folder), [
                ("Z Folder", True), ("anh.xlsx", False),
                ("icon.csv", False), ("other.xlsm", False),
            ])

    def test_direct_selection_accepts_spreadsheet_formats(self):
        with tempfile.TemporaryDirectory() as temp:
            for ext in SOURCE_EXTENSIONS:
                path = Path(temp) / ("TÊN ẢNH" + ext)
                path.touch()
                self.assertEqual(source_file_path(str(path)), path)
                self.assertEqual(source_file_path('"' + str(path) + '"'), path)

    def test_rejects_wrong_extension_or_missing(self):
        with tempfile.TemporaryDirectory() as temp:
            wrong = Path(temp) / "bad.png"
            wrong.touch()
            with self.assertRaises(ValueError):
                source_file_path(str(wrong))
            with self.assertRaises(ValueError):
                source_file_path(str(Path(temp) / "missing.csv"))

    def test_c_drive_prefix_is_normalized_before_windows_browsing(self):
        given = "/C:/Users/Admin/Desktop/Androiddemo/LUMII/LUMII_REFACTOR_V3/design/icon-inventory/danh-sach-icon.csv"
        self.assertEqual(normalize_source_path(given), given[1:])

    def test_csv_can_have_424_names(self):
        from imageflow_core import load_name_source, read_names
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "icons.csv"
            path.write_text('STT,Tên ảnh\n' + '\n'.join(f'{i},ic_icon_{i:03d}' for i in range(1, 425)), encoding='utf-8-sig')
            data = load_name_source(str(path))
            names, duplicated = read_names(data.active, 2, True)
            self.assertEqual((len(names), duplicated), (424, 0))


if __name__ == '__main__':
    unittest.main()
