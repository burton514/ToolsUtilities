"""Filesystem-only output preview follows the icon currently selected."""
from __future__ import annotations
from pathlib import Path
from PIL import Image
from imageflow_core import NameItem
from folder_live import scan_png_folder
from output_preview import resolve_selected_output, preview_identity


def test_preview_points_at_selected_png_and_preserves_filename_case(tmp_path):
    folder = tmp_path / "project_a"
    folder.mkdir()
    a = folder / "Ic_Alpha.PNG"
    b = folder / "ic_beta.png"
    Image.new("RGBA", (128, 128), (0, 99, 220, 255)).save(a)
    Image.new("RGBA", (256, 64), (20, 40, 70, 255)).save(b)
    rows = [NameItem(name="ic_alpha", excel_row=2), NameItem(name="ic_beta", excel_row=3)]
    snap = scan_png_folder(folder)
    assert resolve_selected_output(snap, str(folder), rows, 0).path == a
    assert resolve_selected_output(snap, str(folder), rows, 1).path == b
    assert resolve_selected_output(snap, str(folder), rows, None) is None
    assert resolve_selected_output(snap, str(folder), rows, -1) is None
    assert resolve_selected_output(snap, str(folder), rows, 99) is None


def test_folder_switch_and_deletion_never_use_a_old_project_preview(tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    a.mkdir(); b.mkdir()
    Image.new("RGB", (10, 10)).save(a / "test.png")
    rows = [NameItem(name="test", excel_row=2)]
    snap_a = scan_png_folder(a)
    assert resolve_selected_output(snap_a, str(a), rows, 0) is not None
    assert resolve_selected_output(snap_a, str(b), rows, 0) is None
    snap_b = scan_png_folder(b)
    assert resolve_selected_output(snap_b, str(b), rows, 0) is None
    Image.new("RGB", (8, 8)).save(b / "test.png")
    snap_b = scan_png_folder(b)
    assert resolve_selected_output(snap_b, str(b), rows, 0).path == b / "test.png"
    (b / "test.png").unlink()
    assert resolve_selected_output(scan_png_folder(b), str(b), rows, 0) is None


def test_preview_cache_invalidates_when_png_overwritten_even_if_still_present(tmp_path):
    folder = tmp_path / "images"
    folder.mkdir()
    p = folder / "icon.png"
    Image.new("RGB", (12, 16), "red").save(p)
    rows = [NameItem(name="icon", excel_row=2)]
    snap1 = scan_png_folder(folder)
    key1 = preview_identity("project_one", resolve_selected_output(snap1, str(folder), rows, 0))
    Image.new("RGBA", (23, 19), "blue").save(p)
    snap2 = scan_png_folder(folder)
    key2 = preview_identity("project_one", resolve_selected_output(snap2, str(folder), rows, 0))
    assert key1 != key2
    assert key2 != preview_identity("project_two", resolve_selected_output(snap2, str(folder), rows, 0))
    assert preview_identity("project_two", None) is None


def test_invalid_name_not_previewed_even_if_file_artificially_exists(tmp_path):
    folder = tmp_path / "project"
    folder.mkdir()
    (folder / "icon.png").write_bytes(b"not a real png")
    rows = [NameItem(name="icon", excel_row=2, state="invalid")]
    assert resolve_selected_output(scan_png_folder(folder), str(folder), rows, 0) is None
