"""Copy-Prompt action in the compact name row; reuses Workspace behavior."""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from app import ModernResourceManager
from imageflow_core import NameItem, assemble_prompt


ROOT = Path(__file__).resolve().parents[1]


def test_compact_button_uses_workspace_copy_and_existing_icon():
    source = (ROOT / 'compact_view.py').read_text(encoding='utf-8')
    assert "name_card, 'prompt_copy', self.copy_prompt" in source
    assert "self.compact_copy_prompt_btn.pack(side='right'" in source
    assert (ROOT / 'assets/mono/black/prompt_copy.png').is_file()
    assert ModernResourceManager.copy_prompt.__module__ == 'veloura.gui.workspace'


@pytest.mark.skipif(os.name != 'nt' and not os.environ.get('DISPLAY'),
                    reason='Needs a mapped Windows/X11 desktop')
def test_compact_copy_prompt_current_selection_template_and_long_name(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path))
    app = ModernResourceManager()
    root = app.root
    try:
        root.update()
        long_name = 'image_gen_' + 'sample_' * 35
        app.items = [
            NameItem(name=long_name, excel_row=2, prompt='Vẽ một ngôi sao màu xanh'),
            NameItem(name='second', excel_row=3, prompt='Vẽ một vầng trăng'),
        ]
        app._set_template_text('Tên ảnh: {name}\nYêu cầu: {prompt}')
        app.template_enabled.set(True)
        app.select_by_index(0)
        app._compact_enter()
        root.geometry('310x520+25+25')
        root.update()

        button = app.compact_copy_prompt_btn
        assert button.winfo_ismapped()
        assert button.cget('image') != ''
        assert button.winfo_rootx() + button.winfo_width() <= root.winfo_rootx() + root.winfo_width()
        assert app.compact_name_label.winfo_width() > 30
        assert app._compact_full_name.startswith(long_name)
        assert '…' in app.compact_name_label.cget('text')
        assert button.tooltip_description == 'Sao chép Prompt'

        button.invoke()
        root.update()
        expected = assemble_prompt(app.items[0].prompt, long_name,
                                   app._get_template_text(), True)
        assert root.clipboard_get() == expected

        app._compact_select_next()
        root.update()
        assert app.selected_index == 1
        button.invoke()
        root.update()
        expected = assemble_prompt(app.items[1].prompt, 'second',
                                   app._get_template_text(), True)
        assert root.clipboard_get() == expected

        # The button is still available when returning to the first long name.
        app.select_by_index(0)
        root.update()
        assert button.winfo_ismapped()
    finally:
        if root.winfo_exists():
            app.on_close()


def test_compact_uses_same_prompt_copy_method_as_workspace():
    from compact_view import CompactWindowActions
    # The new button binds to the existing public method; there must be no
    # alternate template/clipboard implementation in CompactWindowActions.
    assert not hasattr(CompactWindowActions, 'copy_prompt')
