"""Regression coverage for streamlined four-field Project management."""
from pathlib import Path
import json
import pytest

from imageflow_core import DEFAULTS
from project_store import ProjectStore


def test_four_fields_round_trip_and_independent_projects(tmp_path):
    store = ProjectStore({**DEFAULTS, 'destination': str(tmp_path / 'old')}, tmp_path / 'projects.json')
    alpha = store.add('Veloura', str(tmp_path / 'veloura'), 'Ảnh app nữ', str(tmp_path / 'veloura.csv'))
    beta = store.add('MediaTool', str(tmp_path / 'media'), '', str(tmp_path / 'media.xlsx'))
    store.edit(alpha['id'], 'Veloura mới', str(tmp_path / 'veloura'), 'Biểu tượng Android', str(tmp_path / 'new.csv'))
    assert store.get(alpha['id'])['description'] == 'Biểu tượng Android'
    assert store.get(alpha['id'])['last_source'] == str(tmp_path / 'new.csv')
    assert store.get(alpha['id'])['last_column'] == 0
    assert store.get(alpha['id'])['last_prompt_column'] == 0
    assert store.get(beta['id'])['description'] == ''
    assert store.get(beta['id'])['last_source'] == str(tmp_path / 'media.xlsx')
    reloaded = ProjectStore(DEFAULTS, tmp_path / 'projects.json')
    assert reloaded.get(alpha['id'])['description'] == 'Biểu tượng Android'
    assert reloaded.get(beta['id'])['destination'] == str(tmp_path / 'media')


def test_edit_does_not_reset_unrelated_settings_or_column_mapping(tmp_path):
    store = ProjectStore(DEFAULTS, tmp_path / 'projects.json')
    other = store.add('Alpha', str(tmp_path / 'alpha'), 'Mô tả', 'a.csv')
    store.select(other['id'])
    store.update_active({'last_column': 2, 'last_prompt_column': 3,
                         'reference_paths': ['ref1.png'], 'resize_width': 512})
    store.edit(other['id'], 'Alpha updated', other['destination'], 'Mô tả sửa', 'a.csv')
    profile = store.get(other['id'])
    assert profile['last_column'] == 2
    assert profile['last_prompt_column'] == 3
    assert profile['resize_width'] == 512
    assert profile['reference_paths'] == ['ref1.png']
    assert profile['description'] == 'Mô tả sửa'


def test_backward_compatibility_existing_registry_without_description(tmp_path):
    path = tmp_path / 'projects.json'
    legacy = {'version': 1, 'active_id': 'old', 'projects': [
        {**DEFAULTS, 'id': 'old', 'name': 'Old Project',
         'destination': str(tmp_path / 'old'), 'last_source': 'old.csv'}]}
    path.write_text(json.dumps(legacy), encoding='utf-8')
    store = ProjectStore(DEFAULTS, path)
    assert store.active['description'] == ''
    assert store.active['last_source'] == 'old.csv'
    store.edit('old', 'Old Project', store.active['destination'], 'Mô tả mới', 'old.csv')
    assert ProjectStore(DEFAULTS, path).active['description'] == 'Mô tả mới'


def test_four_field_validation_requires_selected_existing_file_and_folder(tmp_path):
    from app import ImageManager
    csv = tmp_path / 'icons.csv'
    csv.write_text('Tên icon,Prompt\nic_one,hello\n', encoding='utf-8')
    folder = tmp_path / 'output'
    folder.mkdir()
    value = ImageManager._validate_project_fields(None, '  Project  ', '  ', str(csv), str(folder))
    assert value == ('Project', str(folder), '', str(csv))
    with pytest.raises(ValueError, match='Excel hoặc CSV'):
        ImageManager._validate_project_fields(None, 'Project', '', '', str(folder))
    with pytest.raises(ValueError, match='chưa tồn tại'):
        ImageManager._validate_project_fields(None, 'Project', '', str(csv), str(tmp_path / 'missing'))
    with pytest.raises(ValueError, match='Chỉ hỗ trợ'):
        doc = tmp_path / 'document.txt'
        doc.write_text('x')
        ImageManager._validate_project_fields(None, 'Project', '', str(doc), str(folder))


def test_project_path_pickers_update_readonly_field_variables(monkeypatch, tmp_path):
    from app import ImageManager
    import app
    csv = tmp_path / 'icons.csv'
    csv.write_text('name\ntest\n')
    folder = tmp_path / 'output'
    folder.mkdir()

    class FakeVar:
        def __init__(self): self.value=''
        def get(self): return self.value
        def set(self, new): self.value=new

    var = FakeVar()
    monkeypatch.setattr(app, 'ask_source_file', lambda parent, initial: str(csv))
    ImageManager._browse_project_source(None, object(), var)
    assert var.get() == str(csv)
    monkeypatch.setattr(app.filedialog, 'askdirectory', lambda **kw: str(folder))
    ImageManager._browse_project_folder(None, object(), var)
    assert var.get() == str(folder)
