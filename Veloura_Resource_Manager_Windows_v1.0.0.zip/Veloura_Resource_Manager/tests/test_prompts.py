import csv
import io
import tempfile
import unittest
from pathlib import Path

from PIL import Image
from openpyxl import Workbook

from imageflow_core import load_name_source, get_column_options, read_names_with_prompts
from clipboard_image import image_clipboard_payloads


class PromptMappingTests(unittest.TestCase):
    def test_prompts_same_rows_csv_quoted_multiline_and_duplicate(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'danh-sach.csv'
            with path.open('w', encoding='utf-8-sig', newline='') as f:
                writer = csv.writer(f)
                writer.writerows([
                    ['ID', 'Tên icon', 'Prompt'],
                    [1, 'ic_first', 'Vẽ hoa màu hồng.\nDòng tiếp theo'],
                    [2, 'ic_second.png', 'Tạo icon lông vũ'],
                    [3, 'ic_FIRST', 'Bản trùng phải bỏ'],
                    [4, '', 'Không có tên'],
                    [5, 'ic_third', ''],
                ])
            book = load_name_source(str(path))
            items, duplicates = read_names_with_prompts(book.active, 2, 3, True)
            self.assertEqual([i.name for i in items], ['ic_first', 'ic_second', 'ic_third'])
            self.assertEqual([i.excel_row for i in items], [2, 3, 6])
            self.assertEqual([i.prompt for i in items], ['Vẽ hoa màu hồng.\nDòng tiếp theo', 'Tạo icon lông vũ', ''])
            self.assertEqual(duplicates, 1)

    def test_excel_prompt_column_before_name_and_without_prompt(self):
        book = Workbook()
        sheet = book.active
        sheet.append(['Prompt', 'Mô tả', 'Tên ảnh'])
        sheet.append(['Màu trắng', 'A', 'icon_a'])
        sheet.append(['Màu đen', 'B', 'icon_b'])
        items, duplicates = read_names_with_prompts(sheet, 3, 1, True)
        self.assertEqual([i.prompt for i in items], ['Màu trắng', 'Màu đen'])
        self.assertEqual(duplicates, 0)
        items, _ = read_names_with_prompts(sheet, 3, 0, True)
        self.assertEqual([i.prompt for i in items], ['', ''])

    def test_invalid_column(self):
        book = Workbook()
        with self.assertRaises(ValueError):
            read_names_with_prompts(book.active, 0, 1, False)
        with self.assertRaises(ValueError):
            read_names_with_prompts(book.active, 1, 151, False)

    def test_reference_clipboard_bitmap_and_png_payloads(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'ref.png'
            Image.new('RGBA', (32, 25), (200, 40, 100, 128)).save(path)
            png_data, dib_data = image_clipboard_payloads(path)
            self.assertTrue(png_data.startswith(b'\x89PNG\r\n\x1a\n'))
            self.assertEqual(int.from_bytes(dib_data[:4], 'little'), 40)
            self.assertEqual(Image.open(io.BytesIO(png_data)).size, (32, 25))


if __name__ == '__main__':
    unittest.main()
