"""Quick Workspace: native Windows DND lifecycle + safe output removal."""
from pathlib import Path
from types import SimpleNamespace
import sys

from compact_view import CompactWindowActions
from app import ModernResourceManager


class FakeRoot:
    def __init__(self):
        self.jobs = []
        self.cancelled = []

    def after(self, delay, callback):
        self.jobs.append((delay, callback))
        return len(self.jobs)

    def after_cancel(self, job):
        self.cancelled.append(job)


class FakeTarget:
    def __init__(self, mapped=True):
        self.mapped = mapped
        self.registered = []
        self.unregistered = 0
        self.handlers = {}

    def winfo_ismapped(self):
        return self.mapped

    def drop_target_register(self, *kinds):
        self.registered.append(kinds)

    def drop_target_unregister(self):
        self.unregistered += 1

    def dnd_bind(self, name, callback):
        self.handlers[name] = callback


class QuickWindow(CompactWindowActions):
    def __init__(self):
        self.root = FakeRoot()
        self.compact_drop_canvas = FakeTarget()
        self._compact_drop_targets = (FakeTarget(), self.compact_drop_canvas)
        self._compact_active = True
        self._compact_dnd_job = None
        self._compact_dnd_bound = False
        self._compact_dnd_error = None
        self._compact_pin = SimpleNamespace(get=lambda: True)
        self.paint_count = 0
        self.files = []
        self.drop_events = []
        self.statuses = []

    def _paint_compact_dropzone(self):
        self.paint_count += 1

    def _status(self, text):
        self.statuses.append(text)

    def process_image(self, image):
        self.files.append(image)

    def set_drop_active(self, flag):
        self.drop_events.append(flag)
        return 'copy'

    def on_drop(self, event):
        self.files.append(('explorer', event.data))
        return 'copy'


def test_native_registration_is_deferred_until_compact_window_is_mapped(monkeypatch):
    monkeypatch.setitem(sys.modules, 'tkinterdnd2',
                        SimpleNamespace(DND_FILES='DND_Files', DND_TEXT='DND_Text'))
    app = QuickWindow()
    app.compact_drop_canvas.mapped = False
    app._compact_schedule_dnd_registration()
    assert app.root.jobs[0][0] == 120
    app.root.jobs.pop(0)[1]()
    assert not app.compact_drop_canvas.registered
    app.compact_drop_canvas.mapped = True
    app.root.jobs.pop(0)[1]()
    for widget in app._compact_drop_targets:
        assert widget.registered == [('DND_Files', 'DND_Text')]
        assert set(widget.handlers) == {'<<DropEnter>>', '<<DropLeave>>', '<<DropPosition>>', '<<Drop>>'}
    assert app._compact_dnd_bound
    assert app._compact_dnd_error is None


def test_reregister_after_pin_does_not_install_duplicate_callbacks(monkeypatch):
    monkeypatch.setitem(sys.modules, 'tkinterdnd2',
                        SimpleNamespace(DND_FILES='DND_Files', DND_TEXT='DND_Text'))
    app = QuickWindow()
    app._compact_activate_drop_targets()
    app._compact_schedule_dnd_registration()
    app.root.jobs.pop(0)[1]()
    for target in app._compact_drop_targets:
        assert target.unregistered == 1
        assert len(target.registered) == 2
        assert len(target.handlers) == 4
    assert app._compact_dnd_bound


def test_native_drop_file_from_explorer_passes_to_existing_export():
    app = QuickWindow()
    assert app._compact_on_drop(SimpleNamespace(data='{C:/Images/My photo.png}')) == 'copy'
    assert app.files == [('explorer', '{C:/Images/My photo.png}')]
    assert app.drop_events[-1] is False


def test_local_file_drop_accepts_plain_path_with_spaces(tmp_path):
    app = QuickWindow()
    path = tmp_path / 'My image.png'
    path.write_bytes(b'png')
    assert app._compact_on_drop(SimpleNamespace(data=str(path))) == 'copy'
    assert app.files == [path]


def test_file_uri_drop_is_local_not_network(tmp_path):
    app = QuickWindow()
    path = tmp_path / 'Photo with space.png'
    path.write_bytes(b'png')
    assert app._compact_on_drop(SimpleNamespace(data=path.as_uri())) == 'copy'
    assert app.files == [path]


def test_browser_url_drop_does_not_download_or_process(monkeypatch):
    from compact_view import messagebox
    warnings = []
    monkeypatch.setattr(messagebox, 'showinfo', lambda *a, **kw: warnings.append(a))
    app = QuickWindow()
    assert app._compact_on_drop(SimpleNamespace(data='https://example.com/image.png')) == 'copy'
    assert not app.files
    assert warnings and 'Ctrl+V' in warnings[0][1]


def test_missing_tkdnd_is_visible_instead_of_silent(monkeypatch):
    monkeypatch.setitem(sys.modules, 'tkinterdnd2', None)
    app = QuickWindow()
    app._compact_activate_drop_targets()
    assert app._compact_dnd_error
    assert not app._compact_dnd_bound
    assert app.statuses and 'Ctrl+V' in app.statuses[-1]


def test_compact_delete_delegates_to_gallery_safe_deletion():
    app = QuickWindow()
    app.selected_index = 1
    app.items = [SimpleNamespace(name='other'), SimpleNamespace(name='current')]
    app.processing = False
    calls = []
    app.delete_gallery_png = lambda idx, name, **kwargs: calls.append((idx, name, kwargs)) or True
    assert app._compact_delete_output() is True
    assert calls == [(1, 'current', {'confirm': False, 'accept_updated': True})]
    app.processing = True
    # Test no state mutation on processing; patch dialog to avoid a Tk root.
    import compact_view
    original = compact_view.messagebox.showinfo
    compact_view.messagebox.showinfo = lambda *a, **k: None
    try:
        assert app._compact_delete_output() is False
    finally:
        compact_view.messagebox.showinfo = original
    assert calls == [(1, 'current', {'confirm': False, 'accept_updated': True})]


def test_public_app_routes_new_compact_callbacks():
    assert ModernResourceManager._compact_activate_drop_targets is CompactWindowActions._compact_activate_drop_targets
    assert ModernResourceManager._compact_on_drop is CompactWindowActions._compact_on_drop
    assert ModernResourceManager._compact_delete_output is CompactWindowActions._compact_delete_output
    text = (Path(__file__).resolve().parents[1] / 'compact_view.py').read_text('utf-8')
    assert "icon_name='image_remove'" in text
    assert 'confirm=False, accept_updated=True' in text
