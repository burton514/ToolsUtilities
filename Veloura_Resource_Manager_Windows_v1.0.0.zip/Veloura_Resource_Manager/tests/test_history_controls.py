"""History actions must be bounded, project-scoped, and never touch image files."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

import app as app_module
from app import ImageManager
from modern_ui import MonoUI


def make_fake_history(tmp_path, entries=2):
    active_id = 'project_A'
    shared = [{'Tên ảnh': f'icon_{i}', 'Kết quả': 'Thành công'} for i in range(entries)]
    other = [{'Tên ảnh': 'other_icon', 'Kết quả': 'Thành công'}]
    png_file = tmp_path/'icon_0.png'
    png_file.write_bytes(b'keep this file')
    project_store = SimpleNamespace(active_id=active_id)
    fake = SimpleNamespace(logs=shared, project_logs={active_id:shared, 'project_B':other},
                           project_store=project_store, root=object(),
                           activity=MagicMock(), _status=MagicMock(),
                           _refresh_history_page=MagicMock())
    fake._clear_activity_text = lambda: ImageManager._clear_activity_text(fake)
    return fake, png_file, other


def test_clear_history_clears_only_current_project_and_workspace(tmp_path, monkeypatch):
    fake, png, other = make_fake_history(tmp_path)
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *args, **kwargs: True)
    assert ImageManager.clear_history(fake) is True
    assert fake.logs == []
    assert fake.project_logs['project_A'] is fake.logs
    assert fake.project_logs['project_B'] is other and len(other)==1
    assert png.read_bytes() == b'keep this file'
    fake.activity.delete.assert_called_with('1.0', 'end')
    fake.activity.insert.assert_called()
    fake._refresh_history_page.assert_called_once()


def test_clear_history_cancellation_does_not_mutate(tmp_path, monkeypatch):
    fake, png, other = make_fake_history(tmp_path)
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *args, **kwargs: False)
    assert ImageManager.clear_history(fake) is False
    assert len(fake.logs) == 2
    assert len(other)==1
    assert png.is_file()
    fake.activity.delete.assert_not_called()
    fake._refresh_history_page.assert_not_called()


def test_clear_empty_history_is_safe(tmp_path, monkeypatch):
    fake, _, _ = make_fake_history(tmp_path, entries=0)
    monkeypatch.setattr(app_module.messagebox, 'askyesno', lambda *args, **kwargs: pytest.fail('must not confirm empty history'))
    assert ImageManager.clear_history(fake) is False
    fake.activity.delete.assert_called_once()
    fake._refresh_history_page.assert_called_once()


def test_refresh_history_only_renders_in_memory(tmp_path):
    fake, png, _ = make_fake_history(tmp_path)
    ImageManager.refresh_history(fake)
    fake._refresh_history_page.assert_called_once()
    assert len(fake.logs)==2 and png.exists()
    fake._status.assert_called_once()


def test_history_buttons_are_in_history_page_and_use_handlers():
    code = MonoUI._refresh_history_page.__code__
    assert 'clear_history' in code.co_names
    assert 'refresh_history' in code.co_names
    assert 'export_logs' in code.co_names


def test_activity_text_buffer_has_upper_bound():
    app = Path(__file__).resolve().parents[1]/'veloura/controllers/activity.py'
    source = app.read_text(encoding='utf-8')
    assert 'if len(self.logs) > 300:' in source
    assert 'if last_line > 35:' in source
