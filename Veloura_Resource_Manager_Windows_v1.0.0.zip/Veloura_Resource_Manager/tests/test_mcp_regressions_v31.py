"""Reproduce four findings from the independent v3.0 audit.

All files and subprocesses use isolated temporary directories, never the
user's real Veloura registry or project PNGs.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pytest
from PIL import Image

from core_service import CoreService
from imageflow_core import DEFAULTS
from mcp_stdio import MCPServer, TOOLS
from project_store import ProjectStore


def test_first_run_is_atomic_across_independent_processes(tmp_path):
    registry = tmp_path / 'config' / 'projects.json'
    barrier = tmp_path / 'begin'
    script = r'''
import json, sys, time
from pathlib import Path
from project_store import ProjectStore
from imageflow_core import DEFAULTS
registry, ready_dir, barrier, number = map(Path, sys.argv[1:])
(ready_dir / ('ready_' + str(number))).write_text('ready')
while not barrier.exists():
    time.sleep(.005)
store = ProjectStore({**DEFAULTS, 'destination': str(registry.parent / 'images')}, registry)
print(json.dumps({'active_id': store.active_id, 'ids': [p['id'] for p in store.projects]}))
'''
    env = os.environ.copy()
    project_root = str(Path(__file__).resolve().parents[1])
    env['PYTHONPATH'] = project_root + os.pathsep + env.get('PYTHONPATH', '')
    workers = 8
    processes = [subprocess.Popen([sys.executable, '-c', script, str(registry), str(tmp_path),
                                   str(barrier), str(index)], stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, text=True, env=env)
                 for index in range(workers)]
    try:
        deadline = time.monotonic() + 15
        while len(list(tmp_path.glob('ready_*'))) < workers and time.monotonic() < deadline:
            time.sleep(.02)
        assert len(list(tmp_path.glob('ready_*'))) == workers
        barrier.touch()
        answers = []
        for proc in processes:
            out, err = proc.communicate(timeout=20)
            assert proc.returncode == 0, err
            answers.append(json.loads(out.strip()))
        assert len({answer['active_id'] for answer in answers}) == 1
        assert all(answer['ids'] == [answers[0]['active_id']] for answer in answers)
        saved = json.loads(registry.read_text(encoding='utf-8'))
        assert len(saved['projects']) == 1
        assert saved['active_id'] == answers[0]['active_id']
    finally:
        for proc in processes:
            if proc.poll() is None:
                proc.kill()
                proc.communicate()


def _service_with_project(tmp_path):
    out = tmp_path / 'icons'; out.mkdir()
    spreadsheet = tmp_path / 'icons.csv'
    spreadsheet.write_text('STT,Tên icon,Prompt\n1,ic_alpha,Create round icon\n', encoding='utf-8-sig')
    registry = tmp_path / 'config' / 'projects.json'
    service = CoreService(registry)
    project = service.create_project('Project test', str(spreadsheet), str(out))['created']
    image = tmp_path / 'image.png'
    Image.new('RGBA', (32, 32), 'red').save(image)
    return service, project['id'], spreadsheet, out, image, registry


def test_blank_project_id_cannot_redirect_mcp_writes(tmp_path):
    service, project_id, csv, folder, image, registry = _service_with_project(tmp_path)
    server = MCPServer(service)
    server.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {}})
    server.handle({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
    calls = {
        'veloura_update_project': {'name': 'Changed'},
        'veloura_delete_project': {'confirm': True},
        'veloura_set_source_columns': {'name_column': 2},
        'veloura_add_reference': {'image_path': str(image)},
        'veloura_assign_reference': {'icon_name': 'ic_alpha', 'image_path': str(image), 'selected': True},
        'veloura_set_review': {'icon_name': 'ic_alpha', 'enabled': True},
        'veloura_import_image': {'icon_name': 'ic_alpha', 'image_path': str(image)},
        'veloura_rename_png': {'old_name': 'ic_alpha', 'new_name': 'ic_alpha_renamed'},
    }
    assert len(calls) == 8
    assert set(calls).issubset(TOOLS)
    before = registry.read_bytes()
    for name, args in calls.items():
        for invalid_id in ('', '   ', '\t'):
            response = server.handle({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call',
                                      'params': {'name': name, 'arguments': {'project_id': invalid_id, **args}}})
            assert response['error']['code'] == -32602, (name, invalid_id, response)
    assert registry.read_bytes() == before
    assert not list(folder.glob('*.png'))
    with pytest.raises(ValueError, match='project_id'):
        service.import_image('', 'ic_alpha', str(image))
    with pytest.raises(ValueError, match='project_id'):
        service.get_project('')
    # Omitting an ID on read-only tools still works normally.
    assert service.get_project()['project']['name'] == 'Project mặc định'
    assert service.get_icon('ic_alpha', project_id)['name'] == 'ic_alpha'
    assert TOOLS['veloura_import_image'].properties['project_id']['minLength'] == 1


def test_new_mcp_project_infers_prompt_and_preserves_explicit_disable(tmp_path):
    service, project_id, csv, folder, image, registry = _service_with_project(tmp_path)
    profile = ProjectStore(DEFAULTS, registry).get(project_id)
    assert profile['last_column'] == 2
    assert profile['last_prompt_column'] == 3
    assert profile['last_sheet'] == 'Dữ liệu CSV'
    assert service.get_icon('ic_alpha', project_id)['prompt'] == 'Create round icon'
    service.set_source_columns(project_id, name_column=2, prompt_column=0)
    assert service.get_icon('ic_alpha', project_id)['prompt'] == ''
    assert ProjectStore(DEFAULTS, registry).get(project_id)['last_prompt_column'] == 0
    newer_csv = tmp_path / 'more.csv'
    newer_csv.write_text('File name,Promt\nother_icon,Second prompt\n', encoding='utf-8')
    service.update_project(project_id, source_file=str(newer_csv))
    assert service.get_icon('other_icon', project_id)['prompt'] == 'Second prompt'
    assert ProjectStore(DEFAULTS, registry).get(project_id)['last_prompt_column'] == 2


def test_mcp_rejects_invalid_params_and_arguments_shapes(tmp_path):
    service, pid, *_ = _service_with_project(tmp_path)
    server = MCPServer(service)
    server.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {}})
    server.handle({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
    for bad in ([], '', 'abc', 1, True, None):
        response = server.handle({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': bad})
        assert response['error']['code'] == -32602, response
        response = server.handle({'jsonrpc': '2.0', 'id': 2, 'method': 'initialize', 'params': bad})
        assert response['error']['code'] == -32602, response
    for bad_args in ([], None, 'oops', 10, False):
        response = server.handle({'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call',
                                  'params': {'name': 'veloura_list_projects', 'arguments': bad_args}})
        assert response['error']['code'] == -32602, response
    valid = server.handle({'jsonrpc': '2.0', 'id': 4, 'method': 'tools/call',
                           'params': {'name': 'veloura_list_projects'}})
    assert valid['result']['isError'] is False
    assert len(valid['result']['structuredContent']['projects']) >= 1
