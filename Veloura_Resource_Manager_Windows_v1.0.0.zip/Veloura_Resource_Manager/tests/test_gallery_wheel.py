"""Regression: mouse wheel above thumbnail and card controls scrolls Gallery.

Unit tests do not require a display; the Tk event integration is smoke-tested
separately with Xvfb/Windows.
"""
from types import SimpleNamespace

from modern_ui import MonoUI


class FakeCanvas:
    def __init__(self, viewable=True):
        self.calls = []
        self.viewable = viewable

    def winfo_viewable(self):
        return self.viewable

    def yview_scroll(self, amount, unit):
        self.calls.append((amount, unit))


class FakeOwner:
    def __init__(self, page='gallery', viewable=True):
        self.current_page = page
        self.gallery_canvas = FakeCanvas(viewable=viewable)


def test_windows_mousewheel_forwarded_from_card():
    owner = FakeOwner()
    assert MonoUI._gallery_mouse_wheel(owner, SimpleNamespace(delta=-120, num='??')) == 'break'
    assert MonoUI._gallery_mouse_wheel(owner, SimpleNamespace(delta=240, num='??')) == 'break'
    assert owner.gallery_canvas.calls == [(1, 'units'), (-2, 'units')]


def test_high_resolution_touchpad_small_delta_is_not_ignored():
    owner = FakeOwner()
    assert MonoUI._gallery_mouse_wheel(owner, SimpleNamespace(delta=-30, num='??')) == 'break'
    assert owner.gallery_canvas.calls == [(1, 'units')]


def test_x11_mousewheel_forwarded_from_card():
    owner = FakeOwner()
    MonoUI._gallery_mouse_wheel(owner, SimpleNamespace(delta=0, num=4))
    MonoUI._gallery_mouse_wheel(owner, SimpleNamespace(delta=0, num=5))
    assert owner.gallery_canvas.calls == [(-1, 'units'), (1, 'units')]


def test_gallery_wheel_does_not_affect_other_pages():
    owner = FakeOwner(page='workspace')
    assert MonoUI._gallery_mouse_wheel(owner, SimpleNamespace(delta=-120, num='??')) is None
    assert not owner.gallery_canvas.calls


def test_unmapped_gallery_wheel_does_not_affect_gallery():
    owner = FakeOwner(viewable=False)
    assert MonoUI._gallery_mouse_wheel(owner, SimpleNamespace(delta=-120, num='??')) is None
    assert not owner.gallery_canvas.calls


class FakeWidget:
    def __init__(self, *children):
        self.children = children
        self.binds = []

    def winfo_children(self):
        return self.children

    def bind(self, sequence, callback, add=None):
        self.binds.append((sequence, callback, add))


def test_dynamically_created_card_descendants_receive_wheel_handlers():
    image = FakeWidget()
    title = FakeWidget()
    action = FakeWidget()
    card = FakeWidget(FakeWidget(image, title), FakeWidget(action))
    owner = FakeOwner()
    owner._gallery_mouse_wheel = MonoUI._gallery_mouse_wheel.__get__(owner, FakeOwner)
    owner._bind_gallery_wheel_children = MonoUI._bind_gallery_wheel_children.__get__(owner, FakeOwner)
    MonoUI._bind_gallery_wheel_children(owner, card)
    assert not card.binds  # card isn't a descendant of itself
    for child in (image, title, action):
        assert {entry[0] for entry in child.binds} == {
            '<MouseWheel>', '<Button-4>', '<Button-5>'
        }
        assert all(entry[2] == '+' for entry in child.binds)
