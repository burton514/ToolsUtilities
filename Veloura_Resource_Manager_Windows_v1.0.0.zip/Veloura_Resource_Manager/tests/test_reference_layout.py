"""Regression for the thumbnail shelf not being covered by its scrollbar."""

from modern_ui import MonoUI


class FakeTiles:
    def __init__(self, required_width):
        self.required_width = required_width

    def winfo_reqwidth(self):
        return self.required_width


class FakeScrollbar:
    def __init__(self):
        self.visible = False
        self.calls = []

    def winfo_manager(self):
        return 'pack' if self.visible else ''

    def pack(self, **kwargs):
        self.visible = True
        self.calls.append(('show', kwargs))

    def pack_forget(self):
        self.visible = False
        self.calls.append(('hide', {}))


class FakeCanvas:
    def __init__(self, width):
        self.width = width
        self.calls = []

    def bbox(self, what):
        assert what == 'all'
        return (0, 0, 400, 100)

    def configure(self, **kwargs):
        self.calls.append(('config', kwargs))

    def winfo_width(self):
        return self.width

    def xview_moveto(self, value):
        self.calls.append(('move', value))


class FakeOwner:
    def __init__(self, available=340, required=180):
        self.ref_scroll_canvas = FakeCanvas(available)
        self.ref_tiles = FakeTiles(required)
        self.ref_horizontal_scroll = FakeScrollbar()
        self.ref_controls = object()


def test_scrollbar_is_hidden_when_two_thumbnails_fit():
    owner = FakeOwner(available=340, required=180)
    MonoUI._update_reference_scroll_region(owner)
    assert not owner.ref_horizontal_scroll.visible
    assert owner.ref_horizontal_scroll.calls == []


def test_scrollbar_shows_below_shelf_when_images_overflow_then_hides():
    owner = FakeOwner(available=240, required=680)
    MonoUI._update_reference_scroll_region(owner)
    assert owner.ref_horizontal_scroll.visible
    how, props = owner.ref_horizontal_scroll.calls[-1]
    assert how == 'show'
    assert props['before'] is owner.ref_controls
    assert props['fill'] == 'x'
    owner.ref_tiles.required_width = 185
    MonoUI._update_reference_scroll_region(owner)
    assert not owner.ref_horizontal_scroll.visible
    assert ('move', 0) in owner.ref_scroll_canvas.calls
