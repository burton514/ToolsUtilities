"""Regressions for spreadsheet refresh, disconnected folders, and same-metadata PNG rewrites."""
from __future__ import annotations

import os
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import pytest
from PIL import Image

from app import ImageManager
from core_service import CoreService
from folder_live import scan_png_folder
from imageflow_core import DEFAULTS, NameItem
from output_preview import preview_identity
from project_store import ProjectStore
from ui_thumbnail_cache import ThumbnailCache


def _png(path, color):
    Image.new('RGB', (16, 16), color).save(path)


def test_project_sync_checks_csv_even_when_registry_is_unchanged():
    calls = []
    root = SimpleNamespace(focus_get=lambda: None,
                           after=lambda timeout, cb: calls.append(('timer', timeout)))
    fake = SimpleNamespace(_sync_project_task=None, _closing=False,
                           processing=False, _changing_project=False,
                           save_task=None, root=root, _sync_project_registry=lambda: None,
                           project_store=SimpleNamespace(active={}, sync_from_disk=lambda: False),
                           _reload_source_if_changed=lambda: calls.append('source'),
                           _status=lambda message: calls.append(message))
    ImageManager._sync_project_registry(fake)
    ImageManager._sync_project_registry(fake)
    assert calls.count('source') == 2
    assert calls.count(('timer', 2800)) == 2


def test_project_sync_skips_source_refresh_during_text_edit():
    calls = []
    focus = SimpleNamespace(winfo_class=lambda: 'TEntry')
    root = SimpleNamespace(focus_get=lambda: focus, after=lambda ms, cb: None)
    fake = SimpleNamespace(_sync_project_task=None, _closing=False,
                           processing=False, _changing_project=False, save_task=None,
                           root=root, _sync_project_registry=lambda: None,
                           _reload_source_if_changed=lambda: calls.append('called'))
    ImageManager._sync_project_registry(fake)
    assert not calls


def test_offline_folder_is_not_equivalent_to_deleted_png(tmp_path):
    folder = tmp_path / 'output'; folder.mkdir()
    _png(folder / 'first.png', 'red')
    good = scan_png_folder(folder)
    assert good.available and good.for_icon('first') is not None
    other = tmp_path / 'offline'
    folder.rename(other)
    missing = scan_png_folder(folder, previous=good)
    assert not missing.available and not missing.files
    store_marks = []
    fake = SimpleNamespace(items=[NameItem('first', 2)], review_marks={'first'},
                           _folder_snapshot=good,
                           _store_review_marks=lambda persist=True: store_marks.append('saved'))
    assert ImageManager._prune_review_marks(fake, missing) is False
    assert fake.review_marks == {'first'} and store_marks == []
    other.rename(folder)
    restored = scan_png_folder(folder, previous=missing)
    assert restored.available and restored.for_icon('first') is not None
    assert ImageManager._prune_review_marks(fake, restored) is False


def test_real_deletion_in_accessible_folder_still_clears_review(tmp_path):
    folder = tmp_path / 'output'; folder.mkdir()
    _png(folder / 'first.png', 'red')
    old = scan_png_folder(folder)
    (folder / 'first.png').unlink()
    new = scan_png_folder(folder, previous=old)
    assert new.available and not new.files
    calls = []
    fake = SimpleNamespace(items=[NameItem('first', 2)], review_marks={'first'},
                           _folder_snapshot=old,
                           _store_review_marks=lambda persist=True: calls.append('saved'))
    assert ImageManager._prune_review_marks(fake, new) is True
    assert not fake.review_marks and calls == ['saved']


def test_agent_preserves_review_marks_during_disconnect(tmp_path):
    folder = tmp_path / 'png'; folder.mkdir()
    source = tmp_path / 'names.csv'
    source.write_text('Tên icon,Prompt\nfirst,OK\n', encoding='utf-8-sig')
    registry = tmp_path / 'settings' / 'projects.json'
    service = CoreService(registry)
    project = service.create_project('Sample', str(source), str(folder))['created']
    pid = project['id']
    _png(folder / 'first.png', 'red')
    assert service.set_review(pid, 'first', True)['needs_review']
    offline = tmp_path / 'disconnected'
    folder.rename(offline)
    with pytest.raises(OSError, match='không truy cập'):
        service.scan_project(pid)
    assert ProjectStore(DEFAULTS, registry).get(pid)['review_marks'] == ['first']
    offline.rename(folder)
    assert service.scan_project(pid)['counts']['needs_review'] == 1
    assert ProjectStore(DEFAULTS, registry).get(pid)['review_marks'] == ['first']
    (folder / 'first.png').unlink()
    service.scan_project(pid)
    assert ProjectStore(DEFAULTS, registry).get(pid)['review_marks'] == []


def test_same_size_restored_mtime_image_refresh_detects_contents(tmp_path):
    path = tmp_path / 'same.png'
    Image.new('RGBA', (16, 16), (255, 0, 0)).save(path)
    first = scan_png_folder(tmp_path)
    old = first.for_icon('same')
    assert old is not None and old.content_digest
    original_stat = path.stat()
    Image.new('RGBA', (16, 16), (0, 0, 255)).save(path)
    assert path.stat().st_size == original_stat.st_size
    os.utime(path, ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns))
    # Simulate Windows filesystems that preserve birth/change-time as well:
    # metadata alone cannot prove whether the actual bytes changed.
    new_change_ns = path.stat().st_ctime_ns
    first.files['same.png'] = replace(old, change_ns=new_change_ns)
    unchanged = scan_png_folder(tmp_path, previous=first)
    assert unchanged.files == first.files  # deliberate metadata-only fast path
    refreshed = scan_png_folder(tmp_path, previous=first, check_contents=True)
    updated = refreshed.for_icon('same')
    assert updated.content_digest != old.content_digest
    assert preview_identity('test', updated) != preview_identity('test', old)
    cache = ThumbnailCache(3)
    calls = []
    def factory():
        calls.append(True)
        return object()
    cache.get(path, (64, 64), (old.content_digest,), factory)
    cache.get(path, (64, 64), (updated.content_digest,), factory)
    assert len(calls) == 2 and len(cache) == 1


def test_folder_with_no_output_path_is_not_available():
    assert not scan_png_folder('').available


def test_native_watcher_event_requests_content_check(tmp_path, monkeypatch):
    """A coarse native event must not trust metadata-only snapshots."""
    import queue
    import threading
    import time
    import folder_live
    from folder_live import FolderLiveMonitor

    output = tmp_path / 'out'; output.mkdir()
    _png(output / 'first.png', 'blue')
    requested = []
    original = folder_live.scan_png_folder

    def scan_spy(*args, **kwargs):
        requested.append(bool(kwargs.get('check_contents', False)))
        return original(*args, **kwargs)

    class Watcher:
        def __init__(self, folder):
            self.signal = threading.Event()
            self.closed = False
        def wait(self, timeout):
            hit = self.signal.wait(timeout)
            if hit: self.signal.clear()
            return hit
        def close(self):
            self.closed = True
            self.signal.set()

    watcher = Watcher(str(output))
    received = queue.Queue()
    monkeypatch.setattr(folder_live, 'scan_png_folder', scan_spy)
    monitor = FolderLiveMonitor(lambda gen, snap: received.put(snap), interval=0.2,
                                reconcile_interval=30,
                                watcher_factory=lambda path: watcher)
    try:
        monitor.watch(str(output))
        received.get(timeout=4)
        assert requested == [False]
        _png(output / 'second.png', 'red')
        watcher.signal.set()
        received.get(timeout=5)
        assert True in requested[1:]
    finally:
        monitor.stop()
