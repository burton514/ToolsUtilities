"""A review-state toggle is an in-place update, never a Gallery card reload."""
from types import SimpleNamespace

from modern_ui import MonoUI


class DummyCard:
    def __init__(self):
        self.destroyed = False
        self.moved_to = []
    def destroy(self):
        self.destroyed = True
    def grid_configure(self, **kwargs):
        self.moved_to.append(kwargs)


class DummyLabel:
    def __init__(self, text):
        self.text = text
        self.updated = []
    def cget(self, option):
        assert option == 'text'
        return self.text
    def configure(self, **kwargs):
        self.updated.append(kwargs)
        self.text = kwargs.get('text', self.text)


class DummyEmpty:
    def __init__(self):
        self.destroyed = False
        self.packed = False
    def destroy(self):
        self.destroyed = True
    def pack(self, **kwargs):
        self.packed = True


# Each row: index, name, state, reviewed, corrupt, file metadata.
def row(index, name, review=False, signature=None):
    return (index, name, 'review' if review else 'existing', review, False,
            signature if signature is not None else (name + '.png', 99, 100, 1, 2, 'digest'))


def fingerprint(*rows, project='p', mode='Tất cả'):
    return (project, '/out', 3, 0, '', mode, tuple(rows))


def fake_view(previous):
    owner = SimpleNamespace(
        _gallery_render_pending=False,
        _gallery_render_key=previous,
        _gallery_card_widgets={},
        _gallery_empty_widget=None,
        gallery_thumb_refs=[],
        gallery_inner=object(),
        _gallery_can_reconcile_cards=MonoUI._gallery_can_reconcile_cards,
        _gallery_status_text=MonoUI._gallery_status_text,
        _bind_gallery_wheel_children=lambda _: None,
    )
    owner._make_gallery_card = lambda pos, entry, columns: (DummyCard(), DummyLabel('✓ Đã có ảnh'), object())
    owner.txt = lambda *args, **kwargs: DummyEmpty()
    return owner


def test_status_change_preserves_all_cards_photo_refs_and_scroll():
    old = fingerprint(row(0, 'a'), row(1, 'b'), row(2, 'c'))
    owner = fake_view(old)
    a = DummyCard(); b = DummyCard(); c = DummyCard()
    la = DummyLabel('✓ Đã có ảnh'); lb = DummyLabel('✓ Đã có ảnh'); lc = DummyLabel('✓ Đã có ảnh')
    photos = [object(), object(), object()]
    owner._gallery_card_widgets = {(0, 'a'): (a, la, photos[0]),
                                   (1, 'b'): (b, lb, photos[1]),
                                   (2, 'c'): (c, lc, photos[2])}
    new = fingerprint(row(0, 'a'), row(1, 'b', review=True), row(2, 'c'))
    page = [(0, 'a', object(), False, False),
            (1, 'b', object(), True, False),
            (2, 'c', object(), False, False)]
    assert MonoUI._reconcile_gallery_cards(owner, page, new, 3)
    assert owner._gallery_render_key == new
    assert owner._gallery_card_widgets[(1, 'b')][0] is b
    assert not any(card.destroyed for card in (a, b, c))
    assert lb.text == '◉ Cần xem xét'
    assert la.updated == [] and lc.updated == []
    assert set(owner.gallery_thumb_refs) == set(photos)


def test_review_filter_removes_only_one_card_and_reflows_survivors():
    old = fingerprint(row(0, 'a', True), row(1, 'b', True), row(2, 'c', True), mode='Cần xem xét')
    owner = fake_view(old)
    a = DummyCard(); b = DummyCard(); c = DummyCard()
    owner._gallery_card_widgets = {(0, 'a'): (a, DummyLabel('◉ Cần xem xét'), object()),
                                   (1, 'b'): (b, DummyLabel('◉ Cần xem xét'), object()),
                                   (2, 'c'): (c, DummyLabel('◉ Cần xem xét'), object())}
    new = fingerprint(row(0, 'a', True), row(2, 'c', True), mode='Cần xem xét')
    meta = object()
    assert MonoUI._reconcile_gallery_cards(owner,
        [(0, 'a', meta, True, False), (2, 'c', meta, True, False)], new, 3)
    assert b.destroyed and not a.destroyed and not c.destroyed
    assert len(owner._gallery_card_widgets) == 2
    assert c.moved_to[-1] == {'row': 0, 'column': 1}


def test_review_filter_adds_only_one_card():
    old = fingerprint(row(0, 'a', True), mode='Cần xem xét')
    owner = fake_view(old)
    a = DummyCard()
    owner._gallery_card_widgets = {(0, 'a'): (a, DummyLabel('◉ Cần xem xét'), object())}
    new = fingerprint(row(0, 'a', True), row(1, 'b', True), mode='Cần xem xét')
    meta = object()
    assert MonoUI._reconcile_gallery_cards(owner,
        [(0, 'a', meta, True, False), (1, 'b', meta, True, False)], new, 3)
    assert owner._gallery_card_widgets[(0, 'a')][0] is a
    assert len(owner._gallery_card_widgets) == 2
    assert not a.destroyed


def test_png_changes_reconcile_in_place_but_project_switch_rebuilds():
    old = fingerprint(row(0, 'a'))
    changed_meta = fingerprint(row(0, 'a', signature=('a.png', 99, 100, 1, 2, 'NEW')))
    assert MonoUI._gallery_can_reconcile_cards(old, changed_meta)
    assert not MonoUI._gallery_can_reconcile_cards(old, fingerprint(row(0, 'a'), project='other'))
    assert MonoUI._gallery_can_reconcile_cards(old, fingerprint(row(0, 'a', True)))
