"""Release metadata is consistent across GUI, MCP, docs and Windows EXEs."""
import ast
from pathlib import Path

from app_version import APP_NAME, APP_TITLE, APP_VERSION
from mcp_stdio import MCPServer

ROOT = Path(__file__).resolve().parents[1]


def test_release_version_in_gui_and_docs():
    assert APP_VERSION == "1.0.0"
    assert APP_TITLE == f"{APP_NAME} v{APP_VERSION}"
    assert APP_TITLE in (ROOT / "README_HUONG_DAN.md").read_text(encoding="utf-8")
    for filename in ("app.py", "modern_ui.py"):
        source = (ROOT / filename).read_text(encoding="utf-8")
        assert "from app_version import APP_TITLE" in source
        assert "root.title(APP_TITLE)" in source


def test_release_version_in_mcp_handshake_and_discovery():
    server = MCPServer(service=object())
    initialized = server.handle({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
    assert initialized["result"]["serverInfo"]["version"] == APP_VERSION
    modern_meta = {"io.modelcontextprotocol/protocolVersion": "2026-07-28"}
    discovered = server.handle({"jsonrpc": "2.0", "id": 2, "method": "server/discover", "params": {"_meta": modern_meta}})
    assert discovered["result"]["_meta"]["io.modelcontextprotocol/serverInfo"]["version"] == APP_VERSION


def test_windows_exe_version_metadata_configured():
    build = (ROOT / "build_exe_windows.ps1").read_text(encoding="utf-8")
    assert build.count("'--version-file'") == 2
    for filename, executable in (("windows_version_gui.txt", "VelouraResourceManager.exe"),
                                  ("windows_version_mcp.txt", "VelouraMCP.exe")):
        version = (ROOT / filename).read_text(encoding="ascii")
        ast.parse(version)
        assert f"StringStruct(u'ProductVersion', u'{APP_VERSION}')" in version
        assert "StringStruct(u'FileVersion', u'1.0.0.0')" in version
        assert "filevers=(1, 0, 1, 0)" in version
        assert f"StringStruct(u'OriginalFilename', u'{executable}')" in version
        assert filename in build
