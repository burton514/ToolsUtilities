"""Regression coverage for compact window small-height and long-title issues."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest
from PIL import Image

from compact_view import CompactWindowActions
from app import ModernResourceManager
from imageflow_core import NameItem
from folder_live import scan_png_folder


def test_one_line_ellipsis_fits_by_rendered_pixel_width():
    measure = lambda value: len(value) * 7
    name = 'ic_' + 'very_long_' * 25 + '.png'
    short = CompactWindowActions._compact_ellipsize(name, 98, measure)
    assert short.endswith('…')
    assert len(short) < len(name)
    assert measure(short) <= 98
    assert CompactWindowActions._compact_ellipsize(name, measure(name), measure) == name


def test_ellipsis_handles_zero_width_tiny_width_and_unicode():
    measure = lambda value: len(value) * 10
    assert CompactWindowActions._compact_ellipsize('abcdef', 0, measure) == ''
    assert CompactWindowActions._compact_ellipsize('abcdef', 4, measure) == ''
    assert CompactWindowActions._compact_ellipsize('abcdef', 10, measure) == '…'
    assert CompactWindowActions._compact_ellipsize('ảnh_mẫu.png', 40, measure) == 'ảnh…'


@pytest.mark.parametrize('width,height,expected', [
    (258, 95, (248, 88)),
    (288, 115, (280, 104)),
    (6, 100, None),
    (300, 10, None),
])
def test_compact_canvas_bounds_fit_within_available_space(width, height, expected):
    size = CompactWindowActions._compact_thumbnail_bounds(width, height)
    assert size == expected
    if size:
        assert size[0] <= width - 6 and size[1] <= height - 6


@pytest.mark.skipif(os.name != 'nt' and not os.environ.get('DISPLAY'),
                    reason='Desktop integration requires Windows desktop or X11/Xvfb')
def test_real_compact_ui_minimum_size_long_name_tooltip_and_pin(tmp_path, monkeypatch):
    """Catch clipping regressions in a mapped Tk UI, not just unit-level helpers."""
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path))
    folder = tmp_path / 'images'
    folder.mkdir()
    tall_name = 'tall'
    long_name = 'icon_' + 'wide_' * 34
    Image.new('RGBA', (100, 500), '#d366a0').save(folder / (tall_name + '.png'))
    Image.new('RGBA', (1700, 320), '#5e8bc4').save(folder / (long_name + '.png'))
    try:
        app = ModernResourceManager()
    except Exception as exc:
        import tkinter as tk
        if isinstance(exc, tk.TclError) and 'display' in str(exc).lower():
            pytest.skip(f'Desktop display unavailable: {exc}')
        raise
    root = app.root
    try:
        for _ in range(4):
            root.update()
        app.items = [NameItem(name=tall_name, excel_row=2, prompt=''),
                     NameItem(name=long_name, excel_row=3, prompt='')]
        app.destination.set(str(folder))
        app._folder_snapshot = scan_png_folder(str(folder))
        app.select_by_index(0)
        app._compact_enter()
        root.update()
        for width, height, index in [(310, 520, 0), (340, 540, 1), (340, 670, 0)]:
            root.geometry(f'{width}x{height}+30+30')
            app.select_by_index(index)
            root.after(175, root.quit)
            root.mainloop()
            root.update()
            canvas = app.compact_preview_canvas
            bbox = canvas.bbox('all')
            assert bbox is not None and app._compact_photo is not None
            assert 0 <= bbox[0] <= bbox[2] <= canvas.winfo_width() + 1
            assert 0 <= bbox[1] <= bbox[3] <= canvas.winfo_height() + 1
            assert app.compact_name_label.winfo_height() < 45
            detail = app.compact_preview_detail
            assert detail.winfo_rooty() + detail.winfo_height() <= root.winfo_rooty() + root.winfo_height()
            if index == 1:
                assert '…' in app.compact_name_label.cget('text')
                assert app._compact_full_name == long_name + '.png'
                app._compact_schedule_tooltip(app.compact_name_label, lambda: app._compact_full_name)
                root.after(490, root.quit)
                root.mainloop()
                assert app._compact_tooltip_window is not None
                app._compact_hide_tooltip()
                app._compact_copy_tooltip_text(lambda: app._compact_full_name)
                assert root.clipboard_get() == app._compact_full_name
        app._compact_toggle_pin()
        assert app._compact_pin.get() is True
        assert str(app.compact_pin_btn.cget('bg')) != 'white'
        app._compact_exit()
        root.update()
        assert app._compact_active is False
        assert app._compact_pin.get() is False
        assert root.winfo_width() >= 1040 and root.winfo_height() >= 690
    finally:
        if root.winfo_exists():
            app.on_close()
