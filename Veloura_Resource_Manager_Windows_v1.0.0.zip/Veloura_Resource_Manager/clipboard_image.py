"""Copy a local image to the Windows clipboard for pasting in ChatGPT/browser apps.

Adds both PNG and CF_DIB representations. Requires Pillow only, not pywin32.
"""
from __future__ import annotations

import ctypes
import io
import os
import time
from ctypes import wintypes
from pathlib import Path

from PIL import Image, ImageOps

GMEM_MOVEABLE = 0x0002
CF_DIB = 8


def image_clipboard_payloads(path: str | Path) -> tuple[bytes, bytes]:
    """Return PNG and Windows DIB bytes suitable for SetClipboardData."""
    with Image.open(path) as src:
        image = ImageOps.exif_transpose(src).convert("RGBA")
        png_buf = io.BytesIO()
        image.save(png_buf, format="PNG")
        png_bytes = png_buf.getvalue()
        # DIB is a BMP file without the 14-byte BITMAPFILEHEADER.
        bmp_buf = io.BytesIO()
        rgb = Image.new("RGB", image.size, (255, 255, 255))
        rgb.paste(image, mask=image.getchannel("A"))
        rgb.save(bmp_buf, format="BMP")
        dib_bytes = bmp_buf.getvalue()[14:]
    return png_bytes, dib_bytes


def copy_image_to_clipboard(path: str | Path) -> None:
    if os.name != "nt":
        raise OSError("Chức năng copy ảnh mẫu chỉ hỗ trợ Windows")
    png_bytes, dib_bytes = image_clipboard_payloads(path)
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    user32.OpenClipboard.argtypes = (wintypes.HWND,)
    user32.OpenClipboard.restype = wintypes.BOOL
    user32.EmptyClipboard.restype = wintypes.BOOL
    user32.CloseClipboard.restype = wintypes.BOOL
    user32.SetClipboardData.argtypes = (wintypes.UINT, wintypes.HANDLE)
    user32.SetClipboardData.restype = wintypes.HANDLE
    user32.RegisterClipboardFormatW.argtypes = (wintypes.LPCWSTR,)
    user32.RegisterClipboardFormatW.restype = wintypes.UINT
    kernel32.GlobalAlloc.argtypes = (wintypes.UINT, ctypes.c_size_t)
    kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
    kernel32.GlobalLock.argtypes = (wintypes.HGLOBAL,)
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = (wintypes.HGLOBAL,)
    kernel32.GlobalUnlock.restype = wintypes.BOOL
    kernel32.GlobalFree.argtypes = (wintypes.HGLOBAL,)
    kernel32.GlobalFree.restype = wintypes.HGLOBAL
    opened = False
    for _ in range(6):
        if user32.OpenClipboard(None):
            opened = True
            break
        time.sleep(0.04)
    if not opened:
        raise OSError("Clipboard đang được ứng dụng khác sử dụng")
    try:
        if not user32.EmptyClipboard():
            raise OSError("Không thể làm trống clipboard")
        png_fmt = user32.RegisterClipboardFormatW("PNG")
        success = 0
        for fmt, blob in ((png_fmt, png_bytes), (CF_DIB, dib_bytes)):
            if not fmt:
                continue
            hmem = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(blob))
            if not hmem:
                continue
            pointer = kernel32.GlobalLock(hmem)
            if not pointer:
                kernel32.GlobalFree(hmem)
                continue
            ctypes.memmove(pointer, blob, len(blob))
            kernel32.GlobalUnlock(hmem)
            if user32.SetClipboardData(fmt, hmem):
                success += 1
            else:
                kernel32.GlobalFree(hmem)
        if not success:
            raise OSError("Windows không thể sao chép ảnh vào clipboard")
    finally:
        user32.CloseClipboard()
