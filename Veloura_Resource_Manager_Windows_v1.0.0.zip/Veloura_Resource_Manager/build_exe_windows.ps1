param([switch]$CopyToDesktop)

$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = Join-Path $AppRoot '.venv\Scripts\python.exe'
$BuildScript = Join-Path $AppRoot 'setup_and_run.ps1'
$Assets = Join-Path $AppRoot 'assets'
$Icon = Join-Path $Assets 'veloura_icon.ico'
$EntryPoint = Join-Path $AppRoot 'app.py'
$McpEntryPoint = Join-Path $AppRoot 'mcp_stdio.py'
$GuiVersionInfo = Join-Path $AppRoot 'windows_version_gui.txt'
$McpVersionInfo = Join-Path $AppRoot 'windows_version_mcp.txt'
$DistDir = Join-Path $AppRoot 'dist'
$WorkDir = Join-Path $env:TEMP 'VelouraRM_PyInstaller_Work'
$SpecDir = Join-Path $env:TEMP 'VelouraRM_PyInstaller_Spec'
$Exe = Join-Path $DistDir 'VelouraResourceManager.exe'
$McpExe = Join-Path $DistDir 'VelouraMCP.exe'

function Check-NativeCode([string]$step) {
    if ($LASTEXITCODE -ne 0) {
        throw ("$step failed (exit code: $LASTEXITCODE).")
    }
}

try {
    if (!(Test-Path -LiteralPath $EntryPoint)) { throw 'app.py not found.' }
    if (!(Test-Path -LiteralPath $McpEntryPoint)) { throw 'mcp_stdio.py not found.' }
    if (!(Test-Path -LiteralPath $Icon)) { throw 'App icon not found.' }
    if (!(Test-Path -LiteralPath $BuildScript)) { throw 'setup_and_run.ps1 not found.' }
    if (!(Test-Path -LiteralPath $GuiVersionInfo)) { throw 'GUI EXE version info not found.' }
    if (!(Test-Path -LiteralPath $McpVersionInfo)) { throw 'MCP EXE version info not found.' }

    # The setup script only provisions Python and application dependencies.
    # It must NOT launch the GUI during the build.
    Write-Host '[1/4] Checking Python and application libraries...' -ForegroundColor Cyan
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $BuildScript -InstallOnly
    Check-NativeCode 'Dependency setup'
    if (!(Test-Path -LiteralPath $Python)) { throw 'The app Python environment was not created.' }

    Write-Host '[2/4] Installing PyInstaller inside the private app environment...' -ForegroundColor Cyan
    & $Python -m pip install --disable-pip-version-check 'pyinstaller>=6.10,<7'
    Check-NativeCode 'PyInstaller installation'
    New-Item -ItemType Directory -Path $DistDir, $WorkDir, $SpecDir -Force | Out-Null

    Write-Host '[3/4] Building a self-contained Windows GUI EXE...' -ForegroundColor Cyan
    $buildArgs = @(
        '--noconfirm', '--clean', '--onefile', '--windowed',
        '--noupx',
        '--name', 'VelouraResourceManager',
        '--icon', $Icon,
        '--version-file', $GuiVersionInfo,
        '--collect-all', 'tkinterdnd2',
        '--add-data', ($Assets + ';assets'),
        '--paths', $AppRoot,
        '--distpath', $DistDir,
        '--workpath', $WorkDir,
        '--specpath', $SpecDir,
        $EntryPoint
    )
    & $Python -m PyInstaller @buildArgs
    Check-NativeCode 'EXE build'

    # MCP must be built as a console process, otherwise Windows onefile
    # --windowed initializes stdin/stdout to None and MCP cannot communicate.
    Write-Host '[4/4] Building the separate stdio MCP agent executable...' -ForegroundColor Cyan
    $mcpArgs = @(
        '--noconfirm', '--onefile', '--console', '--noupx',
        '--name', 'VelouraMCP', '--icon', $Icon,
        '--version-file', $McpVersionInfo,
        '--paths', $AppRoot, '--distpath', $DistDir,
        '--workpath', $WorkDir, '--specpath', $SpecDir,
        $McpEntryPoint
    )
    & $Python -m PyInstaller @mcpArgs
    Check-NativeCode 'MCP EXE build'
    if (!(Test-Path -LiteralPath $McpExe)) { throw ('MCP EXE missing: ' + $McpExe) }
    if (!(Test-Path -LiteralPath $Exe)) { throw ('Build finished but EXE not found: ' + $Exe) }
    if ((Get-Item -LiteralPath $Exe).Length -lt 1000000) { throw 'EXE looks incomplete.' }
    Write-Host ('Built: ' + $Exe) -ForegroundColor Green
    Write-Host ('Built MCP: ' + $McpExe) -ForegroundColor Green

    $AgentExecutable = $McpExe
    if ($CopyToDesktop) {
        $Desktop = [Environment]::GetFolderPath('DesktopDirectory')
        if (!$Desktop -or !(Test-Path -LiteralPath $Desktop -PathType Container)) {
            throw 'Could not find your Windows Desktop folder.'
        }
        $DesktopExe = Join-Path $Desktop 'Veloura Resource Manager.exe'
        $running = Get-Process -Name 'VelouraResourceManager' -ErrorAction SilentlyContinue
        if ($running) { throw 'Close Veloura Resource Manager before replacing the Desktop EXE.' }
        Copy-Item -LiteralPath $Exe -Destination $DesktopExe -Force
        $DesktopMcpExe = Join-Path $Desktop 'VelouraMCP.exe'
        Copy-Item -LiteralPath $McpExe -Destination $DesktopMcpExe -Force
        $AgentExecutable = $DesktopMcpExe
        if (!(Test-Path -LiteralPath $DesktopExe)) { throw 'Copy to Desktop failed.' }
        Write-Host ('Desktop app ready: ' + $DesktopExe) -ForegroundColor Green
        Write-Host 'GUI and MCP EXEs can run without Python at runtime.' -ForegroundColor Green
        Start-Process explorer.exe -ArgumentList ('"' + $Desktop + '"')
    } else {
        Start-Process explorer.exe -ArgumentList ('"' + $DistDir + '"')
    }
    # Ready-to-copy templates; do not modify Claude/Codex settings silently.
    $ClaudeConfig = @{
        mcpServers = @{
            veloura = @{
                command = $AgentExecutable
                args = @()
            }
        }
    } | ConvertTo-Json -Depth 8
    Set-Content -LiteralPath (Join-Path $DistDir 'Veloura_MCP_Claude_Config.json') -Value $ClaudeConfig -Encoding UTF8
    $TomlCommand = $AgentExecutable.Replace('\', '\\')
    $TomlConfig = "[mcp_servers.veloura]`ncommand = `"$TomlCommand`"`n"
    Set-Content -LiteralPath (Join-Path $DistDir 'Veloura_MCP_Codex_Config.toml') -Value $TomlConfig -Encoding UTF8
    Write-Host ('Agent configuration examples: ' + $DistDir) -ForegroundColor Green
    exit 0
} catch {
    $message = $_.Exception.Message
    Write-Host ('BUILD FAILED: ' + $message) -ForegroundColor Red
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            $message,
            'Veloura Resource Manager - EXE builder',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } catch { }
    exit 1
}
