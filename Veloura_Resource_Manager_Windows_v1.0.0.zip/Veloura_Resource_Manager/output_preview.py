"""Resolve the active icon's PNG on disk; never persist images in the app.

The source of truth is the live folder snapshot of the active project.
"""
from __future__ import annotations

from folder_live import FolderSnapshot, IconFile


def resolve_selected_output(snapshot: FolderSnapshot | None, folder: str,
                            items: list, selected_index: int | None,
                            preferred: str = "png") -> IconFile | None:
    if snapshot is None or snapshot.folder != folder:
        return None
    if selected_index is None or not 0 <= selected_index < len(items):
        return None
    item = items[selected_index]
    if item.state == 'invalid':
        return None
    return snapshot.for_icon(item.name, preferred)


def preview_identity(project_id: str | None, file: IconFile | None) -> tuple | None:
    """A stable key for cache invalidation on selection, overwrite and switch."""
    if file is None:
        return None
    return (project_id, str(file.path), file.size, file.modified_ns,
            file.inode, file.change_ns, file.content_digest)
