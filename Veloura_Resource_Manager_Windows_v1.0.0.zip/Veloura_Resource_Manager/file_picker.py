# -*- coding: utf-8 -*-
"""Portable source-file chooser without the Windows native filename parser.

This deliberately uses Tk widgets instead of the OS-native OpenFileDialog: on
some Windows/Tk installations pasting /C:/... into the native chooser raises
"The file name is not valid" before Python receives a filename. Here, every
file selection and pasted path passes through normalize_source_path first.
"""
from __future__ import annotations

import os
import string
import tkinter as tk
from pathlib import Path
from tkinter import ttk

from imageflow_core import normalize_source_path

SOURCE_EXTENSIONS = frozenset({".xlsx", ".xlsm", ".csv"})


def source_file_path(raw: str) -> Path:
    """Normalize and validate a selected/pasted spreadsheet path."""
    value = normalize_source_path(raw)
    if not value:
        raise ValueError("Hãy chọn hoặc nhập đường dẫn file.")
    path = Path(value).expanduser()
    if path.suffix.casefold() not in SOURCE_EXTENSIONS:
        raise ValueError("Chỉ hỗ trợ Excel (.xlsx, .xlsm) và CSV (.csv).")
    if not path.is_file():
        raise ValueError("Không tìm thấy file. Hãy kiểm tra đường dẫn và thử lại.")
    return path


def list_source_entries(directory: Path) -> list[tuple[str, bool]]:
    """List directories first; filter files by extension, without native dialogs."""
    result = []
    with os.scandir(directory) as entries:
        for entry in entries:
            try:
                folder = entry.is_dir(follow_symlinks=False)
                if folder or (entry.is_file(follow_symlinks=False) and
                              Path(entry.name).suffix.casefold() in SOURCE_EXTENSIONS):
                    result.append((entry.name, folder))
            except OSError:
                continue
    result.sort(key=lambda e: (not e[1], e[0].casefold()))
    return result


class SourceFilePicker(tk.Toplevel):
    """Compact Explorer-like browser, with editable address and file selection."""

    def __init__(self, master, initial_dir=None):
        super().__init__(master)
        self.result = None
        self.current = None
        self.row_paths = {}
        self.title("Veloura Resource Manager — Chọn Excel / CSV")
        self.configure(bg="#F6F6F6")
        self.geometry("850x570")
        self.minsize(610, 440)
        self.transient(master)
        self.protocol("WM_DELETE_WINDOW", self.destroy)

        self.path_var = tk.StringVar()
        self.file_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Chọn một file hoặc dán đường dẫn đầy đủ vào ô Đường dẫn file.")
        self._create_widgets()
        initial = Path(initial_dir).expanduser() if initial_dir else Path.home()
        if not initial.is_dir():
            initial = Path.home()
        self.navigate(initial)
        self.update_idletasks()
        # Place the browser over the application, not at the screen's origin.
        x = master.winfo_rootx() + max(0, (master.winfo_width() - self.winfo_width()) // 2)
        y = master.winfo_rooty() + max(0, (master.winfo_height() - self.winfo_height()) // 2)
        self.geometry(f"+{x}+{y}")
        self.grab_set()
        self.focus_force()

    def _create_widgets(self):
        bg = "#F6F6F6"
        white = "#FFFFFF"
        ink = "#111111"
        muted = "#565656"
        font = ("Segoe UI", 10)
        medium = ("Segoe UI Semibold", 10)
        header = tk.Frame(self, bg=white, highlightbackground="#D8D8D8", highlightthickness=1)
        header.pack(fill="x")
        tk.Frame(header, width=5, bg="#111111").pack(side="left", fill="y")
        htitle = tk.Frame(header, bg=white)
        htitle.pack(side="left", padx=18, pady=12)
        tk.Label(htitle, text="Chọn Excel / CSV", font=("Segoe UI Semibold", 15),
                 fg=ink, bg=white).pack(anchor="w")
        tk.Label(htitle, text="Duyệt thư mục hoặc nhập trực tiếp đường dẫn file dữ liệu",
                 font=font, fg=muted, bg=white).pack(anchor="w", pady=(4, 0))
        tk.Label(header, text="EXCEL  ·  CSV", bg="#EAEAEA", fg="#111111",
                 font=medium, padx=10, pady=5).pack(side="right", padx=18)

        top = tk.Frame(self, bg=bg)
        top.pack(fill="x", padx=16, pady=(12, 8))
        self._button(top, "↑ Lên", self.go_up, width=7).pack(side="left", padx=(0, 7))
        self._button(top, "Trang chủ", lambda: self.navigate(Path.home())).pack(side="left", padx=(0, 7))
        desktop = Path.home() / "Desktop"
        if desktop.is_dir():
            self._button(top, "Desktop", lambda: self.navigate(desktop)).pack(side="left", padx=(0, 7))
        downloads = Path.home() / "Downloads"
        if downloads.is_dir():
            self._button(top, "Downloads", lambda: self.navigate(downloads)).pack(side="left", padx=(0, 7))
        if os.name == "nt":
            drive_values = [f"{letter}:\\" for letter in string.ascii_uppercase
                            if Path(f"{letter}:\\").exists()]
            if drive_values:
                self.drives = ttk.Combobox(top, state="readonly", values=drive_values, width=6,
                                           font=font)
                self.drives.pack(side="right")
                self.drives.bind("<<ComboboxSelected>>", lambda e: self.navigate(Path(self.drives.get())))

        address_row = tk.Frame(self, bg=bg)
        address_row.pack(fill="x", padx=16, pady=(0, 8))
        tk.Label(address_row, text="Thư mục:", font=medium, bg=bg, fg=ink).pack(side="left", padx=(0, 8))
        address = tk.Entry(address_row, textvariable=self.path_var, bg=white, fg=ink,
                           font=font, relief="solid", bd=1)
        address.pack(side="left", fill="x", expand=True, ipady=6)
        address.bind("<Return>", lambda e: self.address_enter())
        self._button(address_row, "Đi đến", self.address_enter).pack(side="left", padx=(8, 0))

        listing = tk.Frame(self, bg=white, highlightbackground="#D8D8D8", highlightthickness=1)
        listing.pack(fill="both", expand=True, padx=16)
        self.tree = ttk.Treeview(listing, columns=("name", "type"), show="headings",
                                 selectmode="browse", height=9)
        self.tree.heading("name", text="Tên thư mục / file")
        self.tree.heading("type", text="Loại")
        self.tree.column("name", stretch=True, anchor="w", width=540)
        self.tree.column("type", stretch=False, anchor="w", width=110)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(listing, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Double-1>", self.on_double_click)
        self.tree.bind("<Return>", self.on_enter_row)
        self.tree.bind("<BackSpace>", lambda e: self.go_up())
        style = ttk.Style(self)
        style.configure("SourcePicker.Treeview", font=font, rowheight=29, background=white,
                        foreground=ink, fieldbackground=white, borderwidth=0)
        style.map("SourcePicker.Treeview", background=[("selected", "#E4E4E4")],
                  foreground=[("selected", ink)])
        style.configure("SourcePicker.Treeview.Heading", font=medium,
                        foreground=ink, background="#EFEFEF", padding=7, relief="flat")
        self.tree.configure(style="SourcePicker.Treeview")

        bottom = tk.Frame(self, bg=bg)
        bottom.pack(fill="x", padx=16, pady=(8, 12))
        tk.Label(bottom, text="Đường dẫn file:", font=medium, bg=bg, fg=ink).pack(anchor="w")
        row = tk.Frame(bottom, bg=bg)
        row.pack(fill="x", pady=(5, 7))
        self.file_entry = tk.Entry(row, textvariable=self.file_var, font=font, bg=white,
                                   fg=ink, relief="solid", bd=1)
        self.file_entry.pack(side="left", fill="x", expand=True, ipady=7)
        self.file_entry.bind("<Return>", lambda e: self.confirm())
        self._button(row, "Hủy", self.destroy).pack(side="right", padx=(7, 0))
        self._button(row, "Mở file", self.confirm, primary=True).pack(side="right", padx=(7, 0))
        tk.Label(bottom, textvariable=self.status_var, font=("Segoe UI", 9), fg=muted,
                 bg=bg, anchor="w").pack(fill="x")

    @staticmethod
    def _button(parent, title, callback, primary=False, width=None):
        bg = '#111111' if primary else '#FFFFFF'
        fg = '#FFFFFF' if primary else '#111111'
        hover = '#303030' if primary else '#EAEAEA'
        button = tk.Button(parent, text=title, command=callback, width=width,
                           font=('Segoe UI Semibold', 10), fg=fg,
                           bg=bg, relief='flat', bd=0, activebackground=hover,
                           activeforeground=fg, padx=11, pady=7, cursor='hand2',
                           highlightthickness=1, highlightbackground='#D8D8D8')
        button.bind('<Enter>', lambda event: button.configure(bg=hover))
        button.bind('<Leave>', lambda event: button.configure(bg=bg))
        return button

    def navigate(self, directory):
        path = Path(normalize_source_path(str(directory))).expanduser()
        if not path.is_dir():
            self.status_var.set("Không mở được thư mục này.")
            return
        try:
            rows = list_source_entries(path)
        except OSError as exc:
            self.status_var.set("Không thể đọc thư mục: " + str(exc))
            return
        self.current = path
        self.path_var.set(str(path))
        self.row_paths.clear()
        self.tree.delete(*self.tree.get_children())
        for index, (name, is_folder) in enumerate(rows):
            iid = str(index)
            self.row_paths[iid] = (path / name, is_folder)
            self.tree.insert("", "end", iid=iid, values=("📁  " + name if is_folder else name,
                                                         "Thư mục" if is_folder else Path(name).suffix.upper()[1:]))
        self.status_var.set(f"{sum(not folder for _, folder in rows)} file Excel/CSV · Nhấp đúp để mở")

    def go_up(self):
        if self.current:
            self.navigate(self.current.parent)

    def address_enter(self):
        raw = normalize_source_path(self.path_var.get())
        candidate = Path(raw).expanduser()
        if candidate.is_dir():
            self.navigate(candidate)
        elif candidate.is_file():
            self.file_var.set(raw)
            self.confirm()
        else:
            self.status_var.set("Thư mục không tồn tại. Kiểm tra lại đường dẫn.")

    def on_select(self, event=None):
        selection = self.tree.selection()
        if not selection:
            return
        path, folder = self.row_paths[selection[0]]
        if not folder:
            self.file_var.set(str(path))

    def on_enter_row(self, event=None):
        self.on_double_click()
        return "break"

    def on_double_click(self, event=None):
        selection = self.tree.selection()
        if not selection:
            return
        path, folder = self.row_paths[selection[0]]
        if folder:
            self.navigate(path)
        else:
            self.file_var.set(str(path))
            self.confirm()

    def confirm(self):
        raw = self.file_var.get().strip()
        if not raw:
            self.status_var.set("Hãy chọn một file trong danh sách hoặc dán đường dẫn file.")
            self.file_entry.focus_set()
            return
        # Accept a bare filename too, relative to the visible directory.
        raw_path = Path(normalize_source_path(raw)).expanduser()
        if not raw_path.is_absolute() and self.current is not None:
            raw_path = self.current / raw_path
        try:
            selected = source_file_path(str(raw_path))
        except (ValueError, OSError) as exc:
            self.status_var.set(str(exc))
            return
        self.result = str(selected)
        self.destroy()


def ask_source_file(parent, initial_dir=None) -> str:
    dialog = SourceFilePicker(parent, initial_dir)
    parent.wait_window(dialog)
    return dialog.result or ""
