param([switch]$InstallOnly)

$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPython = Join-Path $AppRoot '.venv\Scripts\python.exe'
$VenvPythonW = Join-Path $AppRoot '.venv\Scripts\pythonw.exe'
$Stamp = Join-Path $AppRoot '.venv\installed_requirements.sha256'
$Requirements = Join-Path $AppRoot 'requirements.txt'

function Show-Failure([string]$message) {
    Write-Host "`nERROR: $message" -ForegroundColor Red
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show($message, 'Veloura Resource Manager - Setup', 'OK', 'Error') | Out-Null
    } catch { }
}

try {
    if (!(Test-Path $VenvPython)) {
        Write-Host '[1/3] Preparing Python...' -ForegroundColor Cyan
        $BasePython = $null
        $candidatePaths = @(
            (Join-Path $env:LOCALAPPDATA 'VelouraImageManager\Python312\python.exe'),
            (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
            (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe')
        )
        foreach ($candidate in $candidatePaths) {
            if (Test-Path $candidate) {
                try {
                    & $candidate -c 'import sys,tkinter; assert sys.version_info >= (3,10)'
                    if ($LASTEXITCODE -eq 0) { $BasePython = $candidate; break }
                } catch { }
            }
        }
        if (!$BasePython) {
            foreach ($name in @('py.exe', 'python.exe')) {
                if (!(Get-Command $name -ErrorAction SilentlyContinue)) { continue }
                try {
                    $args = if ($name -eq 'py.exe') { @('-3', '-c', 'import sys,tkinter; assert sys.version_info >= (3,10); print(sys.executable)') } else { @('-c', 'import sys,tkinter; assert sys.version_info >= (3,10); print(sys.executable)') }
                    $answer = & $name @args 2>$null
                    if ($LASTEXITCODE -eq 0 -and $answer) {
                        $path = (($answer | Select-Object -Last 1) -as [string]).Trim()
                        if (Test-Path $path) { $BasePython = $path; break }
                    }
                } catch { }
            }
        }
        if (!$BasePython) {
            if (![Environment]::Is64BitOperatingSystem) { throw 'Windows 64-bit is required for automatic Python installation.' }
            Write-Host 'Python not found. Downloading an official Python installer (one time)...' -ForegroundColor Yellow
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $downloadUrl = 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe'
            $installer = Join-Path $env:TEMP 'veloura-python-3.12.10-amd64.exe'
            $destination = Join-Path $env:LOCALAPPDATA 'VelouraImageManager\Python312'
            Invoke-WebRequest -Uri $downloadUrl -OutFile $installer -UseBasicParsing
            Write-Host 'Installing Python locally for the current Windows user...' -ForegroundColor Yellow
            $installArgs = @('/quiet', 'InstallAllUsers=0', 'PrependPath=0', 'Include_launcher=0', 'Include_pip=1', 'Include_tcltk=1', 'Include_test=0', ('TargetDir="' + $destination + '"'))
            $process = Start-Process -FilePath $installer -ArgumentList $installArgs -Wait -PassThru
            if ($process.ExitCode -ne 0) { throw ('Python installer error code: ' + $process.ExitCode) }
            $BasePython = Join-Path $destination 'python.exe'
            if (!(Test-Path $BasePython)) { throw 'Python installation completed but python.exe was not found.' }
        }
        Write-Host '[2/3] Creating an isolated app environment...' -ForegroundColor Cyan
        & $BasePython -m venv (Join-Path $AppRoot '.venv')
        if ($LASTEXITCODE -ne 0 -or !(Test-Path $VenvPython)) { throw 'Could not create the application environment.' }
    }

    $NewHash = (Get-FileHash -Path $Requirements -Algorithm SHA256).Hash
    $OldHash = if (Test-Path $Stamp) { (Get-Content $Stamp -Raw).Trim() } else { '' }
    if ($NewHash -ne $OldHash) {
        Write-Host '[3/3] Installing image and Excel libraries (first launch only)...' -ForegroundColor Cyan
        & $VenvPython -m pip install --disable-pip-version-check -r $Requirements
        if ($LASTEXITCODE -ne 0) { throw 'Could not install libraries. Check the internet connection and retry START_WINDOWS.cmd.' }
        Set-Content -Path $Stamp -Value $NewHash -NoNewline
    }

    if ($InstallOnly) {
        Write-Host 'Setup complete.' -ForegroundColor Green
        exit 0
    }
    if (!(Test-Path $VenvPythonW)) { throw 'pythonw.exe was not found.' }
    Write-Host 'Launching Veloura Resource Manager...' -ForegroundColor Green
    Start-Process -FilePath $VenvPythonW -ArgumentList ('"' + (Join-Path $AppRoot 'app.py') + '"') -WorkingDirectory $AppRoot
} catch {
    Show-Failure $_.Exception.Message
    exit 1
}
