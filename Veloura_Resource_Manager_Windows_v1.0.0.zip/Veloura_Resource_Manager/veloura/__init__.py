"""Veloura application layers; public legacy entry points remain stable."""
