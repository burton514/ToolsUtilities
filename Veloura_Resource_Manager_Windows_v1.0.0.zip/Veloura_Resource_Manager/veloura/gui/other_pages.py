"""OtherPagesUI: presentation and interaction for other pages."""
from app_version import APP_TITLE
from veloura.gui.theme import BG, BLACK, BORDER, F, FIELD, INK, MUTED, SMALL, WHITE
from PIL import Image, ImageTk
from pathlib import Path
from clipboard_image import copy_image_to_clipboard
from tkinter import messagebox, ttk
import tkinter as tk


class OtherPagesUI:
    def _build_extra_pages(self):
        pages=[('progress','Tiến độ'),('references','Thư viện ảnh mẫu'),
               ('prompt_templates','Mẫu Prompt'),('history','Lịch sử'),
               ('settings','Cài đặt'),('about','Giới thiệu')]
        for name,title in pages:
            page=tk.Frame(self.content_host,bg=BG)
            page.place(relx=0,rely=0,relwidth=1,relheight=1)
            self.extra_pages[name]=page
            self.txt(page,title,18,INK,True,bg=BG).pack(anchor='w',pady=(8,12))
            wrap,_,inner=self._scroll_area(page)
            wrap.pack(fill='both',expand=True)
            setattr(self,name+'_body',inner)
        self._build_template_content()
        self._refresh_settings_page()
        self._build_about_page()

    def _refresh_progress_page(self):
        if not hasattr(self,'progress_body'):
            return
        body=self.progress_body
        for w in body.winfo_children():w.destroy()
        counts={state:sum(1 for item in self.items if item.state==state)
                for state in ('done','existing','review','pending','invalid','corrupt')}
        cards=[('Tổng số Image Gen',len(self.items)),('Đã có ảnh',counts['done']+counts['existing']+counts['review']),
               ('Cần xem xét',counts['review']),('Chưa có',counts['pending']),('Lỗi',counts['invalid']+counts['corrupt'])]
        grid=tk.Frame(body,bg=BG)
        grid.pack(fill='x')
        for i,(title,value) in enumerate(cards):
            card=self._surface(grid)
            card.grid(row=0,column=i,sticky='nsew',padx=5,pady=5)
            grid.grid_columnconfigure(i,weight=1)
            self.txt(card,title,10,MUTED).pack(padx=18,pady=(14,4))
            self.txt(card,str(value),23,INK,True).pack(padx=18,pady=(0,14))
        card=self._surface(body)
        card.pack(fill='x',padx=5,pady=10)
        total=max(1,len(self.items))
        done=counts['done']+counts['existing']+counts['review']
        percent=100*done/total
        self.txt(card,f'Đã hoàn thành {percent:.1f}%',13,INK,True).pack(anchor='w',padx=15,pady=(14,7))
        prog=tk.Canvas(card,height=18,bg=WHITE,highlightthickness=0)
        prog.pack(fill='x',padx=15,pady=(0,14))
        def draw(e):
            prog.delete('all')
            width=prog.winfo_width()
            prog.create_rectangle(0,2,width,16,fill='#E4E4E4',outline='')
            prog.create_rectangle(0,2,width*percent/100,16,fill=BLACK,outline='')
        prog.bind('<Configure>',draw)
        self.button(body,'Về Workspace',lambda:self.show_page('workspace'),primary=True).pack(anchor='w',padx=6)

    def _refresh_reference_page(self):
        if not hasattr(self,'references_body'):
            return
        body=self.references_body
        for w in body.winfo_children():w.destroy()
        action=self._surface(body)
        action.pack(fill='x',pady=(0,10))
        self.txt(action,f'{len(self.reference_paths)} ảnh mẫu thuộc project {self.project_store.active["name"]}',
                 11,INK,True).pack(side='left',padx=12,pady=12)
        self.button(action,'Thêm ảnh',self.choose_reference,primary=True,icon_name='reference_add').pack(side='right',padx=12)
        cols=4
        grid=tk.Frame(body,bg=BG)
        grid.pack(fill='x')
        thumbs=[]
        for i,path in enumerate(self.reference_paths):
            frame=self._surface(grid)
            frame.grid(row=i//cols,column=i%cols,sticky='nsew',padx=5,pady=5)
            grid.grid_columnconfigure(i%cols,weight=1)
            photo=None
            if Path(path).is_file():
                try:
                    with Image.open(path) as image:
                        prev=image.convert('RGBA')
                        prev.thumbnail((130,130),Image.Resampling.LANCZOS)
                    photo=ImageTk.PhotoImage(prev)
                    thumbs.append(photo)
                except Exception:pass
            tk.Label(frame,image=photo if photo else self.thumbnail_placeholder,compound='center',text='' if photo else 'Không tìm thấy ảnh',
                     bg=FIELD,width=150,height=138,font=SMALL).pack(padx=12,pady=(12,6))
            self.txt(frame,Path(path).name[:25],10,INK,True).pack(padx=8)
            buttons=tk.Frame(frame,bg=WHITE)
            buttons.pack(fill='x',padx=10,pady=10)
            self.button(buttons,'Copy',lambda p=path:self._copy_one_reference(p),small=True).pack(side='left',fill='x',expand=True)
            self.button(buttons,'Bỏ khỏi dự án',lambda p=path:self._remove_reference(p),small=True).pack(side='left',fill='x',expand=True,padx=(6,0))
        self.reference_library_photos=thumbs

    def _copy_one_reference(self,path):
        try:copy_image_to_clipboard(path)
        except Exception as exc:messagebox.showerror('Không copy được',str(exc))
        else:self._status('Đã copy: '+Path(path).name)

    def _build_template_content(self):
        body=self.prompt_templates_body
        card=self._surface(body)
        card.pack(fill='x')
        self.txt(card,'Mẫu Prompt riêng của project',12,INK,True).pack(anchor='w',padx=15,pady=(14,5))
        self.txt(card,'Dùng {name} cho tên Image Gen và {prompt} cho Prompt từ Excel/CSV.',10,MUTED).pack(anchor='w',padx=15,pady=(0,10))
        ttk.Checkbutton(card,text='Bật mẫu Prompt khi copy',variable=self.template_enabled,
                        style='Veloura.TCheckbutton',command=self._save_prompt_template).pack(anchor='w',padx=15,pady=(0,8))
        self.template_text=tk.Text(card,height=9,font=F,wrap='word',bg=FIELD,fg=INK,
                                  relief='flat',bd=0,padx=12,pady=10,highlightthickness=1,
                                  highlightbackground=BORDER)
        self.template_text.pack(fill='x',padx=15,pady=(0,10))
        self.template_text.bind('<FocusOut>',lambda e:self._save_prompt_template())
        self.button(card,'Lưu mẫu Prompt',self._save_prompt_template,primary=True,icon_name='project_save').pack(anchor='e',padx=15,pady=(0,14))

    def _save_prompt_template(self):
        if getattr(self,'_template_loading',False) or self._changing_project:
            return
        self.project_store.active['prompt_template']=self._get_template_text()
        self.project_store.active['template_enabled']=self.template_enabled.get()
        self.project_store.save()
        self._refresh_prompt()
        self._status('Đã lưu mẫu Prompt của project')

    def _refresh_template_page(self):
        self._template_loading=True
        self._set_template_text(self.project_store.active.get('prompt_template',''))
        self.template_enabled.set(bool(self.project_store.active.get('template_enabled',False)))
        self._template_loading=False

    def _refresh_history_page(self):
        if not hasattr(self,'history_body'):
            return
        body=self.history_body
        for w in body.winfo_children():w.destroy()
        card=self._surface(body)
        card.pack(fill='x')
        head=self._section_title(card,'Hoạt động trong phiên',icon_name='nav_history')
        head.pack(fill='x',padx=12,pady=12)
        # Right-aligned actions; pack in reverse order to keep visual order:
        # Làm mới | Xóa nhật ký | Xuất CSV.
        self.button(head, 'Xuất CSV', self.export_logs, icon_name='data_csv', small=True).pack(side='right')
        self.button(head, 'Xóa nhật ký', self.clear_history, icon_name='history_clear', small=True).pack(side='right', padx=(0, 8))
        self.button(head, 'Làm mới', self.refresh_history, icon_name='gallery_refresh', small=True).pack(side='right', padx=(0, 8))
        if not self.logs:
            self.txt(card,'Chưa có lịch sử trong phiên hiện tại.',10,MUTED).pack(anchor='w',padx=15,pady=(0,14))
        for event in reversed(self.logs[-50:]):
            line=tk.Frame(card,bg=WHITE)
            line.pack(fill='x',padx=12,pady=4)
            self.txt(line,event.get('Thời gian',''),9,MUTED).pack(side='left',padx=(0,10))
            self.txt(line,event.get('Tên ảnh',''),10,INK,True).pack(side='left')
            self.txt(line,event.get('Kết quả',''),9,MUTED).pack(side='right')

    def _refresh_settings_page(self):
        if not hasattr(self,'settings_body'):
            return
        body=self.settings_body
        for w in body.winfo_children():w.destroy()
        card=self._surface(body)
        card.pack(fill='x')
        self.txt(card,'Thiết lập project đang chọn',12,INK,True).pack(anchor='w',padx=14,pady=(14,8))
        self.txt(card,'Thư mục ảnh',9,MUTED).pack(anchor='w',padx=14)
        row=tk.Frame(card,bg=WHITE)
        row.pack(fill='x',padx=14,pady=(5,10))
        self._field(row,self.destination).pack(side='left',fill='x',expand=True,ipady=6)
        self.button(row,'Chọn',self.pick_destination).pack(side='left',padx=(8,0))
        self.button(card,'Lưu cài đặt',self.persist_settings,primary=True,icon_name='project_save').pack(anchor='e',padx=14,pady=(0,14))

    def _build_about_page(self):
        body=self.about_body
        card=self._surface(body)
        card.pack(fill='x')
        self.txt(card,APP_TITLE,16,INK,True).pack(anchor='w',padx=16,pady=(18,8))
        self.txt(card,'Quản lý ảnh theo project: Excel/CSV, Prompt, ảnh mẫu và nhiều định dạng đầu ra.',
                 11,MUTED).pack(anchor='w',padx=16,pady=(0,16))

