"""Presentation palette for the existing project dialogs.

Keep this separate from the monochrome main-window palette in gui/theme.py.
"""
# Veloura Studio UI: neutral white surfaces, a restrained lilac accent, dark text.
BG = "#F7F5FC"
WHITE = "#FFFFFF"
INK = "#171821"
MUTED = "#6A6878"
ACCENT = "#7A4AD8"
DARK_PURPLE = INK
SOFT_PURPLE = "#F4EEFE"
SOFT_PINK = "#FAF7FE"
BORDER = "#E7E0F1"
GREEN = "#1C7957"
RED = "#9D3B57"
BUTTON_HOVER = "#E2D5FA"
FIELD = "#FCFBFE"

F = ("Segoe UI", 10)
F_SMALL = ("Segoe UI", 9)
F_MEDIUM = ("Segoe UI Semibold", 10)
F_H2 = ("Segoe UI Semibold", 11)
F_H1 = ("Segoe UI Semibold", 18)

