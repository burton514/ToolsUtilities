"""Reusable Tk widgets used by both the controller dialogs and the main GUI."""
import tkinter as tk
from veloura.gui.dialog_theme import INK, WHITE


def make_label(parent, text, size=11, color=INK, bold=False, **kwargs):
    font = ("Segoe UI Semibold" if bold else "Segoe UI", size)
    return tk.Label(parent, text=text, font=font, fg=color,
                    bg=kwargs.pop("bg", WHITE), **kwargs)
