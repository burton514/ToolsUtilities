"""ProjectsUI: presentation and interaction for projects."""
from veloura.gui.theme import ACTIVE, BG, BORDER, F, FIELD, INK, MUTED, WHITE
from tkinter import messagebox
import tkinter as tk


class ProjectsUI:
    def _build_projects_page(self, parent):
        header=tk.Frame(parent,bg=BG)
        header.pack(fill='x',pady=(7,10))
        self.txt(header,'Quản lý project',18,INK,True,bg=BG).pack(side='left')
        self.button(header,'Tạo project',self.new_project,primary=True,icon_name='project_create').pack(side='right')
        self.button(header,'Nhân bản',self._duplicate_project,icon_name='project_duplicate').pack(side='right',padx=8)
        body=tk.Frame(parent,bg=BG)
        body.pack(fill='both',expand=True)
        body.grid_columnconfigure(1,weight=1)
        body.grid_rowconfigure(0,weight=1)
        sidebar=self._surface(body)
        sidebar.grid(row=0,column=0,sticky='ns',padx=(0,8))
        sidebar.configure(width=275)
        sidebar.pack_propagate(False)
        label=self._section_title(sidebar,'Danh sách project',icon_name='project_list')
        label.pack(fill='x',padx=12,pady=(12,9))
        self.project_search=tk.StringVar()
        entry=self._field(sidebar,self.project_search)
        entry.pack(fill='x',padx=12,ipady=6,pady=(0,8))
        self.project_search.trace_add('write',lambda *_:self.refresh_projects_page())
        wrap,_,self.projects_list=self._scroll_area(sidebar,WHITE)
        wrap.pack(fill='both',expand=True,padx=10,pady=(0,8))
        self.project_detail=self._surface(body)
        self.project_detail.grid(row=0,column=1,sticky='nsew')
        self.selected_project_id=self.project_store.active_id
        self._render_project_detail()

    def refresh_projects_page(self):
        if not hasattr(self,'projects_list'):
            return
        for child in self.projects_list.winfo_children():
            child.destroy()
        query=self.project_search.get().strip().casefold() if hasattr(self,'project_search') else ''
        for project in self.project_store.projects:
            if query and query not in project['name'].casefold():
                continue
            selected = project['id']==self.selected_project_id
            row=tk.Frame(self.projects_list,bg=ACTIVE if selected else WHITE,
                         highlightbackground=BORDER,highlightthickness=1,cursor='hand2')
            row.pack(fill='x',pady=(0,5))
            icon=self._get_icon('project_folder')
            if icon:
                tk.Label(row,image=icon,bg=ACTIVE if selected else WHITE).pack(side='left',padx=(9,6),pady=12)
            content=tk.Frame(row,bg=ACTIVE if selected else WHITE)
            content.pack(side='left',fill='x',expand=True,pady=8)
            title=self.txt(content,project['name'][:23],11,INK,True,bg=ACTIVE if selected else WHITE,anchor='w')
            title.pack(fill='x')
            text=self.txt(content,project['destination'][:32]+'…' if len(project['destination'])>32 else project['destination'],
                           9,MUTED,bg=ACTIVE if selected else WHITE,anchor='w')
            text.pack(fill='x',pady=(3,0))
            for item in (row,title,text,content):
                item.bind('<Button-1>',lambda e, pid=project['id']:self._select_project_card(pid))
        self._render_project_detail()

    def _select_project_card(self,project_id):
        self.selected_project_id=project_id
        self.refresh_projects_page()

    def _render_project_detail(self):
        """Exactly four editable project fields; source and folder use pickers."""
        if not hasattr(self, 'project_detail'):
            return
        for widget in self.project_detail.winfo_children():
            widget.destroy()
        try:
            project=self.project_store.get(self.selected_project_id)
        except KeyError:
            self.selected_project_id=self.project_store.active_id
            project=self.project_store.active
        inner_wrap,_,inner=self._scroll_area(self.project_detail,WHITE,auto_hide=True)
        inner_wrap.pack(fill='both',expand=True)
        head=self._section_title(inner,'Chi tiết project',icon_name='project_selected')
        head.pack(fill='x',padx=16,pady=(15,14))

        name_var=tk.StringVar(value=project['name'])
        description=str(project.get('description','') or '')
        source_var=tk.StringVar(value=project.get('last_source','') or '')
        folder_var=tk.StringVar(value=project.get('destination','') or '')
        editor=tk.Frame(inner,bg=WHITE)
        editor.pack(fill='x',padx=16)

        self.txt(editor,'Tên Project',10,INK,True,bg=WHITE).pack(anchor='w',pady=(0,5))
        name_entry=self._field(editor,name_var)
        name_entry.pack(fill='x',ipady=8,pady=(0,13))

        self.txt(editor,'Mô tả (có thể trống)',10,INK,True,bg=WHITE).pack(anchor='w',pady=(0,5))
        description_entry=tk.Text(editor,height=3,wrap='word',font=F,bg=FIELD,fg=INK,
                                  relief='flat',highlightbackground=BORDER,highlightthickness=1,
                                  insertbackground=INK,padx=9,pady=6)
        description_entry.pack(fill='x',pady=(0,13))
        description_entry.insert('1.0',description)

        self.txt(editor,'File Excel/CSV',10,INK,True,bg=WHITE).pack(anchor='w',pady=(0,5))
        source_row=tk.Frame(editor,bg=WHITE)
        source_row.pack(fill='x',pady=(0,13))
        source_entry=self._field(source_row,source_var)
        source_entry.configure(state='readonly',readonlybackground=FIELD,cursor='hand2')
        source_entry.pack(side='left',fill='x',expand=True,ipady=8)
        source_entry.bind('<Button-1>',lambda _:self._browse_project_source(self.root,source_var))
        self.button(source_row,'Chọn file...',lambda: self._browse_project_source(self.root,source_var),
                    icon_name='data_import',small=True).pack(side='left',padx=(8,0))

        self.txt(editor,'Thư mục lưu',10,INK,True,bg=WHITE).pack(anchor='w',pady=(0,5))
        folder_row=tk.Frame(editor,bg=WHITE)
        folder_row.pack(fill='x')
        folder_entry=self._field(folder_row,folder_var)
        folder_entry.configure(state='readonly',readonlybackground=FIELD,cursor='hand2')
        folder_entry.pack(side='left',fill='x',expand=True,ipady=8)
        folder_entry.bind('<Button-1>',lambda _:self._browse_project_folder(self.root,folder_var))
        self.button(folder_row,'Chọn thư mục...',lambda: self._browse_project_folder(self.root,folder_var),
                    icon_name='project_browse',small=True).pack(side='left',padx=(8,0))

        footer=tk.Frame(inner,bg=WHITE)
        footer.pack(fill='x',padx=16,pady=(18,16))
        def save_project():
            if self.processing:
                messagebox.showinfo('Đang xử lý','Hãy hoàn tất thao tác trước khi sửa project.')
                return
            try:
                fields=self._validate_project_fields(name_var.get(),
                       description_entry.get('1.0','end-1c'),source_var.get(),folder_var.get())
                self._save_project_fields(project['id'],fields)
                self._status('Đã lưu project: '+fields[0])
            except (ValueError,OSError) as exc:
                messagebox.showwarning('Thông tin project chưa hợp lệ',str(exc),parent=self.root)
        self.button(footer,'Lưu project',save_project,primary=True,
                    icon_name='project_save').pack(side='left')
        self.button(footer,'Chuyển sang project',lambda pid=project['id']:self._select_project_from_page(pid),
                    icon_name='project_switch').pack(side='left',padx=(8,0))
        self.button(footer,'Xóa project',lambda pid=project['id']:self.delete_project(pid),
                    icon_name='project_delete').pack(side='right')

    def _duplicate_project(self):
        if self.processing:
            messagebox.showinfo('Đang xử lý','Không thể đổi project khi đang xử lý ảnh.')
            return
        source=self.project_store.get(self.selected_project_id)
        draft={'name':source['name']+' (bản sao)', 'description':source.get('description',''),
               'destination':'', 'last_source':source.get('last_source','')}
        result=self._project_dialog('Nhân bản project',draft)
        if not result:
            return
        try:
            duplicate=self.project_store.add(*result)
            # Keep independent settings, but never overwrite fields chosen in the dialog.
            keys=[k for k in source if k not in ('id','name','description','destination','last_source')]
            for key in keys:
                value=source[key]
                duplicate[key]=value.copy() if isinstance(value,(dict,list)) else value
            if result[3] != source.get('last_source',''):
                duplicate['last_sheet']=''
                duplicate['last_column']=0
                duplicate['last_prompt_column']=0
            self.project_store.save()
            self.activate_project(duplicate['id'])
            self.selected_project_id=duplicate['id']
            self.refresh_projects_page()
        except ValueError as exc:
            messagebox.showerror('Không nhân bản được',str(exc))

    def _select_project_from_page(self, project_id):
        self.activate_project(project_id)
        self.show_page("workspace")
