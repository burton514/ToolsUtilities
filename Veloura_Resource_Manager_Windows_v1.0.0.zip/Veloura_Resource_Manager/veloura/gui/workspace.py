"""WorkspaceUI: presentation and interaction for workspace."""
from veloura.gui.theme import BG, BLACK, BORDER, F, FIELD, INK, MED, MUTED, SMALL, SOFT, WHITE
from PIL import Image, ImageTk
from pathlib import Path
from imageflow_core import SUPPORTED_EXTENSIONS, assemble_prompt
from reference_library import contact_sheet, enabled_references, remove_reference, set_reference_selection, unique_paths
from clipboard_image import copy_image_to_clipboard
from tkinter import filedialog, messagebox, ttk
import tempfile
import tkinter as tk


class WorkspaceUI:
    def _build_sidebar(self):
        header = self._section_title(self.left, 'Danh sách Image Gen', icon_name='data_list')
        header.pack(fill='x', padx=11, pady=(12, 7))
        actions = tk.Frame(self.left, bg=WHITE)
        actions.pack(fill='x', padx=10, pady=(0, 6))
        self.button(actions, 'Excel / CSV', self.open_source, primary=True, icon_name='data_import', small=True).pack(side='left', fill='x', expand=True)
        self.button(actions, 'Đường dẫn', self.paste_source_path, icon_name='data_paste_path', small=True).pack(side='left', padx=(6, 0))
        line = tk.Frame(self.left, bg=WHITE)
        line.pack(fill='x', padx=11, pady=(0, 5))
        self.recent_file_lbl = self.txt(line, 'Chưa có dữ liệu', 9, MUTED, anchor='w')
        self.recent_file_lbl.pack(side='left', fill='x', expand=True)
        self.recent_btn = self.button(line, 'Gần đây', self.open_recent, small=True)
        if self.settings.get('last_source') and Path(self.settings['last_source']).is_file():
            self.recent_btn.pack(side='right')
        # Keep the source-column mapping visible at all times.  The previous
        # UI auto-collapsed this section after loading and hid a critical input.
        self.source_options_frame = tk.Frame(
            self.left, bg=SOFT, highlightbackground=BORDER, highlightthickness=1)
        self.source_options_frame.pack(fill='x', padx=10, pady=(0, 7))
        self.txt(self.source_options_frame, 'LIÊN KẾT CỘT DỮ LIỆU', 9, INK, True,
                 bg=SOFT).pack(anchor='w', padx=9, pady=(7, 3))

        def source_row(title, variable, callback, optional=False):
            row = tk.Frame(self.source_options_frame, bg=SOFT)
            row.pack(fill='x', padx=9, pady=(0, 4))
            self.txt(row, title, 9, MUTED if optional else INK,
                     bg=SOFT, anchor='w', width=12).pack(side='left')
            combo = ttk.Combobox(row, state='readonly', textvariable=variable,
                                 style='Veloura.TCombobox', font=SMALL, width=15)
            combo.pack(side='left', fill='x', expand=True)
            combo.bind('<<ComboboxSelected>>', callback)
            return combo

        self.sheet_combo = source_row('Sheet / CSV', self.sheet_var,
                                      lambda e: self.on_sheet_changed())
        self.column_combo = source_row('Cột tên Image Gen', self.column_var,
                                       lambda e: self.load_selected_column())
        self.prompt_column_combo = source_row('Cột Prompt', self.prompt_column_var,
                                              lambda e: self.load_selected_column(), optional=True)
        ttk.Checkbutton(self.source_options_frame, text='Dòng đầu là tiêu đề',
                        variable=self.has_header, command=self.on_header_changed,
                        style='Veloura.TCheckbutton').pack(anchor='w', padx=9, pady=(0, 6))
        self.counter = self.txt(self.left, '0 / 0 đã có ảnh', 10, INK, True)
        self.counter.pack(anchor='w', padx=11, pady=(4, 6))
        search_row = tk.Frame(self.left, bg=WHITE)
        search_row.pack(fill='x', padx=10, pady=(0, 6))
        entry = self._field(search_row, self.search_var)
        entry.pack(side='left', fill='x', expand=True, ipady=5)
        filter_combo = ttk.Combobox(search_row, textvariable=self.filter_var, state='readonly',
                     values=['Tất cả', 'Chưa xong', 'Đã có ảnh', 'Cần xem xét'], style='Veloura.TCombobox', width=9, font=SMALL)
        filter_combo.pack(side='left', padx=(6, 0))
        treebox = tk.Frame(self.left, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        treebox.pack(fill='both', expand=True, padx=10, pady=(0, 7))
        self.tree = ttk.Treeview(treebox, columns=('name','status'), show='headings',
                     selectmode='browse', style='Veloura.Treeview')
        self.tree.heading('name', text='Tên Image Gen')
        self.tree.heading('status', text='Trạng thái')
        self.tree.column('name', width=137, minwidth=90, stretch=True)
        self.tree.column('status', width=92, stretch=False, anchor='center')
        self.tree.pack(side='left', fill='both', expand=True)
        sy = ttk.Scrollbar(treebox, orient='vertical', command=self.tree.yview, style='Veloura.Vertical.TScrollbar')
        sy.pack(side='right', fill='y')
        self.tree.configure(yscrollcommand=sy.set)
        self.tree.tag_configure('done', foreground='#333333')
        self.tree.tag_configure('existing', foreground='#333333')
        self.tree.tag_configure('review', foreground='#111111')
        self.tree.tag_configure('invalid', foreground='#000000')
        self.tree.bind('<<TreeviewSelect>>', self.on_tree_select)
        self.tree.bind('<Double-1>', lambda e: self.choose_picture())
        row = tk.Frame(self.left, bg=WHITE)
        row.pack(fill='x', padx=10, pady=(0, 10))
        self.button(row, 'Thêm tên', self.add_name, icon_name='data_add_name', small=True).pack(side='left', fill='x', expand=True)
        self.button(row, 'Sửa tên', self.rename_item, icon_name='data_edit_name', small=True).pack(side='left', fill='x', expand=True, padx=(6, 0))

    def toggle_source_details(self, expanded=None):
        """The modern UI always exposes sheet/name/prompt column selectors.

        The base import pipeline still calls this method with False after a
        successful read; ignoring that collapse is intentional, so the user
        can correct an accidentally selected STT/number column immediately.
        """
        if not self.source_options_frame.winfo_manager():
            self.source_options_frame.pack(fill='x', padx=10, pady=(0, 7),
                                           before=self.counter)

    def _build_main_panel(self):
        shell, self.workspace_scroll, main = self._scroll_area(self.right_frame)
        shell.pack(fill='both', expand=True)
        self.main_inner = main
        # Route wheel events from all Workspace descendants. Base scroll-area
        # handlers on just canvas/inner would double-scroll after routing.
        for holder in (self.workspace_scroll, self.main_inner):
            for event_name in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
                holder.unbind(event_name)
        self._install_workspace_wheel_router()
        main.grid_columnconfigure(0, weight=1)
        top = tk.Frame(main, bg=BG)
        top.grid(row=0, column=0, sticky='ew', pady=(0, 8))
        self.txt(top, 'Làm việc với Image Gen', 17, INK, True, bg=BG).pack(side='left')
        self.button(top, 'Tiếp theo', self.select_next, icon_name='next_item', small=True).pack(side='right')
        self.button(top, 'Trước', self.select_previous, icon_name='previous_item', small=True).pack(side='right', padx=6)

        selection = self._surface(main)
        selection.grid(row=1, column=0, sticky='ew', pady=(0, 8))
        self.txt(selection, 'Tên Image Gen', 10, INK, True).pack(side='left', padx=(12, 8), pady=9)
        self.target_lbl = self.txt(selection, 'Chưa chọn tên ảnh', 11, INK, True, bg=SOFT, anchor='w', wraplength=310, justify='left')
        self.target_lbl.pack(side='left', fill='x', expand=True, padx=(0, 8), pady=9)
        self.target_details = self.txt(selection, 'Chưa chọn', 9, MUTED)
        self.target_details.pack(side='right', padx=12)

        self.prompt_ref_row = tk.Frame(main, bg=BG)
        self.prompt_ref_row.grid(row=2, column=0, sticky='ew', pady=(0, 8))
        self.prompt_ref_row.grid_columnconfigure(0, weight=5)
        self.prompt_ref_row.grid_columnconfigure(1, weight=5)
        self._refs_side_by_side = True

        self.prompt_card = self._surface(self.prompt_ref_row)
        self.prompt_card.grid(row=0, column=0, sticky='nsew', padx=(0, 5))
        prompt_head = self._section_title(self.prompt_card, 'Prompt', icon_name='prompt_content')
        prompt_head.pack(fill='x', padx=10, pady=(9, 5))
        self.copy_prompt_btn = self.button(prompt_head, 'Copy', self.copy_prompt,
                                           icon_name='prompt_copy', small=True)
        self.copy_prompt_btn.pack(side='right')
        prompt_wrap = tk.Frame(self.prompt_card, bg=FIELD, highlightbackground=BORDER, highlightthickness=1)
        prompt_wrap.pack(fill='both', expand=True, padx=10, pady=(0, 10))
        self.prompt_text = tk.Text(prompt_wrap, height=3, bg=FIELD, fg=INK,
                      bd=0, relief='flat', font=F, padx=10, pady=8,
                      wrap='word', state='disabled', insertbackground=INK)
        self.prompt_text.pack(side='left', fill='both', expand=True)
        prompt_scroll = ttk.Scrollbar(prompt_wrap, orient='vertical', command=self.prompt_text.yview)
        prompt_scroll.pack(side='right', fill='y')
        self.prompt_text.configure(yscrollcommand=prompt_scroll.set)
        self._set_prompt_text('Chọn tên Image Gen để xem nội dung Prompt.')

        self.refs_card = self._surface(self.prompt_ref_row)
        self.refs_card.grid(row=0, column=1, sticky='nsew', padx=(5, 0))
        refs_head = self._section_title(self.refs_card, 'Ảnh mẫu', icon_name='reference_library')
        refs_head.pack(fill='x', padx=9, pady=(9, 5))
        self.refs_counter = self.txt(refs_head, '(0)', 9, MUTED)
        self.refs_counter.pack(side='left', padx=4)
        self.button(refs_head, 'Thêm', self.choose_reference, icon_name='reference_add', small=True).pack(side='right')
        # A dedicated thumbnail viewport, with the scrollbar *outside* the tiles.
        # Previous 80 px viewport cropped the filename and the lower image edge.
        self.ref_scroll_canvas = tk.Canvas(self.refs_card, height=119, bg=WHITE,
                                            bd=0, highlightthickness=0)
        self.ref_scroll_canvas.pack(fill='x', padx=9)
        self.ref_tiles = tk.Frame(self.ref_scroll_canvas, bg=WHITE)
        self.ref_win = self.ref_scroll_canvas.create_window(
            (0, 0), window=self.ref_tiles, anchor='nw')
        self.ref_tiles.bind('<Configure>', self._update_reference_scroll_region)
        self.ref_scroll_canvas.bind('<Configure>', self._update_reference_scroll_region)
        self.ref_horizontal_scroll = ttk.Scrollbar(
            self.refs_card, orient='horizontal', command=self.ref_scroll_canvas.xview,
            style='Veloura.Horizontal.TScrollbar')
        self.ref_scroll_canvas.configure(xscrollcommand=self.ref_horizontal_scroll.set)
        # It is shown only when the project has more images than fit.
        controls = tk.Frame(self.refs_card, bg=WHITE)
        self.ref_controls = controls
        controls.pack(fill='x', padx=9, pady=(6, 9))
        self.button(controls, 'Copy ảnh chọn', self.copy_reference, primary=True,
                    icon_name='reference_copy', small=True).pack(side='left', fill='x', expand=True)
        self.button(controls, 'Quản lý', lambda: self.show_page('references'), small=True).pack(side='left', padx=(6, 0))

        self.io_row = tk.Frame(main, bg=BG)
        self.io_row.grid(row=3, column=0, sticky='ew', pady=(0, 8))
        self.io_row.grid_columnconfigure(0, weight=1)
        self.io_row.grid_columnconfigure(1, weight=1)
        input_card = self._surface(self.io_row)
        input_card.grid(row=0, column=0, sticky='nsew', padx=(0, 5))
        head = self._section_title(input_card, 'Ảnh đầu vào', icon_name='image_import')
        head.pack(fill='x', padx=11, pady=(9, 5))
        self.button(head, 'Chọn ảnh', self.choose_picture, icon_name='image_open', small=True).pack(side='right')
        self.drop_canvas = tk.Canvas(input_card, height=74, bg=WHITE, bd=0,
                                     cursor='hand2', highlightthickness=0)
        self.drop_canvas.pack(fill='both', expand=True, padx=10, pady=(0, 6))
        self.drop_canvas.bind('<Button-1>', lambda e: self.choose_picture())
        self.button(input_card, 'Dán ảnh (Ctrl+V)', self.paste_image_from_clipboard,
                    primary=True, icon_name='image_paste').pack(fill='x', padx=10, pady=(0, 10))
        self.paint_dropzone()
        try:
            from tkinterdnd2 import DND_FILES
            self.drop_canvas.drop_target_register(DND_FILES)
            self.drop_canvas.dnd_bind('<<Drop>>', self.on_drop)
            self.drop_canvas.dnd_bind('<<DropEnter>>', lambda e: self.set_drop_active(True))
            self.drop_canvas.dnd_bind('<<DropLeave>>', lambda e: self.set_drop_active(False))
        except (ImportError, tk.TclError):
            pass

        output_card = self._surface(self.io_row)
        output_card.grid(row=0, column=1, sticky='nsew', padx=(5, 0))
        head = self._section_title(output_card, 'Ảnh đầu ra', icon_name='image_output')
        head.pack(fill='x', padx=11, pady=(9, 5))
        self.preview_box = tk.Frame(output_card, bg=FIELD, highlightbackground=BORDER, highlightthickness=1)
        self.preview_box.pack(fill='both', expand=True, padx=10, pady=(0, 7))
        self.preview_empty = tk.PhotoImage(width=1, height=1)
        self.preview_img = tk.Label(self.preview_box, image=self.preview_empty, bg=FIELD,
                                    height=92, width=156)
        self.preview_img.pack(pady=(4, 2))
        self.preview_title = self.txt(self.preview_box, 'Chưa có ảnh cho Image Gen này', 10, INK, True, bg=FIELD)
        self.preview_title.pack()
        self.preview_sub = self.txt(self.preview_box, 'Đọc trực tiếp từ thư mục project', 9, MUTED, bg=FIELD)
        self.preview_sub.pack(pady=(2, 5))
        review_row = tk.Frame(output_card, bg=WHITE)
        review_row.pack(fill='x', padx=10, pady=(0, 7))
        self.review_toggle_btn = self.button(review_row, 'Đánh dấu cần xem xét', self.toggle_review_for_selected,
                    icon_name='gallery_flag', small=True)
        self.review_toggle_btn.pack(side='left', fill='x', expand=True)
        self.button(output_card, 'Mở thư mục ảnh', self.open_destination,
                    icon_name='project_open_folder', small=True).pack(fill='x', padx=10, pady=(0, 10))

        settings = self._surface(main)
        settings.grid(row=4, column=0, sticky='ew', pady=(0, 8))
        head = self._section_title(settings, 'Thiết lập xuất ảnh', icon_name='resize')
        head.pack(fill='x', padx=10, pady=(9, 5))
        folder = tk.Frame(settings, bg=WHITE)
        folder.pack(fill='x', padx=10, pady=(0, 6))
        self.txt(folder, 'Thư mục đích', 9, INK, True).pack(side='left', padx=(0, 8))
        dest = self._field(folder, self.destination)
        dest.pack(side='left', fill='x', expand=True, ipady=5)
        dest.bind('<Return>', lambda e: self._destination_changed())
        dest.bind('<FocusOut>', lambda e: self._destination_changed())
        self.button(folder, '…', self.pick_destination, icon_name='project_browse', small=True).pack(side='left', padx=(5, 0))
        row = tk.Frame(settings, bg=WHITE)
        row.pack(fill='x', padx=10, pady=(0, 6))
        self.txt(row, 'Chế độ', 9, INK, True).pack(side='left', padx=(0, 6))
        ttk.Radiobutton(row, text='Copy', variable=self.operation, value='copy', style='Veloura.TRadiobutton').pack(side='left')
        ttk.Radiobutton(row, text='Move', variable=self.operation, value='move', style='Veloura.TRadiobutton').pack(side='left', padx=(4, 8))
        self.txt(row, 'Resize', 9, INK, True).pack(side='left', padx=(4, 4))
        ttk.Checkbutton(row, variable=self.resize_enabled, text='Bật', command=self.on_resize_toggled,
                    style='Veloura.TCheckbutton').pack(side='left')
        self.width_input = self._field(row, self.width_var, width=5)
        self.width_input.pack(side='left', padx=(5, 1), ipady=4)
        self.txt(row, '×', 10, INK).pack(side='left')
        self.height_input = self._field(row, self.height_var, width=5)
        self.height_input.pack(side='left', padx=(1, 5), ipady=4)
        self.resize_combo = ttk.Combobox(row, values=list(self._resize_options()),
                            textvariable=self.resize_mode, state='readonly', width=19,
                            style='Veloura.TCombobox', font=SMALL)
        self.resize_combo.pack(side='left', padx=(2, 0))
        format_row = tk.Frame(settings, bg=WHITE)
        format_row.pack(fill='x', padx=10, pady=(0, 6))
        self.txt(format_row, 'Định dạng xuất', 9, INK, True).pack(side='left', padx=(0, 8))
        self.output_format_combo = ttk.Combobox(
            format_row, values=['png', 'jpg', 'webp', 'bmp', 'tiff'],
            textvariable=self.output_format, state='readonly', width=10,
            style='Veloura.TCombobox', font=SMALL)
        self.output_format_combo.pack(side='left')
        self.txt(format_row, 'JPG / BMP: nền trắng khi ảnh trong suốt', 9, MUTED).pack(
            side='left', padx=(10, 0))
        conflict = tk.Frame(settings, bg=WHITE)
        conflict.pack(fill='x', padx=10, pady=(0, 8))
        self.txt(conflict, 'Trùng tên', 9, INK, True).pack(side='left', padx=(0, 8))
        self.conflict_combo = ttk.Combobox(conflict, values=list(self._conflict_options()),
                          textvariable=self.conflict, state='readonly', width=22,
                          style='Veloura.TCombobox', font=SMALL)
        self.conflict_combo.pack(side='left')
        ttk.Checkbutton(conflict, text='Tự chuyển tên tiếp theo', variable=self.advance,
                        style='Veloura.TCheckbutton').pack(side='right')
        self.resize_note = self.txt(settings, 'Giữ tỷ lệ và nền trong suốt', 9, MUTED)
        # Explanation is available in the resize selector, do not consume vertical workspace space.
        self.resize_note.pack_forget()
        self.on_resize_toggled()

        log = self._surface(main)
        log.grid(row=5, column=0, sticky='ew', pady=(0, 8))
        log_line=tk.Frame(log,bg=WHITE)
        log_line.pack(fill='x',padx=10,pady=7)
        self.txt(log_line,'Nhật ký',10,INK,True).pack(side='left',padx=(0,8))
        self.button(log_line,'CSV',self.export_logs,icon_name='data_csv',small=True).pack(side='right')
        self.activity = tk.Text(log_line, height=1, bg=FIELD, fg=INK, font=SMALL,
                                relief='flat', bd=0, wrap='word', padx=6, pady=5)
        self.activity.pack(side='left',fill='x',expand=True)
        self.activity.insert('end','Chưa có ảnh nào được xử lý trong phiên này.\n')
        self.activity.configure(state='disabled')
        status = tk.Frame(main, bg=BG)
        status.grid(row=6, column=0, sticky='ew')
        self.status_lbl = self.txt(status, 'Sẵn sàng', 9, MUTED, bg=BG, anchor='w')
        self.status_lbl.pack(side='left')

    @staticmethod
    def _resize_options():
        return ['Giữ tỷ lệ · thêm nền trong suốt', 'Phủ đầy khung · cắt giữa',
                'Kéo giãn · đúng kích thước']

    @staticmethod
    def _conflict_options():
        return ['Hỏi trước khi ghi đè', 'Tự động ghi đè', 'Bỏ qua nếu đã có']

    def _responsive_workspace(self, event=None):
        # Below 670px place Prompt above references; avoid side-by-side clipping.
        if not hasattr(self, 'prompt_ref_row'):
            return
        width = self.right_frame.winfo_width()
        if hasattr(self, 'target_lbl'):
            # Quantize width to avoid re-laying out text for every pixel dragged.
            wrap = max(170, ((max(width - 280, 0)) // 24) * 24)
            if getattr(self, '_target_wrap_width', None) != wrap:
                self._target_wrap_width = wrap
                self.target_lbl.configure(wraplength=wrap)
        adjacent = width >= 720
        if adjacent == self._refs_side_by_side:
            return
        self._refs_side_by_side = adjacent
        self.prompt_card.grid_forget()
        self.refs_card.grid_forget()
        self.prompt_ref_row.grid_columnconfigure(0, weight=5)
        self.prompt_ref_row.grid_columnconfigure(1, weight=5 if adjacent else 0)
        if adjacent:
            self.prompt_card.grid(row=0, column=0, sticky='nsew', padx=(0,5))
            self.refs_card.grid(row=0, column=1, sticky='nsew', padx=(5,0))
        else:
            self.prompt_card.grid(row=0, column=0, sticky='ew', pady=(0,6))
            self.refs_card.grid(row=1, column=0, sticky='ew')

    def _resize_right_content(self, event):
        self._responsive_workspace(event)

    def _update_counter(self):
        complete = sum(1 for item in self.items if item.state in ('existing','done','review'))
        valid = sum(1 for item in self.items if item.state != 'invalid')
        self.counter.configure(text=f'{complete} / {valid} đã có ảnh')

    def paint_dropzone(self):
        c = self.drop_canvas
        c.delete('all')
        width = max(160, c.winfo_width())
        height = max(80, c.winfo_height())
        c.create_rectangle(4, 4, width - 4, height - 4,
                           outline=BLACK, width=2, dash=(6, 5), fill=WHITE)
        c.create_text(width/2, height/2 - 16, text='↓', fill=INK, font=('Segoe UI Semibold', 24))
        c.create_text(width/2, height/2 + 12, text='Kéo thả ảnh vào đây', fill=INK, font=MED)
        if self.processing:
            c.create_text(width/2, height - 15, text='Đang xử lý…', fill=MUTED, font=SMALL)

    def select_previous(self):
        if not self.items:
            return
        idx = self.selected_index if self.selected_index is not None else 0
        self.select_by_index((idx - 1) % len(self.items))

    def _update_review_controls(self):
        item = self.items[self.selected_index] if self.selected_index is not None and 0 <= self.selected_index < len(self.items) else None
        reviewed = bool(item and self._is_reviewed_name(item.name))
        can_toggle = self._can_mark_review(item) if item is not None else False
        if hasattr(self, 'review_toggle_btn'):
            self.review_toggle_btn.configure(text='Bỏ đánh dấu xem xét' if reviewed else 'Đánh dấu cần xem xét',
                                             state='normal' if can_toggle else 'disabled')
        if hasattr(self, 'gallery_review_btn'):
            gallery_item = None
            if getattr(self, '_gallery_selected', None):
                g_index, g_name, _ = self._gallery_selected
                if g_index is not None and 0 <= g_index < len(self.items):
                    gallery_item = self.items[g_index]
                elif g_name:
                    gallery_item = next((entry for entry in self.items if entry.name == g_name), None)
            gallery_reviewed = bool(gallery_item and self._is_reviewed_name(gallery_item.name))
            gallery_can = self._can_mark_review(gallery_item) if gallery_item is not None else False
            self.gallery_review_btn.configure(text='Bỏ đánh dấu xem xét' if gallery_reviewed else 'Đánh dấu cần xem xét',
                                              state='normal' if gallery_can else 'disabled')

    def _refresh_selected_output_preview(self):
        """Show only the selected icon's real file in the active project folder.

        No output file is imported or copied into application storage. Only a
        small PhotoImage lives in RAM while the icon is being displayed.
        """
        if not hasattr(self, 'preview_img'):
            return
        from output_preview import resolve_selected_output, preview_identity

        current = resolve_selected_output(
            getattr(self, '_folder_snapshot', None), self.destination.get().strip(),
            self.items, self.selected_index,
            self.output_format.get() if hasattr(self, 'output_format') else 'png',
        )
        project_id = getattr(getattr(self, 'project_store', None), 'active_id', None)
        key = preview_identity(project_id, current)
        if key is None:
            selected = (self.items[self.selected_index] if self.selected_index is not None
                        and 0 <= self.selected_index < len(self.items) else None)
            key = (project_id, selected.name if selected else None,
                   selected.state if selected else None, self.destination.get().strip())
        if key == getattr(self, '_output_preview_key', object()):
            return
        self._output_preview_key = key
        self.preview_ref = None
        if current is None:
            self.preview_img.configure(image=self.preview_empty, text='', width=156, height=92)
            selected = (self.items[self.selected_index] if self.selected_index is not None
                        and 0 <= self.selected_index < len(self.items) else None)
            if selected is not None and selected.state == 'corrupt':
                self.preview_title.configure(text=selected.name + '.png')
                self.preview_sub.configure(text='Ảnh bị lỗi hoặc chưa ghi xong; chưa tính là đã có')
            else:
                self.preview_title.configure(text='Chưa có ảnh cho Image Gen này')
                self.preview_sub.configure(text='Chưa tìm thấy ảnh trong thư mục project')
            return

        try:
            if hasattr(self, '_cached_thumbnail'):
                photo, dimensions = self._cached_thumbnail(current.path, (146, 86), icon_file=current)
            else:  # Compatibility for lightweight preview adapters in integrations.
                with Image.open(current.path) as source:
                    dimensions = source.size
                    thumbnail = source.convert('RGBA')
                    thumbnail.thumbnail((146, 86), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(thumbnail)
            self.preview_ref = photo
            self.preview_img.configure(image=photo, text='', width=156, height=92)
            self.preview_title.configure(text=current.path.name if len(current.path.name) <= 32
                                         else current.path.name[:29] + '…')
            self.preview_sub.configure(text=f'{dimensions[0]} × {dimensions[1]} px  ·  Trong thư mục project')
        except (OSError, ValueError) as exc:
            # Keep the real filename visible even if an external writer is still
            # writing the file; next filesystem modification retries the preview.
            self.preview_img.configure(image=self.preview_empty, text='', width=156, height=92)
            self.preview_title.configure(text=current.path.name[:32])
            self.preview_sub.configure(text='Chưa đọc được ảnh; đang chờ file hoàn tất')

    def _show_preview(self, path: Path, width, height):
        """Reconcile the just-exported file, never pin a historical image."""
        self.refresh_existing_states()
        self._refresh_selected_output_preview()

    def rename_item(self):
        old = self.items[self.selected_index].name if self.selected_index is not None and self.selected_index < len(self.items) else None
        self._rename_source_item()
        new = self.items[self.selected_index].name if self.selected_index is not None and self.selected_index < len(self.items) else None
        if old and new and old != new and old in self.reference_assignments:
            self.reference_assignments[new] = self.reference_assignments.pop(old)
            self._store_reference_config()
            self._render_reference()
        if old and new and old != new and self._is_reviewed_name(old):
            self._set_review_mark(old, False, persist=False)
            self._set_review_mark(new, True, persist=False)
            self._store_review_marks(persist=True)

    def _restore_reference(self):
        profile = self.project_store.active
        paths = profile.get('reference_paths')
        legacy = profile.get('reference_path', '')
        if not isinstance(paths, list):
            paths = [legacy] if legacy else []
        self.reference_paths = unique_paths(paths)
        mapping = profile.get('reference_assignments', {})
        self.reference_assignments = mapping if isinstance(mapping, dict) else {}
        self._chosen_reference = self.reference_paths[0] if self.reference_paths else None
        self._render_reference()
        if hasattr(self, 'references_body'):
            self._refresh_reference_page()

    def _update_reference_scroll_region(self, event=None):
        """Keep the horizontal scroller separate from complete thumbnail tiles."""
        if not hasattr(self, 'ref_scroll_canvas'):
            return
        canvas = self.ref_scroll_canvas
        canvas.configure(scrollregion=canvas.bbox('all'))
        if not hasattr(self, 'ref_horizontal_scroll'):
            return
        # Canvas's embedded frame can be wider than the viewport. When it isn't,
        # don't consume valuable height with a disabled horizontal scrollbar.
        required = self.ref_tiles.winfo_reqwidth()
        available = canvas.winfo_width()
        needed = required > max(available, 1) + 2
        shown = bool(self.ref_horizontal_scroll.winfo_manager())
        if needed and not shown:
            self.ref_horizontal_scroll.pack(
                fill='x', padx=9, pady=(0, 1), before=self.ref_controls)
        elif not needed and shown:
            self.ref_horizontal_scroll.pack_forget()
            canvas.xview_moveto(0)

    def _render_reference(self):
        if not hasattr(self, 'ref_tiles'):
            return
        for child in self.ref_tiles.winfo_children():
            child.destroy()
        self.reference_thumb_refs = []
        item = self.items[self.selected_index] if self.selected_index is not None and self.selected_index < len(self.items) else None
        name = item.name if item else None
        enabled = enabled_references(self.reference_paths, self.reference_assignments, name) if name else self.reference_paths
        self.refs_counter.configure(text=f'({len(enabled)}/{len(self.reference_paths)})')
        if not self.reference_paths:
            self.txt(self.ref_tiles, 'Chưa có ảnh mẫu — chọn Thêm', 9, MUTED).pack(padx=8, pady=28)
            return
        for path in self.reference_paths:
            active = path in enabled
            tile = tk.Frame(self.ref_tiles, bg=SOFT if active else WHITE,
                           highlightbackground=BLACK if active else BORDER, highlightthickness=1)
            tile.pack(side='left', padx=4, pady=(3, 3))
            frame = tk.Frame(tile, bg=SOFT if active else WHITE)
            frame.pack(padx=5, pady=(5, 2))
            photo = None
            if Path(path).is_file():
                try:
                    photo, _ = self._cached_thumbnail(path, (60, 50))
                    self.reference_thumb_refs.append(photo)
                except Exception:
                    pass
            lbl = tk.Label(frame, image=photo if photo else self.thumbnail_placeholder,compound='center',
                           text='' if photo else 'Thiếu ảnh', bg=SOFT if active else WHITE,
                           width=74, height=58, fg=MUTED, font=SMALL,
                           cursor='hand2')
            lbl.pack()
            tag = ('✓ ' if active else '○ ') + Path(path).stem[:9]
            status = tk.Label(tile, text=tag, font=SMALL, fg=INK, bg=SOFT if active else WHITE, cursor='hand2')
            status.pack(padx=4, pady=(2, 6))
            for widget in (tile, lbl, status):
                widget.bind('<Button-1>', lambda e, p=path: self._toggle_reference_for_icon(p))
        # Tk's Configure events will settle the scroller; do not synchronously
        # flush every layout operation when selecting icons rapidly.
        self.root.after_idle(self._update_reference_scroll_region)

    def _toggle_reference_for_icon(self, path):
        if self.selected_index is None or self.selected_index >= len(self.items):
            self._chosen_reference = path
            self._status('Chọn tên Image Gen trước khi gán bộ ảnh mẫu riêng.')
            return
        name = self.items[self.selected_index].name
        current = enabled_references(self.reference_paths, self.reference_assignments, name)
        self.reference_assignments = set_reference_selection(
            self.reference_paths, self.reference_assignments, name, path, path not in current)
        self._chosen_reference = path
        self._store_reference_config()
        self._render_reference()

    def _store_reference_config(self):
        self.project_store.active['reference_paths'] = self.reference_paths.copy()
        self.project_store.active['reference_assignments'] = dict(self.reference_assignments)
        self.settings['reference_paths'] = self.reference_paths.copy()
        self.settings['reference_assignments'] = dict(self.reference_assignments)
        self.reference_path.set(self.reference_paths[0] if self.reference_paths else '')
        self.project_store.save()

    def choose_reference(self):
        paths = filedialog.askopenfilenames(parent=self.root, title='Thêm ảnh mẫu vào project',
                    filetypes=[('Ảnh hỗ trợ', '*.png *.jpg *.jpeg *.webp *.bmp *.gif *.tif *.tiff *.avif'),
                               ('Tất cả file', '*.*')])
        for path in paths:
            self.set_reference(path)

    def set_reference(self, path):
        source = Path(path)
        if source.suffix.lower() not in SUPPORTED_EXTENSIONS or not source.is_file():
            messagebox.showerror('Ảnh mẫu không hợp lệ', f'Không tìm thấy ảnh hợp lệ: {source.name}')
            return
        try:
            with Image.open(source) as image:
                image.verify()
        except Exception as exc:
            messagebox.showerror('Không mở được ảnh mẫu', str(exc))
            return
        paths = unique_paths(self.reference_paths + [str(source)])
        self.reference_paths = paths
        self._chosen_reference = str(source)
        self._store_reference_config()
        self._render_reference()
        self._refresh_reference_page()
        self._status('Đã thêm ảnh mẫu: ' + source.name)

    def clear_reference(self):
        if not self._chosen_reference:
            return
        self._remove_reference(self._chosen_reference)

    def _remove_reference(self, path):
        self.reference_paths, self.reference_assignments = remove_reference(
                                self.reference_paths, self.reference_assignments, path)
        self._chosen_reference = self.reference_paths[0] if self.reference_paths else None
        self._store_reference_config()
        self._render_reference()
        self._refresh_reference_page()

    def copy_reference(self):
        name = self.items[self.selected_index].name if self.selected_index is not None and self.selected_index < len(self.items) else None
        choices = enabled_references(self.reference_paths, self.reference_assignments, name) if name else self.reference_paths
        valid = [path for path in choices if Path(path).is_file()]
        if not valid:
            messagebox.showinfo('Chưa chọn ảnh mẫu', 'Hãy thêm hoặc chọn ít nhất một ảnh mẫu cho Image Gen.')
            return
        try:
            if len(valid) == 1:
                copy_image_to_clipboard(valid[0])
            else:
                composite = contact_sheet(valid)
                temp = Path(tempfile.gettempdir()) / 'veloura_image_manager' / 'references'
                temp.mkdir(parents=True, exist_ok=True)
                filepath = temp / f'project_refs_{self.project_store.active_id}.png'
                composite.save(filepath, format='PNG')
                copy_image_to_clipboard(filepath)
            self._status(f'Đã copy {len(valid)} ảnh mẫu' + (' (một ảnh ghép)' if len(valid)>1 else ''))
        except Exception as exc:
            messagebox.showerror('Không sao chép được ảnh mẫu', str(exc))

    def _refresh_target(self):
        # Selection drives both reference selection and the real output preview.
        self._refresh_source_target()
        if hasattr(self, 'ref_tiles'):
            self._render_reference()
        self._refresh_selected_output_preview()

    def _update_empty_selection(self):
        self._update_source_empty_selection()
        if hasattr(self, 'ref_tiles'):
            self._render_reference()
        self._refresh_selected_output_preview()

    def persist_settings(self):
        if not self._changing_project:
            self.settings['reference_paths'] = self.reference_paths.copy()
            self.settings['reference_assignments'] = dict(self.reference_assignments)
            self.settings['prompt_template'] = self._get_template_text()
            self.settings['template_enabled'] = self.template_enabled.get()
        return self._persist_controller_settings()

    def _install_project(self, project):
        previous_id = getattr(self, 'selected_project_id', None)
        previous_folder = self.destination.get().strip() if hasattr(self, 'destination') else ''
        if (previous_id != project['id'] or previous_folder != project['destination']):
            self._thumbnail_cache.clear()  # Previous project must release RAM previews.
            self.gallery_thumb_refs = []
            self.reference_thumb_refs = []
            self.reference_library_photos = []
            self._gallery_render_key = None
            self._gallery_render_ticket += 1
            self._gallery_render_pending = False
        self.selected_project_id = project['id']
        self._template_loading = True
        try:
            self._install_controller_project(project)
        finally:
            self._template_loading = False
        self.template_enabled.set(bool(project.get('template_enabled', False)))
        if hasattr(self, 'template_text'):
            self._set_template_text(str(project.get('prompt_template') or ''))
        if hasattr(self, 'nav_project_name'):
            self.nav_project_name.configure(text=project['name'][:22])
        # Always discard the previous project's folder watch and cached file states.
        if getattr(self, '_live_monitor', None) is not None:
            self._rebind_folder_monitor(force=True)
        self._gallery_selected = None
        self._gallery_multi_selected.clear()
        self._gallery_selection_scope = (project['id'], project['destination'])
        if hasattr(self, 'gallery_batch_count'):
            self._gallery_update_batch_toolbar()
        self._gallery_preview_ref = None
        if hasattr(self, 'gallery_preview_name'):
            self.gallery_preview_name.configure(text='Chọn Image Gen để xem')
            self.gallery_preview_info.configure(text='')
            self.gallery_preview_photo.configure(image=self.thumbnail_placeholder, text='')
        self._refresh_prompt()

    def _get_template_text(self):
        if not hasattr(self, 'template_text'):
            return self.project_store.active.get('prompt_template', '')
        return self.template_text.get('1.0', 'end-1c')

    def _set_template_text(self, value):
        if hasattr(self, 'template_text'):
            self.template_text.delete('1.0', 'end')
            self.template_text.insert('1.0', value)

    def _assembled_prompt(self):
        if self.selected_index is None or self.selected_index >= len(self.items):
            return ''
        item = self.items[self.selected_index]
        return assemble_prompt(item.prompt, item.name,
                               self._get_template_text(), self.template_enabled.get())

    def _refresh_prompt(self):
        if not hasattr(self, 'prompt_text'):
            return
        if self.selected_index is None or self.selected_index >= len(self.items):
            value = 'Chọn một mục Image Gen trong danh sách để xem Prompt.'
        elif not self.selected_prompt_col_index():
            value = 'Chưa chọn cột Prompt. Mở Sheet / cột ở danh sách bên trái.'
        else:
            value = self._assembled_prompt() or 'Dòng này chưa có Prompt.'
        self._set_prompt_text(value)

    def copy_prompt(self):
        value = self._assembled_prompt()
        if not value.strip():
            messagebox.showinfo('Chưa có Prompt', 'Hãy chọn mục Image Gen có Prompt hoặc nhập Prompt mẫu.')
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(value)
        self.root.update_idletasks()
        self._status(f'Đã sao chép Prompt ({len(value)} ký tự)')

