"""GalleryUI: presentation and interaction for gallery."""
from veloura.gui.theme import BG, BLACK, BORDER, F, FIELD, INK, MUTED, SMALL, WHITE
from imageflow_core import OUTPUT_FORMATS
from pathlib import Path
from tkinter import messagebox, ttk
import os, subprocess, sys
import tkinter as tk


class GalleryUI:
    def _build_gallery_page(self, parent):
        title = tk.Frame(parent, bg=BG)
        title.pack(fill='x', pady=(6, 10))
        self.txt(title, 'Thư viện Image Gen', 18, INK, True, bg=BG).pack(side='left')
        self.button(title, 'Mở thư mục', self.open_destination, primary=True,
                    icon_name='project_open_folder', small=True).pack(side='right')
        self.button(title, 'Làm mới', self.refresh_from_disk, icon_name='gallery_refresh', small=True).pack(side='right', padx=8)
        tools = self._surface(parent)
        tools.pack(fill='x', pady=(0, 9))
        search = self._field(tools, self.gallery_search_var)
        search.pack(side='left', fill='x', expand=True, padx=10, pady=9, ipady=6)
        ttk.Combobox(tools, textvariable=self.gallery_filter_var, state='readonly',
                     values=['Tất cả','Đã có ảnh','Cần xem xét','Chưa có ảnh'], width=15,
                     style='Veloura.TCombobox', font=F).pack(side='left')
        self.gallery_stats = self.txt(tools, '0 ảnh', 10, INK, True)
        self.gallery_stats.pack(side='left', padx=12)
        batch_bar = self._surface(parent)
        batch_bar.pack(fill='x', pady=(0, 9))
        self.gallery_batch_count = self.txt(batch_bar, 'Đã chọn: 0 ảnh', 9, INK, True)
        self.gallery_batch_count.pack(side='left', padx=(10, 5), pady=7)
        self.gallery_batch_convert_btn = self.button(batch_bar, 'Đổi định dạng', self._gallery_batch_convert,
                                                      small=True, icon_name='image_output')
        self.gallery_batch_convert_btn.pack(side='right', padx=(3, 9), pady=5)
        self.gallery_batch_resize_btn = self.button(batch_bar, 'Resize', self._gallery_batch_resize,
                                                     small=True, icon_name='resize')
        self.gallery_batch_resize_btn.pack(side='right', padx=3, pady=5)
        self.gallery_batch_clear_btn = self.button(batch_bar, 'Bỏ chọn', self._gallery_clear_selection,
                                                    small=True)
        self.gallery_batch_clear_btn.pack(side='right', padx=3, pady=5)
        self.gallery_batch_all_btn = self.button(batch_bar, 'Chọn tất cả', self._gallery_select_all,
                                                  small=True)
        self.gallery_batch_all_btn.pack(side='right', padx=3, pady=5)
        self._gallery_update_batch_toolbar()
        content = tk.Frame(parent, bg=BG)
        content.pack(fill='both', expand=True)
        content.grid_columnconfigure(0, weight=1)
        content.grid_rowconfigure(0, weight=1)
        self.gallery_left = self._surface(content)
        self.gallery_left.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        wrap, self.gallery_canvas, self.gallery_inner = self._scroll_area(self.gallery_left, WHITE)
        wrap.pack(fill='both', expand=True)
        self.gallery_canvas.bind('<Configure>', self._on_gallery_canvas_configure, add='+')
        pagination = tk.Frame(self.gallery_left, bg=WHITE)
        pagination.pack(fill='x', padx=10, pady=8)
        self.button(pagination, '‹', lambda: self._change_gallery_page(-1), small=True).pack(side='left')
        self.gallery_paging = self.txt(pagination, '1 / 1', 10, INK, True)
        self.gallery_paging.pack(side='left', padx=10)
        self.button(pagination, '›', lambda: self._change_gallery_page(1), small=True).pack(side='left')
        self.gallery_preview_card = self._surface(content)
        self.gallery_preview_card.grid(row=0, column=1, sticky='ns')
        self.gallery_preview_card.configure(width=225)
        self.gallery_preview_card.pack_propagate(False)
        head = self._section_title(self.gallery_preview_card, 'Xem nhanh', icon_name='gallery_thumbnail')
        head.pack(anchor='w', padx=11, pady=(12, 10))
        self.gallery_preview_photo = tk.Label(self.gallery_preview_card, image=self.thumbnail_placeholder, bg=FIELD, width=188, height=180, compound='center')
        self.gallery_preview_photo.pack(padx=12, pady=(0, 8))
        self.gallery_preview_name = self.txt(self.gallery_preview_card, 'Chọn Image Gen để xem', 10, INK, True,
                                            justify='center', wraplength=195)
        self.gallery_preview_name.pack(padx=12)
        self.gallery_preview_info = self.txt(self.gallery_preview_card, '', 9, MUTED, justify='center',
                                            wraplength=190)
        self.gallery_preview_info.pack(pady=(8, 10), padx=12)
        self.gallery_open_btn = self.button(self.gallery_preview_card, 'Mở file', self._open_gallery_selected,
                                             icon_name='gallery_open', small=True)
        self.gallery_open_btn.pack(fill='x', padx=11, pady=(0, 6))
        self.gallery_review_btn = self.button(self.gallery_preview_card, 'Đánh dấu cần xem xét', self._toggle_gallery_review,
                                             icon_name='gallery_flag', small=True)
        self.gallery_review_btn.pack(fill='x', padx=11, pady=(0, 6))
        self.gallery_goto_btn = self.button(self.gallery_preview_card, 'Đi tới Workspace', self._goto_gallery_selected,
                                             primary=True, icon_name='nav_workspace', small=True)
        self.gallery_goto_btn.pack(fill='x', padx=11)
        self.gallery_search_var.trace_add('write', self._gallery_query_changed)
        self.gallery_filter_var.trace_add('write', self._gallery_query_changed)
        # Also allow scrolling over the persistent large preview and its controls.
        self._bind_gallery_wheel_children(self.gallery_preview_card)

    def _gallery_mouse_wheel(self, event):
        """Route wheel events on Gallery cards to their owning scroll canvas.

        Tk delivers wheel events to the widget under the pointer, not its parent.
        Each thumbnail/label/button therefore needs this binding after rendering.
        The handler is scoped to Gallery so other screens keep their own scrolling.
        """
        if self.current_page != 'gallery' or not self.gallery_canvas.winfo_viewable():
            return None
        number = getattr(event, 'num', None)
        if number in (4, 5):  # X11 / Linux
            units = -1 if number == 4 else 1
        else:  # Windows mouse wheel and high-resolution touchpads
            delta = getattr(event, 'delta', 0)
            if not delta:
                return None
            units = -(1 if delta > 0 else -1) * max(1, round(abs(delta) / 120))
        self.gallery_canvas.yview_scroll(units, 'units')
        return 'break'

    def _bind_gallery_wheel_children(self, parent):
        """Bind every descendant created inside Gallery, never application-wide."""
        for child in parent.winfo_children():
            child.bind('<MouseWheel>', self._gallery_mouse_wheel, add='+')
            child.bind('<Button-4>', self._gallery_mouse_wheel, add='+')
            child.bind('<Button-5>', self._gallery_mouse_wheel, add='+')
            self._bind_gallery_wheel_children(child)

    def _gallery_query_changed(self, *_):
        self._gallery_page_index = 0
        if self.current_page == 'gallery':
            self.refresh_gallery()

    def _on_gallery_canvas_configure(self, event=None):
        if not hasattr(self, 'gallery_canvas') or self.current_page != 'gallery':
            return
        columns = max(1, self.gallery_canvas.winfo_width() // 177)
        if columns == self._gallery_columns:
            return  # Moving the window does not imply relaying out the cards.
        self._gallery_columns = columns
        if self._gallery_resize_job is not None:
            self.root.after_cancel(self._gallery_resize_job)
        # Defer the expensive reflow until the user pauses resizing.
        self._gallery_resize_job = self.root.after(260, self._gallery_resize_done)

    def _gallery_resize_done(self):
        self._gallery_resize_job = None
        self.refresh_gallery()

    def _change_gallery_page(self, delta):
        self._gallery_page_index += delta
        self.refresh_gallery()
        self.gallery_canvas.yview_moveto(0)

    def _gallery_display_items(self):
        """Work from the existing worker-produced snapshot; no disk reads on the UI thread."""
        snapshot = self._folder_snapshot
        folder = self.destination.get().strip()
        if snapshot.folder != folder:
            # A new project's scan is still in flight; do not block dragging
            # the window while decoding/revalidating every PNG.
            from folder_live import FolderSnapshot
            snapshot = FolderSnapshot(folder=folder)
        preferred = self.output_format.get() if hasattr(self, 'output_format') else 'png'
        if self.items:
            entries = [(i, item.name, snapshot.for_icon(item.name, preferred), item.state)
                       for i, item in enumerate(self.items)]
        else:
            # Show only one card per stem even when multiple formats coexist.
            names = sorted({f.path.stem for f in snapshot.files.values()}, key=str.casefold)
            entries = [(None, name, snapshot.for_icon(name, preferred),
                        'existing' if snapshot.for_icon(name, preferred) else 'corrupt')
                       for name in names]
        query = self.gallery_search_var.get().strip().casefold()
        mode = self.gallery_filter_var.get()
        visible = []
        complete = 0
        for index, name, file_meta, state in entries:
            exists = file_meta is not None
            reviewed = state == 'review'
            complete += int(exists)
            if query and query not in name.casefold():
                continue
            if mode == 'Đã có ảnh' and not exists:
                continue
            if mode == 'Cần xem xét' and not reviewed:
                continue
            if mode == 'Chưa có ảnh' and exists:
                continue
            corrupt = snapshot.invalid_for_icon(name, preferred) if file_meta is None else None
            visible.append((index, name, file_meta, reviewed, bool(corrupt)))
        return visible, complete, len(entries)

    @staticmethod
    def _gallery_status_text(meta, reviewed, corrupt):
        if corrupt:
            return '⚠ Ảnh lỗi', BLACK
        if reviewed:
            return '◉ Cần xem xét', BLACK
        if meta is not None:
            return '✓ Đã có ảnh', BLACK
        return '○ Chưa có', MUTED

    @staticmethod
    def _gallery_can_reconcile_cards(previous, updated):
        """Reuse cards for changes within the same Gallery view.

        PNG creation, overwrite or deletion updates its own card. Project,
        pagination and layout changes still use the regular renderer.
        """
        return previous is not None and previous[:6] == updated[:6]

    def _make_gallery_card(self, index_in_page, entry, columns):
        """Create a Gallery card with reusable thumbnail and action widgets."""
        idx, name, meta, reviewed, corrupt = entry
        path = meta.path if meta is not None else None
        row, col = divmod(index_in_page, columns)
        card = self._surface(self.gallery_inner)
        card.grid(row=row, column=col, sticky='nsew', padx=5, pady=5)
        self.gallery_inner.grid_columnconfigure(col, weight=1)
        thumb = tk.Frame(card, bg=FIELD)
        thumb.pack(fill='x', padx=8, pady=(8, 4))
        photo = None
        if path is not None:
            try:
                photo, _ = self._cached_thumbnail(path, (112, 105), icon_file=meta)
            except (OSError, ValueError):
                pass
        label = tk.Label(thumb, image=photo if photo else self.thumbnail_placeholder,
                         text='' if photo else 'Chưa có ảnh', compound='center',
                         bg=FIELD, fg=MUTED, font=SMALL,
                         width=135, height=110, cursor='hand2')
        label.pack(padx=4, pady=4)
        label.bind('<Button-1>', lambda e, i=idx, n=name, m=meta: self._gallery_toggle_selection(i, n, m))
        name_row = tk.Frame(card, bg=WHITE)
        name_row.pack(fill='x', padx=8)
        name_label = self.txt(name_row, name if len(name) < 22 else name[:19] + '…', 9, INK, True)
        name_label.pack(side='left', anchor='w', fill='x', expand=True)
        select_badge = self.txt(name_row, '☐ Chọn' if meta is not None else '', 9, INK)
        select_badge.pack(side='right')
        status, color = self._gallery_status_text(meta, reviewed, corrupt)
        status_label = self.txt(card, status, 9, color)
        status_label.pack(anchor='w', padx=8, pady=3)
        actions = tk.Frame(card, bg=WHITE)
        actions.pack(fill='x', padx=6, pady=(0, 8))
        goto_btn = self.button(actions, 'Đi tới', lambda i=idx, n=name, p=path: self._gallery_go(i, n, p),
                               small=True)
        goto_btn.pack(side='left', fill='x', expand=True)
        open_btn = self.button(actions, 'Mở', lambda p=path: self._open_external(p), small=True)
        delete_btn = self.button(actions, 'Xóa', lambda i=idx, n=name: self.delete_gallery_png(i, n), small=True)
        if path is not None:
            open_btn.pack(side='left', fill='x', expand=True, padx=(3, 0))
            delete_btn.pack(side='left', fill='x', expand=True, padx=(3, 0))
        # Attaching references to the card preserves the existing three-item
        # tuple contract used by the v3.4 in-place Gallery reconciler.
        card._gallery_goto_btn = goto_btn
        card._gallery_thumb_label = label
        card._gallery_meta = meta
        card._gallery_open_btn = open_btn
        card._gallery_delete_btn = delete_btn
        card._gallery_photo = photo
        card._gallery_name_row = name_row
        card._gallery_name_label = name_label
        card._gallery_thumb_holder = thumb
        card._gallery_actions = actions
        card._gallery_select_badge = select_badge
        card._gallery_file_key = path.name.casefold() if path else None
        for widget in (card, thumb, name_row, name_label, status_label, select_badge):
            widget.bind('<Button-1>', lambda e, i=idx, n=name, m=meta: self._gallery_toggle_selection(i, n, m))
        self._gallery_paint_selection(card)
        self._bind_gallery_wheel_children(card)
        return card, status_label, photo

    def _update_gallery_card_image(self, card, index, name, meta):
        """Update one card's PNG/controls without disturbing other card widgets."""
        previous = card._gallery_meta
        if previous == meta:
            return card._gallery_photo
        path = meta.path if meta is not None else None
        photo = None
        if path is not None:
            try:
                photo, _ = self._cached_thumbnail(path, (112, 105), icon_file=meta)
            except (OSError, ValueError):
                pass
        card._gallery_thumb_label.configure(
            image=photo if photo else self.thumbnail_placeholder,
            text='' if photo else 'Chưa có ảnh')
        card._gallery_thumb_label.bind('<Button-1>',
            lambda e, i=index, n=name, m=meta: self._gallery_toggle_selection(i, n, m))
        card._gallery_goto_btn.configure(
            command=lambda i=index, n=name, p=path: self._gallery_go(i, n, p))
        open_btn = card._gallery_open_btn
        delete_btn = card._gallery_delete_btn
        open_btn.configure(command=lambda p=path: self._open_external(p) if p is not None else None)
        if path is None:
            open_btn.pack_forget()
            delete_btn.pack_forget()
        else:
            if not open_btn.winfo_manager():
                open_btn.pack(side='left', fill='x', expand=True, padx=(3, 0))
            if not delete_btn.winfo_manager():
                delete_btn.pack(side='left', fill='x', expand=True, padx=(3, 0))
        card._gallery_meta = meta
        card._gallery_photo = photo
        card._gallery_file_key = path.name.casefold() if path else None
        for widget in (card, card._gallery_name_row, card._gallery_name_label,
                       card._gallery_select_badge):
            widget.bind('<Button-1>', lambda e, i=index, n=name, m=meta:
                        self._gallery_toggle_selection(i, n, m))
        self._gallery_paint_selection(card)
        return photo

    def _reconcile_gallery_cards(self, page, fingerprint, columns):
        """Update existing review badges and reflow filtered cards without a grid reload."""
        if (self._gallery_render_pending or
                not self._gallery_can_reconcile_cards(self._gallery_render_key, fingerprint)):
            return False
        cards = getattr(self, '_gallery_card_widgets', None)
        if cards is None:
            return False
        new_keys = {(idx, name) for idx, name, *_ in page}
        for key in cards.keys() - new_keys:
            card, _, _ = cards.pop(key)
            card.destroy()
        if getattr(self, '_gallery_empty_widget', None) is not None:
            self._gallery_empty_widget.destroy()
            self._gallery_empty_widget = None
        for position, entry in enumerate(page):
            idx, name, meta, reviewed, corrupt = entry
            key = (idx, name)
            if key not in cards:
                cards[key] = self._make_gallery_card(position, entry, columns)
            else:
                card, status_label, old_photo = cards[key]
                row, col = divmod(position, columns)
                card.grid_configure(row=row, column=col)
                # Older synthetic test cards have no image widgets; ordinary
                # review toggles still update their badge without repainting.
                if hasattr(card, '_gallery_meta') and card._gallery_meta != meta:
                    photo = self._update_gallery_card_image(card, idx, name, meta)
                    cards[key] = (card, status_label, photo)
                status, color = self._gallery_status_text(meta, reviewed, corrupt)
                if status_label.cget('text') != status:
                    status_label.configure(text=status, fg=color)
                if hasattr(card, '_gallery_select_badge'):
                    self._gallery_paint_selection(card)
        if not page:
            self._gallery_empty_widget = self.txt(self.gallery_inner,
                'Không tìm thấy Image Gen nào phù hợp.', 11, MUTED)
            self._gallery_empty_widget.pack(padx=18, pady=25)
            self._bind_gallery_wheel_children(self.gallery_inner)
        self.gallery_thumb_refs = [photo for _, _, photo in cards.values() if photo is not None]
        self._gallery_render_key = fingerprint
        return True

    def refresh_gallery(self):
        if not hasattr(self, 'gallery_inner') or self.current_page != 'gallery':
            return
        visible, complete, total = self._gallery_display_items()
        self._gallery_prune_selection()
        self.gallery_stats.configure(text=f'{complete}/{total} đã có')
        page_size = 24
        max_page = max(1, (len(visible) + page_size - 1) // page_size)
        self._gallery_page_index = max(0, min(self._gallery_page_index, max_page - 1))
        self.gallery_paging.configure(text=f'{self._gallery_page_index + 1} / {max_page}')
        start = self._gallery_page_index * page_size
        page = visible[start:start+page_size]
        columns = max(1, self._gallery_columns)

        fingerprint = (
            self.project_store.active_id,
            self.destination.get().strip(), columns, self._gallery_page_index,
            self.gallery_search_var.get(), self.gallery_filter_var.get(),
            tuple((i, name, state, reviewed, bad,
                   (meta.path, meta.size, meta.modified_ns, meta.inode,
                    meta.change_ns, meta.content_digest) if meta else None)
                  for i, name, meta, reviewed, bad in page
                  for state in (self.items[i].state if i is not None and 0 <= i < len(self.items)
                                else 'existing' if meta else 'pending',)),
        )
        if fingerprint == self._gallery_render_key:
            return
        # No Gallery recreation when the only change is an image's review flag.
        if self._reconcile_gallery_cards(page, fingerprint, columns):
            return
        self._gallery_render_key = fingerprint
        self._gallery_render_ticket += 1
        self._gallery_render_pending = bool(page)
        ticket = self._gallery_render_ticket
        for child in self.gallery_inner.winfo_children():
            child.destroy()
        self._gallery_card_widgets = {}
        self._gallery_empty_widget = None
        self.gallery_thumb_refs = []
        if not page:
            self._gallery_render_pending = False
            self._gallery_empty_widget = self.txt(self.gallery_inner,
                'Không tìm thấy Image Gen nào phù hợp.', 11, MUTED)
            self._gallery_empty_widget.pack(padx=18, pady=25)
            self._bind_gallery_wheel_children(self.gallery_inner)
            return

        batch_size = 6
        def render_batch(begin):
            if ticket != self._gallery_render_ticket:
                return
            for index_in_page in range(begin, min(begin + batch_size, len(page))):
                idx, name, meta, reviewed, corrupt = page[index_in_page]
                # Review may have changed while a queued batch was waiting.
                if idx is not None and 0 <= idx < len(self.items):
                    reviewed = self.items[idx].state == 'review'
                entry = (idx, name, meta, reviewed, corrupt)
                card_info = self._make_gallery_card(index_in_page, entry, columns)
                self._gallery_card_widgets[(idx, name)] = card_info
                if card_info[2] is not None:
                    self.gallery_thumb_refs.append(card_info[2])
            if begin + batch_size < len(page):
                self.root.after(1, render_batch, begin + batch_size)
            else:
                self._gallery_render_pending = False
        render_batch(0)

    def _gallery_scope(self):
        return (self.project_store.active_id, self.destination.get().strip())

    def _gallery_prune_selection(self):
        if self._gallery_selection_scope != self._gallery_scope():
            self._gallery_multi_selected.clear()
            self._gallery_selection_scope = self._gallery_scope()
        snapshot = self._folder_snapshot
        if snapshot.folder == self.destination.get().strip() and snapshot.available and not snapshot.error:
            self._gallery_multi_selected = {
                key: meta for key, meta in self._gallery_multi_selected.items()
                if key in snapshot.files and snapshot.files[key].valid and snapshot.files[key] == meta
            }
        self._gallery_update_batch_toolbar()

    def _gallery_update_batch_toolbar(self):
        count = len(self._gallery_multi_selected)
        if hasattr(self, 'gallery_batch_count'):
            self.gallery_batch_count.configure(text=f'Đã chọn: {count} ảnh'
                if not self._gallery_batch_running else 'Đang xử lý ảnh đã chọn…')
            for button in (self.gallery_batch_resize_btn, self.gallery_batch_convert_btn):
                button.configure(state='normal' if count and not self._gallery_batch_running else 'disabled')
            for button in (self.gallery_batch_all_btn, self.gallery_batch_clear_btn):
                button.configure(state='normal' if not self._gallery_batch_running else 'disabled')

    def _gallery_paint_selection(self, card):
        key = getattr(card, '_gallery_file_key', None)
        if not hasattr(card, '_gallery_select_badge'):
            return
        selected = key is not None and key in self._gallery_multi_selected
        background = '#E7E7E7' if selected else WHITE
        card.configure(bg=background, highlightbackground=BLACK if selected else BORDER,
                       highlightthickness=2 if selected else 1)
        for widget in (card._gallery_name_row, card._gallery_name_label,
                       card._gallery_actions, card._gallery_select_badge):
            widget.configure(bg=background)
        # The actual preview remains on a neutral image surface.
        card._gallery_select_badge.configure(text='☑ Đã chọn' if selected else ('☐ Chọn' if key else ''))
        for child in card.winfo_children():
            if child not in (card._gallery_name_row, card._gallery_thumb_holder, card._gallery_actions):
                if isinstance(child, tk.Label):
                    child.configure(bg=background)

    def _gallery_repaint_selections(self):
        for card, _, _ in getattr(self, '_gallery_card_widgets', {}).values():
            self._gallery_paint_selection(card)

    def _gallery_toggle_selection(self, index, name, meta):
        if self._gallery_batch_running:
            return
        self._gallery_select(index, name, meta.path if meta else None)
        if meta is None or not meta.valid:
            return
        self._gallery_prune_selection()
        key = meta.path.name.casefold()
        if key in self._gallery_multi_selected:
            del self._gallery_multi_selected[key]
        else:
            self._gallery_multi_selected[key] = meta
        self._gallery_update_batch_toolbar()
        self._gallery_repaint_selections()

    def _gallery_clear_selection(self):
        if self._gallery_batch_running:
            return
        self._gallery_multi_selected.clear()
        self._gallery_update_batch_toolbar()
        self._gallery_repaint_selections()

    def _gallery_select_all(self):
        """Select matching existing files across ALL Gallery pages, not only page 1."""
        if self._gallery_batch_running:
            return
        self._gallery_prune_selection()
        visible, _, _ = self._gallery_display_items()
        for _, _, meta, _, _ in visible:
            if meta is not None and meta.valid:
                self._gallery_multi_selected[meta.path.name.casefold()] = meta
        self._gallery_update_batch_toolbar()
        self._gallery_repaint_selections()

    def _gallery_batch_dialog(self, operation):
        """Small modal to gather real batch parameters; no global settings changes."""
        if self._gallery_batch_running or not self._gallery_multi_selected:
            return
        window = tk.Toplevel(self.root)
        window.title('Resize ảnh đã chọn' if operation == 'resize' else 'Đổi định dạng ảnh đã chọn')
        window.configure(bg=WHITE)
        window.resizable(False, False)
        window.transient(self.root)
        body = tk.Frame(window, bg=WHITE)
        body.pack(fill='both', expand=True, padx=18, pady=15)
        self.txt(body, f'{len(self._gallery_multi_selected)} ảnh đã chọn', 11, INK, True).pack(anchor='w', pady=(0, 9))
        state = {}
        if operation == 'resize':
            dims = tk.Frame(body, bg=WHITE)
            dims.pack(fill='x', pady=(2, 9))
            self.txt(dims, 'Rộng', 9, INK).pack(side='left')
            width = tk.StringVar(value=self.width_var.get())
            self._field(dims, width, width=7).pack(side='left', padx=(6, 12))
            self.txt(dims, 'Cao', 9, INK).pack(side='left')
            height = tk.StringVar(value=self.height_var.get())
            self._field(dims, height, width=7).pack(side='left', padx=(6, 0))
            self.txt(body, 'Kiểu resize', 9, INK).pack(anchor='w')
            mode = tk.StringVar(value=self.resize_mode.get())
            ttk.Combobox(body, values=list(self._resize_options()), textvariable=mode,
                         state='readonly', width=35, style='Veloura.TCombobox').pack(fill='x', pady=(3, 8))
            self.txt(body, 'Resize sẽ thay thế các file ảnh gốc đã chọn.', 9, MUTED).pack(anchor='w')
            state.update(width=width, height=height, mode=mode)
        else:
            self.txt(body, 'Định dạng mới', 9, INK).pack(anchor='w')
            format_var = tk.StringVar(value='webp' if self.output_format.get() == 'png' else 'png')
            ttk.Combobox(body, values=list(OUTPUT_FORMATS), textvariable=format_var,
                         state='readonly', width=18, style='Veloura.TCombobox').pack(anchor='w', pady=(4, 9))
            overwrite = tk.BooleanVar(value=False)
            remove = tk.BooleanVar(value=False)
            ttk.Checkbutton(body, text='Ghi đè ảnh đích đã có', variable=overwrite,
                            style='Veloura.TCheckbutton').pack(anchor='w')
            ttk.Checkbutton(body, text='Xóa ảnh gốc sau chuyển đổi thành công', variable=remove,
                            style='Veloura.TCheckbutton').pack(anchor='w', pady=(4, 0))
            self.txt(body, 'Mặc định giữ ảnh gốc, không ghi đè ảnh đích.', 9, MUTED).pack(anchor='w', pady=(7, 0))
            state.update(output_format=format_var, overwrite=overwrite, remove=remove)
        actions = tk.Frame(body, bg=WHITE)
        actions.pack(fill='x', pady=(14, 0))
        self.button(actions, 'Hủy', window.destroy, small=True).pack(side='right')
        def submit():
            from gallery_batch import BatchJob
            try:
                if operation == 'resize':
                    w = int(state['width'].get().strip())
                    h = int(state['height'].get().strip())
                    if not (1 <= w <= 16384 and 1 <= h <= 16384 and w * h <= 80_000_000):
                        raise ValueError('Rộng/cao từ 1 đến 16384 px, tối đa 80 triệu pixel.')
                    options = dict(width=w, height=h, mode=dict(zip(self._resize_options(), ('contain', 'cover', 'stretch')))[state['mode'].get()])
                else:
                    options = dict(output_format=state['output_format'].get(),
                                   overwrite=state['overwrite'].get(),
                                   remove_original=state['remove'].get())
                snapshot = self._folder_snapshot
                if not snapshot.available or snapshot.error or snapshot.folder != self.destination.get().strip():
                    raise ValueError('Thư mục đang không khả dụng. Hãy làm mới rồi thử lại.')
            except (ValueError, KeyError) as exc:
                messagebox.showwarning('Thiết lập không hợp lệ', str(exc), parent=window)
                return
            warning = ('Resize sẽ ghi đè ảnh gốc đã chọn.' if operation == 'resize' else
                       'Ảnh đích trùng tên sẽ bị ghi đè.' if options.get('overwrite') else
                       'Ảnh đích trùng tên sẽ được bỏ qua.')
            if options.get('remove_original'):
                warning += '\nẢnh gốc sẽ bị xóa sau khi chuyển đổi thành công.'
            if not messagebox.askyesno('Xác nhận xử lý hàng loạt',
                    f'{len(self._gallery_multi_selected)} ảnh\n\n{warning}\n\nTiếp tục?',
                    icon='warning', parent=window):
                return
            selection = tuple(self._gallery_multi_selected.values())
            job = BatchJob(folder=self.destination.get().strip(),
                           project_id=self.project_store.active_id,
                           files=selection, operation=operation, **options)
            window.destroy()
            self._gallery_start_batch(job)
        self.button(actions, 'Áp dụng', submit, primary=True, small=True).pack(side='right', padx=(0, 8))
        window.grab_set()
        window.wait_window()

    def _gallery_batch_resize(self):
        self._gallery_batch_dialog('resize')

    def _gallery_batch_convert(self):
        self._gallery_batch_dialog('convert')

    def _gallery_start_batch(self, job):
        """Worker writes files; Tk thread receives progress/finished messages only."""
        import threading
        from gallery_batch import run_batch
        if self._gallery_batch_running or job.project_id != self.project_store.active_id:
            return
        self._gallery_batch_running = True
        if getattr(self, '_live_monitor', None) is not None and hasattr(self._live_monitor, 'pause'):
            self._live_monitor.pause()  # Avoid O(files × events) rehashes during a batch.
        self._gallery_update_batch_toolbar()
        def worker():
            try:
                report = run_batch(job, lambda done, total:
                    self.messages.put(('gallery_batch_progress', job.project_id, done, total)))
                # One authoritative reconciliation, not one scan per file.
                from folder_live import scan_png_folder
                fresh = scan_png_folder(job.folder, check_contents=True)
                self.messages.put(('gallery_batch_done', job.project_id, job.folder, report, fresh))
            except Exception as exc:
                self.messages.put(('gallery_batch_error', job.project_id, str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def _gallery_batch_progress(self, project_id, done, total):
        if self.project_store.active_id == project_id and hasattr(self, 'gallery_batch_count'):
            self.gallery_batch_count.configure(text=f'Đang xử lý {done}/{total} ảnh…')

    def _gallery_batch_finished(self, project_id, folder, report, snapshot):
        self._gallery_batch_running = False
        if getattr(self, '_live_monitor', None) is not None and hasattr(self._live_monitor, 'resume'):
            self._live_monitor.resume()
        if self.project_store.active_id != project_id or self.destination.get().strip() != folder:
            self._gallery_update_batch_toolbar()
            return
        self._gallery_multi_selected.clear()
        self._gallery_update_batch_toolbar()
        if snapshot.available and not snapshot.error:
            self._on_live_folder_snapshot(self._live_generation, snapshot)
        self._gallery_repaint_selections()
        message = (f'Thành công: {report.succeeded} ảnh\n'
                   f'Bỏ qua: {report.skipped} ảnh\n'
                   f'Không xử lý được: {report.failed} ảnh')
        if report.problems:
            message += '\n\n' + '\n'.join(report.problems[:8])
        self._status(f'Đã xử lý {report.succeeded} ảnh; bỏ qua {report.skipped}; lỗi {report.failed}')
        messagebox.showinfo('Kết quả xử lý ảnh hàng loạt', message, parent=self.root)

    def _gallery_go(self, index, name, path):
        self._gallery_select(index,name,path)
        if index is not None:
            self.show_page('workspace')
            self.select_by_index(index)

    def _gallery_select(self,index,name,path):
        self._gallery_selected=(index,name,path)
        self.gallery_preview_name.configure(text=name)
        status = 'Chưa có ảnh'
        if index is not None and 0 <= index < len(self.items):
            item = self.items[index]
            status = 'Cần xem xét' if item.state == 'review' else ('Đã có ảnh' if item.state in ('existing','done') else ('Ảnh lỗi' if item.state == 'corrupt' else 'Chưa có ảnh'))
        self.gallery_preview_info.configure(text=(status + (' · ' + str(path) if path else ''))[:170])
        self._gallery_preview_ref=None
        if path:
            try:
                file_meta = self._folder_snapshot.for_icon(
                    name, self.output_format.get() if hasattr(self, 'output_format') else 'png')
                photo, _ = self._cached_thumbnail(path, (174, 168), icon_file=file_meta)
                self._gallery_preview_ref=photo
                self.gallery_preview_photo.configure(image=photo,text='')
            except Exception:
                self.gallery_preview_photo.configure(image=self.thumbnail_placeholder,text='Không xem được ảnh')
        else:
            self.gallery_preview_photo.configure(image=self.thumbnail_placeholder,text='Chưa có ảnh')
        self._update_review_controls()

    def _toggle_gallery_review(self):
        if self._gallery_selected and self._gallery_selected[0] is not None:
            self.selected_index = self._gallery_selected[0]
            self.toggle_review_for_selected()

    def _open_gallery_selected(self):
        if self._gallery_selected and self._gallery_selected[2]:
            self._open_external(self._gallery_selected[2])

    def _goto_gallery_selected(self):
        if self._gallery_selected and self._gallery_selected[0] is not None:
            self._gallery_go(*self._gallery_selected)

    def _on_gallery_card(self,index,path):
        self._gallery_select(index,path.stem if path else '',path)

    def _open_external(self, path: Path):
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(path))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            messagebox.showerror("Không mở được ảnh", str(exc))
