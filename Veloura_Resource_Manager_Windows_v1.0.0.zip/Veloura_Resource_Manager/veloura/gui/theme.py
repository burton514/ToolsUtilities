"""Single source of truth for the monochrome desktop presentation theme."""
BG = '#F6F6F6'
WHITE = '#FFFFFF'
BLACK = '#111111'
INK = '#161616'
MUTED = '#565656'
BORDER = '#D8D8D8'
FIELD = '#FCFCFC'
HOVER = '#ECECEC'
ACTIVE = '#E4E4E4'
SOFT = '#F3F3F3'
F = ('Segoe UI', 10)
SMALL = ('Segoe UI', 9)
MED = ('Segoe UI Semibold', 10)
H = ('Segoe UI Semibold', 13)
