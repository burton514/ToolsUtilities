"""ActivityController: isolated responsibilities of the desktop controller.

No imports from application entry points: app.py binds these methods explicitly.
"""
from PIL import Image, ImageTk
from pathlib import Path
import datetime, queue
from tkinter import filedialog, messagebox
from imageflow_core import save_csv_log
import tkinter as tk


class ActivityController:
    def _poll(self):
        try:
            for _ in range(20):
                try:
                    event = self.messages.get_nowait()
                except queue.Empty:
                    break
                kind = event[0]
                if kind == "gallery_batch_progress":
                    _, project_id, done, total = event
                    if hasattr(self, '_gallery_batch_progress'):
                        self._gallery_batch_progress(project_id, done, total)
                elif kind == "gallery_batch_done":
                    _, project_id, folder, report, snapshot = event
                    if hasattr(self, '_gallery_batch_finished'):
                        self._gallery_batch_finished(project_id, folder, report, snapshot)
                elif kind == "gallery_batch_error":
                    _, project_id, error = event
                    self._gallery_batch_running = False
                    if getattr(self, '_live_monitor', None) is not None and hasattr(self._live_monitor, 'resume'):
                        self._live_monitor.resume()
                    if hasattr(self, '_gallery_update_batch_toolbar'):
                        self._gallery_update_batch_toolbar()
                    messagebox.showwarning('Không xử lý được ảnh', error, parent=self.root)
                elif kind == "folder_snapshot":
                    _, generation, snapshot = event
                    self._on_live_folder_snapshot(generation, snapshot)
                elif kind == "names":
                    _, ticket, items, dup = event
                    if ticket == self.read_ticket:
                        self._apply_names(items, dup)
                elif kind == "names_error":
                    _, ticket, msg = event
                    if ticket == self.read_ticket:
                        self.processing = False
                        self.paint_dropzone()
                        messagebox.showerror("Không đọc được cột", msg)
                elif kind == "export_ok":
                    _, selected, result, cleanup_path = event
                    self.processing = False
                    if 0 <= selected < len(self.items):
                        self.items[selected].state = "done"
                    now = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                    row = {"Thời gian": now, "Tên ảnh": result.destination.stem,
                           "Ảnh nguồn": str(result.source), "Ảnh đích": str(result.destination),
                           "Thao tác": "Move" if result.moved else "Copy",
                           "Kích thước": f"{result.width} × {result.height}", "Kết quả": "Thành công"}
                    self.logs.append(row)
                    # Keep only recent activity in RAM; disk PNGs are the source of truth.
                    if len(self.logs) > 300:
                        del self.logs[:-300]
                    self._append_activity(f"✓  {result.destination.name}   ·   {result.width}×{result.height}   ·   {'Move' if result.moved else 'Copy'}")
                    self._status("Đã lưu thành công: " + result.destination.name)
                    self._show_preview(result.destination, result.width, result.height)
                    self.draw_items()
                    self.refresh_gallery()
                    if self.advance.get():
                        self.selected_index = selected
                        if any(x.state == "pending" for x in self.items):
                            self.select_next()
                        else:
                            self.selected_index = None
                            self.tree.selection_remove(self.tree.selection())
                            self.target_lbl.configure(text="Đã hoàn thành danh sách")
                            self.target_details.configure(text="Tất cả tên hợp lệ đã có ảnh. Bạn có thể chọn lại một tên để thay thế.")
                            self._refresh_prompt()
                            if hasattr(self, '_refresh_selected_output_preview'):
                                self._refresh_selected_output_preview()
                    else:
                        self.select_by_index(selected)
                    self.paint_dropzone()
                    if cleanup_path:
                        try:
                            Path(cleanup_path).unlink(missing_ok=True)
                        except Exception:
                            pass
                elif kind == "export_error":
                    _, selected, source, reason, cleanup_path = event
                    self.processing = False
                    self._status("Xử lý ảnh thất bại")
                    self._append_activity("✕  " + source.name + " · " + reason)
                    messagebox.showerror("Không thể lưu ảnh", f"Ảnh: {source.name}\n\n{reason}")
                    self.paint_dropzone()
                    if cleanup_path:
                        try:
                            Path(cleanup_path).unlink(missing_ok=True)
                        except Exception:
                            pass
        finally:
            try:
                self.root.after(130, self._poll)
            except tk.TclError:
                pass

    def _append_activity(self, line):
        stamp = datetime.datetime.now().strftime("%H:%M:%S")
        self.activity.configure(state="normal")
        if self.activity.get("1.0", "end").strip() == "Chưa có ảnh nào được xử lý trong phiên này.":
            self.activity.delete("1.0", "end")
        self.activity.insert("end", stamp + "    " + line + "\n")
        # The Workspace activity widget is a single-line status view, not a log archive.
        # Bound its backing Text buffer so repeated exports cannot slow down Tk.
        last_line = int(self.activity.index("end-1c").split(".")[0])
        if last_line > 35:
            self.activity.delete("1.0", f"{last_line - 30}.0")
        self.activity.see("end")
        self.activity.configure(state="disabled")

    def _show_preview(self, path: Path, width, height):
        try:
            with Image.open(path) as picture:
                preview = picture.convert("RGBA")
                preview.thumbnail((45, 35), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(preview)
            self.preview_ref = photo
            self.preview_img.configure(image=photo, text="", width=45, height=35)
        except Exception:
            self.preview_img.configure(image=self.preview_empty, text="")
        self.preview_title.configure(text="Đã lưu: " + path.name[:25])
        self.preview_sub.configure(text=f"{width} × {height} px")

    def refresh_history(self):
        """Refresh the current project's in-memory history without touching PNGs."""
        if hasattr(self, "_refresh_history_page"):
            self._refresh_history_page()
        self._status("Đã làm mới lịch sử của project hiện tại")

    def clear_history(self):
        """Clear only this project's session history and the Workspace activity text."""
        count = len(self.logs)
        if not count:
            # Clearing also resets non-record messages left in the activity widget.
            self._clear_activity_text()
            if hasattr(self, "_refresh_history_page"):
                self._refresh_history_page()
            self._status("Không có nhật ký hoạt động để xóa")
            return False
        if not messagebox.askyesno(
            "Xác nhận xóa nhật ký",
            f"Xóa {count} hoạt động trong phiên của project hiện tại?\n\n"
            "Thao tác này không xóa ảnh PNG, file Excel/CSV hoặc cấu hình project.",
            parent=self.root,
        ):
            return False
        # Preserve the list object shared between self.logs and project_logs.
        self.logs.clear()
        self.project_logs[self.project_store.active_id] = self.logs
        self._clear_activity_text()
        if hasattr(self, "_refresh_history_page"):
            self._refresh_history_page()
        self._status("Đã xóa nhật ký trong phiên của project hiện tại")
        return True

    def _clear_activity_text(self):
        if not hasattr(self, "activity"):
            return
        self.activity.configure(state="normal")
        self.activity.delete("1.0", "end")
        self.activity.insert("end", "Chưa có ảnh nào được xử lý trong phiên này.\n")
        self.activity.configure(state="disabled")

    def export_logs(self):
        if not self.logs:
            messagebox.showinfo("Chưa có nhật ký", "Chưa có thao tác thành công nào để xuất CSV.")
            return
        path = filedialog.asksaveasfilename(title="Xuất nhật ký xử lý ảnh", defaultextension=".csv",
                                            initialfile="Veloura_Image_Log.csv", filetypes=[("CSV", "*.csv")])
        if path:
            try:
                save_csv_log(Path(path), self.logs)
                messagebox.showinfo("Đã xuất nhật ký", "Đã lưu CSV ở:\n" + path)
            except Exception as exc:
                messagebox.showerror("Không xuất được", str(exc))

    def _status(self, text):
        self.status_lbl.configure(text=text[:95])

    def on_close(self):
        if getattr(self, '_gallery_batch_running', False):
            messagebox.showinfo('Đang xử lý ảnh',
                                'Hãy hoàn tất xử lý hàng loạt trước khi đóng ứng dụng.', parent=self.root)
            return
        if self.processing:
            if not messagebox.askyesno("Đang xử lý", "Một thao tác đang diễn ra. Đóng ứng dụng lúc này có thể làm gián đoạn ảnh. Bạn vẫn muốn đóng?"):
                return
        self.settings["window_geometry"] = (self._full_window_geometry if getattr(self, "_compact_active", False)
                                            else self.root.geometry())
        if self._folder_rebind_task is not None:
            self.root.after_cancel(self._folder_rebind_task)
            self._folder_rebind_task = None
        if self.save_task:
            self.root.after_cancel(self.save_task)
            self.save_task = None
        self._closing = True
        if not self.persist_settings():
            if not messagebox.askyesno("Cài đặt chưa được lưu",
                    "Không thể lưu cài đặt hiện tại. Bạn vẫn muốn thoát ứng dụng?",
                    parent=self.root):
                self._closing = False
                return
        if self._live_monitor is not None:
            self._live_monitor.stop()
        if self.workbook:
            try:
                self.workbook.close()
            except Exception:
                pass
        if self._sync_project_task is not None:
            try:
                self.root.after_cancel(self._sync_project_task)
            except tk.TclError:
                pass
        self.root.destroy()

