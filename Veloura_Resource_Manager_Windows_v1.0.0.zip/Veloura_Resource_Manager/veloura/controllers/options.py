"""Shared labels and codes for export settings."""
RESIZE_OPTIONS = {
    "Giữ tỷ lệ · thêm nền trong suốt": "contain",
    "Phủ đầy khung · cắt giữa": "cover",
    "Kéo giãn · đúng kích thước": "stretch",
}
CONFLICT_OPTIONS = {
    "Hỏi trước khi ghi đè": "ask",
    "Tự động ghi đè": "overwrite",
    "Bỏ qua nếu đã có": "skip",
}


def label_for(mapping, value):
    """Return the user-facing label for a stored option code."""
    return next((label for label, code in mapping.items() if code == value), next(iter(mapping)))
