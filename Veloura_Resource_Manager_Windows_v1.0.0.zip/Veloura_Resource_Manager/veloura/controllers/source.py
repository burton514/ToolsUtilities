"""SourceController: isolated responsibilities of the desktop controller.

No imports from application entry points: app.py binds these methods explicitly.
"""
from imageflow_core import NameItem, OUTPUT_FORMATS, get_column_options, load_name_source, normalize_source_path, normalized_name, read_names_with_prompts, validate_name
from pathlib import Path
from file_picker import ask_source_file
from tkinter import messagebox, simpledialog
import threading
import tkinter as tk


class SourceController:
    def open_source(self):
        """Open our own file browser; avoid Windows' native invalid-/C:/ parser."""
        if self.processing:
            return
        last = normalize_source_path(self.settings.get("last_source", ""))
        initial_dir = Path(last).parent if last else Path.home()
        file = ask_source_file(self.root, initial_dir)
        if file:
            self.import_source(file)

    def paste_source_path(self):
        """Allow importing paths which Windows' native file chooser cannot parse."""
        if self.processing:
            return
        try:
            raw = self.root.clipboard_get()
        except tk.TclError:
            messagebox.showinfo("Chưa sao chép đường dẫn", "Hãy sao chép đường dẫn Excel / CSV rồi bấm nút này.")
            return
        path = normalize_source_path(raw)
        if not path or not Path(path).is_file():
            messagebox.showerror(
                "Không tìm thấy file",
                "Đường dẫn đã sao chép không trỏ tới file có thật.\n\n"
                "Ví dụ đúng: C:/Users/Admin/Desktop/danh-sach-image-gen.csv\n\n"
                "Hãy kiểm tra và sao chép lại đường dẫn."
            )
            return
        self.import_source(path)

    def open_recent(self):
        file = normalize_source_path(self.settings.get("last_source", ""))
        if file and Path(file).is_file():
            self.import_source(file)
        else:
            messagebox.showinfo("Không tìm thấy", "Không tìm thấy file Excel / CSV đã dùng trước đó.")

    @staticmethod
    def _source_fingerprint(path):
        try:
            stat = Path(path).stat()
            return stat.st_size, stat.st_mtime_ns, getattr(stat, 'st_ino', 0)
        except OSError:
            return None

    def _reload_source_if_changed(self):
        """Reopen a source only after its on-disk metadata stabilizes.

        A two-check debounce avoids loading half-written Excel files. No copy
        of the spreadsheet is stored: the original stays authoritative.
        """
        if not self.source_path or not self.workbook:
            return
        stamp = self._source_fingerprint(self.source_path)
        if stamp is None or stamp == self._source_disk_signature:
            self._source_change_pending = None
            return
        if self._source_change_pending != stamp:
            self._source_change_pending = stamp
            return
        # Validate silently: don't interrupt the user's work with dialogs if
        # another program is temporarily holding an incomplete workbook.
        try:
            check = load_name_source(str(self.source_path))
            check.close()
        except Exception:
            # Excel/CSV may still be in the middle of a save; try next tick.
            return
        previous_name = (self.items[self.selected_index].name
                         if self.selected_index is not None and 0 <= self.selected_index < len(self.items)
                         else None)
        self.import_source(str(self.source_path), preserve_selection=previous_name)

    def import_source(self, path: str, preserve_selection: str | None = None):
        if self.processing:
            return
        path = normalize_source_path(path)
        try:
            workbook = load_name_source(path)
        except Exception as exc:
            messagebox.showerror("Không mở được file", "Hãy chọn file .xlsx, .xlsm hoặc .csv hợp lệ.\n\n" + str(exc))
            return
        if self.workbook:
            try:
                self.workbook.close()
            except Exception:
                pass
        self.workbook = workbook
        self.source_path = Path(path)
        self._source_restore_name = preserve_selection
        self._source_disk_signature = self._source_fingerprint(self.source_path)
        self._source_change_pending = None
        self.items = []
        self.selected_index = None
        self._refresh_target()
        self.refresh_gallery()
        self.recent_file_lbl.configure(text=self.source_path.name[:32])
        self.sheet_combo.configure(values=self.workbook.sheetnames,
                                   state="disabled" if getattr(self.workbook, "is_csv", False) else "readonly")
        saved_sheet = self.settings.get("last_sheet")
        self.sheet_var.set(saved_sheet if saved_sheet in self.workbook.sheetnames else self.workbook.sheetnames[0])
        self.recent_btn.pack_forget()
        self._source_has_collapsed = False
        self.toggle_source_details(True)
        self.on_sheet_changed()
        self._status("Đã mở " + self.source_path.name)
        self.persist_settings()

    def on_header_changed(self):
        if self.workbook:
            self.on_sheet_changed()

    def on_sheet_changed(self):
        if not self.workbook:
            return
        try:
            sheet = self.workbook[self.sheet_var.get()]
            self.columns = get_column_options(sheet, self.has_header.get())
            labels = [label for _, label in self.columns]
            self.column_combo.configure(values=labels)
            self.prompt_column_combo.configure(values=["Không chọn"] + labels)
            same_workbook = self.settings.get("last_source", "") == str(self.source_path)
            if same_workbook and int(self.settings.get("last_column", 0) or 0) > 0:
                desired = int(self.settings.get("last_column", 1))
                desired_prompt = int(self.settings.get("last_prompt_column", 0))
            else:
                # Match the application's current label before broad aliases like
                # "image"/"name" (which can refer to unrelated metadata columns).
                specific_names = ("tên image gen", "ten image gen", "image gen name")
                name_words = ("tên ảnh", "ten anh", "tên icon", "tên file", "file name",
                              "filename", "image name", "icon name", "image", "name")
                specific_match = [idx for idx, label in self.columns
                                  if any(word in label.casefold() for word in specific_names)]
                name_match = [idx for idx, label in self.columns
                              if any(word in label.casefold() for word in name_words)]
                desired = (specific_match or name_match or [1])[0]
                prompt_words = ("prompt", "promt", "câu lệnh", "cau lenh", "mô tả tạo ảnh",
                                "mo ta tao anh", "image description")
                prompt_match = [idx for idx, label in self.columns
                                if any(word in label.lower() for word in prompt_words)]
                desired_prompt = prompt_match[0] if prompt_match else 0
            desired = min(max(desired, 1), len(labels)) if labels else 1
            desired_prompt = desired_prompt if 1 <= desired_prompt <= len(labels) else 0
            self.column_var.set(labels[desired - 1] if labels else "")
            self.prompt_column_var.set(labels[desired_prompt - 1] if desired_prompt else "Không chọn")
            self.load_selected_column()
        except Exception as exc:
            messagebox.showerror("Không đọc được sheet", str(exc))

    def selected_col_index(self):
        val = self.column_var.get()
        return next((index for index, label in self.columns if label == val), 1)

    def selected_prompt_col_index(self):
        val = self.prompt_column_var.get()
        return next((index for index, label in self.columns if label == val), 0)

    def load_selected_column(self):
        if not self.workbook or self.processing:
            return
        self.processing = True
        self._status("Đang đọc tên ảnh và prompt...")
        self.items = []
        self.selected_index = None
        self.draw_items()
        self._refresh_target()
        sheet = self.workbook[self.sheet_var.get()]
        idx, prompt_idx, is_header = self.selected_col_index(), self.selected_prompt_col_index(), self.has_header.get()
        ticket = self.read_ticket = self.read_ticket + 1

        def worker():
            try:
                items, duplicates = read_names_with_prompts(sheet, idx, prompt_idx, is_header)
                self.messages.put(("names", ticket, items, duplicates))
            except Exception as err:
                self.messages.put(("names_error", ticket, str(err)))

        threading.Thread(target=worker, daemon=True).start()
        self.persist_settings()

    def _apply_names(self, items, duplicates):
        self.items = items
        self.duplicates = duplicates
        self.processing = False
        # Column mapping is an essential control; never auto-hide it after import.
        self._source_has_collapsed = False
        self.toggle_source_details(True)
        self.paint_dropzone()
        self.refresh_existing_states()
        self.draw_items()
        self.select_next()
        if self._source_restore_name:
            restore_name = self._source_restore_name.casefold()
            for index, item in enumerate(self.items):
                if item.name.casefold() == restore_name:
                    self.select_by_index(index)
                    break
        self._source_restore_name = None
        self._status(f"Đã nạp {len(items)} tên" + (f" · Bỏ {duplicates} tên trùng" if duplicates else ""))
        self.refresh_gallery()
        if not items:
            messagebox.showinfo("Cột chưa có tên", "Cột được chọn chưa chứa tên ảnh nào. Hãy kiểm tra sheet và cột.")

    def _update_counter(self):
        complete = sum(1 for item in self.items if item.state in ("existing", "done", "review"))
        valid = sum(1 for item in self.items if item.state != "invalid")
        self.counter.configure(text=f"{complete} / {valid} đã có ảnh")
        if hasattr(self, "summary_chip"):
            self.summary_chip.configure(text=f"{valid} tên ảnh")

    def draw_items(self):
        self.render_ticket += 1
        ticket = self.render_ticket
        for row in self.tree.get_children():
            self.tree.delete(row)
        query = self.search_var.get().strip().casefold()
        mode = self.filter_var.get()
        visible = [(i, item) for i, item in enumerate(self.items)
                   if (not query or query in item.name.casefold())
                   and (mode == "Tất cả"
                        or (mode == "Chưa xong" and item.state in ("pending", "invalid", "corrupt"))
                        or (mode == "Đã có ảnh" and item.state in ("existing", "done", "review"))
                        or (mode == "Cần xem xét" and item.state == "review"))]

        def insert_batch(start):
            if ticket != self.render_ticket:
                return
            for index, item in visible[start:start + 220]:
                display_name = item.name if len(item.name) <= 35 else item.name[:32] + "…"
                label = {"pending": "Chưa có", "existing": "Đã có", "review": "Cần xem xét", "done": "Đã lưu", "invalid": "Tên lỗi", "corrupt": "Ảnh lỗi"}.get(item.state, "")
                self.tree.insert("", "end", iid=str(index), values=(display_name, label), tags=(item.state,))
            if start + 220 < len(visible):
                self.root.after(1, insert_batch, start + 220)
            elif self.selected_index is not None and str(self.selected_index) in self.tree.get_children():
                self.tree.selection_set(str(self.selected_index))
        insert_batch(0)
        self._update_counter()

    def on_tree_select(self, event=None):
        selection = self.tree.selection()
        if not selection:
            return
        idx = int(selection[0])
        if 0 <= idx < len(self.items):
            self.selected_index = idx
            self._refresh_target()

    def _refresh_target(self):
        if self.selected_index is None or self.selected_index >= len(self.items):
            self._update_empty_selection()
            return
        item = self.items[self.selected_index]
        self.target_lbl.configure(text=item.name + OUTPUT_FORMATS.get(
            self.output_format.get() if hasattr(self, 'output_format') else 'png', OUTPUT_FORMATS['png'])[0])
        state_text = {"pending": "Chưa có ảnh", "existing": "Ảnh đích đã tồn tại", "review": "Đã đánh dấu cần xem xét", "done": "Đã lưu thành công", "invalid": item.detail, "corrupt": "Ảnh không đọc được"}
        self.target_details.configure(text=f"Dòng {item.excel_row} · {state_text.get(item.state, '')}")
        self._refresh_prompt()
        if hasattr(self, "_update_review_controls"):
            self._update_review_controls()

    def _update_empty_selection(self):
        if self.selected_index is None:
            self.target_lbl.configure(text="Chưa chọn tên ảnh")
            self.target_details.configure(text="Nhập Excel / CSV và chọn một tên ảnh ở danh sách bên trái")
            self._refresh_prompt()
            if hasattr(self, "_update_review_controls"):
                self._update_review_controls()

    def select_next(self):
        if not self.items:
            self.selected_index = None
            self._update_empty_selection()
            return
        candidates = [i for i, v in enumerate(self.items) if v.state == "pending"]
        if candidates:
            if self.selected_index is None:
                chosen = candidates[0]
            else:
                chosen = next((i for i in candidates if i > self.selected_index), candidates[0])
        else:
            candidates = [i for i, v in enumerate(self.items) if v.state != "invalid"]
            chosen = candidates[0] if candidates else 0
        self.select_by_index(chosen)

    def select_by_index(self, index):
        if not 0 <= index < len(self.items):
            return
        self.selected_index = index
        self._refresh_target()
        if str(index) not in self.tree.get_children():
            if self.filter_var.get() != "Tất cả" or self.search_var.get():
                self.filter_var.set("Tất cả")
                self.search_var.set("")
            self.root.after(60, lambda: self._focus_tree(index))
        else:
            self._focus_tree(index)

    def _focus_tree(self, index):
        if str(index) in self.tree.get_children():
            self.tree.selection_set(str(index))
            self.tree.see(str(index))

    def add_name(self):
        val = simpledialog.askstring("Thêm tên ảnh", "Nhập tên ảnh đích (không cần .png):", parent=self.root)
        if val is None:
            return
        self._insert_custom_name(val)

    def _insert_custom_name(self, val):
        name = normalized_name(val)
        error = validate_name(name)
        if error:
            messagebox.showwarning("Tên không hợp lệ", error)
            return
        if any(x.name.casefold() == name.casefold() for x in self.items):
            messagebox.showwarning("Tên đã tồn tại", "Tên ảnh này đã có trong danh sách.")
            return
        item = NameItem(name=name, excel_row=0)
        if self._folder_snapshot.for_icon(name, self.output_format.get() if hasattr(self, 'output_format') else 'png'):
            item.state = "existing"
        self.items.append(item)
        self.draw_items()
        self.select_by_index(len(self.items) - 1)
        self.refresh_gallery()

    def rename_item(self):
        if self.selected_index is None:
            messagebox.showinfo("Chọn tên", "Hãy chọn một tên trong danh sách trước.")
            return
        item = self.items[self.selected_index]
        val = simpledialog.askstring("Đổi tên ảnh đích", "Tên ảnh mới (không cần .png):",
                                     initialvalue=item.name, parent=self.root)
        if val is None:
            return
        name = normalized_name(val)
        error = validate_name(name)
        if error:
            messagebox.showwarning("Tên không hợp lệ", error)
            return
        if any(i != self.selected_index and x.name.casefold() == name.casefold()
               for i, x in enumerate(self.items)):
            messagebox.showwarning("Tên đã tồn tại", "Tên ảnh này đã có trong danh sách.")
            return
        item.name = name
        item.state = "existing" if self._folder_snapshot.for_icon(
            name, self.output_format.get() if hasattr(self, 'output_format') else 'png') else "pending"
        item.detail = ""
        self.draw_items()
        self._refresh_target()
        self.refresh_gallery()

