"""FolderController: isolated responsibilities of the desktop controller.

No imports from application entry points: app.py binds these methods explicitly.
"""
from folder_live import FolderSnapshot, scan_png_folder
from pathlib import Path
from tkinter import messagebox
import tkinter as tk
from imageflow_core import validate_name


class FolderController:
    def _reviewed_name_set(self):
        return {str(name).strip().casefold() for name in self.review_marks if str(name).strip()}

    def _is_reviewed_name(self, name):
        marks = getattr(self, "review_marks", [])
        return str(name).strip().casefold() in {str(item).strip().casefold() for item in marks if str(item).strip()}

    def _can_mark_review(self, item):
        return item is not None and item.state in ("existing", "done", "review")

    def _store_review_marks(self, persist=True):
        cleaned = sorted({str(name).strip() for name in self.review_marks if str(name).strip()}, key=str.casefold)
        self.review_marks = set(cleaned)
        self.project_store.active['review_marks'] = cleaned
        self.settings['review_marks'] = cleaned
        self._review_marks_dirty = True
        if persist and not self._changing_project:
            self.persist_settings()

    def _set_review_mark(self, name, enabled, persist=True):
        key = str(name).strip()
        if not key:
            return False
        before = self._is_reviewed_name(key)
        if enabled:
            self.review_marks = {n for n in self.review_marks if str(n).strip().casefold() != key.casefold()}
            self.review_marks.add(key)
        else:
            self.review_marks = {n for n in self.review_marks if str(n).strip().casefold() != key.casefold()}
        changed = before != enabled
        if changed:
            self._store_review_marks(persist=persist)
        return changed

    def _prune_review_marks(self, snapshot=None):
        if snapshot is None:
            snapshot = self._folder_snapshot
        if not self.items:
            return False  # No CSV loaded yet: do not clear saved review flags.
        if not snapshot.available or snapshot.error:
            return False  # Offline output folder is not proof of PNG deletion.
        preferred = self.output_format.get() if hasattr(self, 'output_format') else 'png'
        valid_names = {item.name.casefold() for item in self.items
                       if snapshot.for_icon(item.name, preferred) is not None}
        current = {str(name).strip().casefold() for name in self.review_marks if str(name).strip()}
        stale = current - valid_names
        if not stale:
            return False
        self.review_marks = {name for name in self.review_marks if str(name).strip().casefold() not in stale}
        self._store_review_marks(persist=True)
        return True

    def _refresh_review_rows(self, changed_indices):
        """Repaint only changed Treeview rows; filters may require reflow."""
        if self.filter_var.get() == "Cần xem xét":
            self.draw_items()
            return
        labels = {"pending": "Chưa có", "existing": "Đã có",
                  "review": "Cần xem xét", "done": "Đã lưu",
                  "invalid": "Tên lỗi", "corrupt": "Ảnh lỗi"}
        for index in changed_indices:
            iid = str(index)
            if self.tree.exists(iid):
                item = self.items[index]
                self.tree.set(iid, "status", labels[item.state])
                self.tree.item(iid, tags=(item.state,))
        self._update_counter()

    def toggle_review_for_selected(self):
        if self.selected_index is None or not (0 <= self.selected_index < len(self.items)):
            messagebox.showinfo("Chưa chọn Image Gen", "Hãy chọn một mục Image Gen trước khi đánh dấu cần xem xét.")
            return
        item = self.items[self.selected_index]
        if not self._can_mark_review(item):
            messagebox.showinfo("Chưa có ảnh", "Chỉ ảnh hợp lệ mới được đánh dấu cần xem xét.")
            return
        enabled = not self._is_reviewed_name(item.name)
        changed = self._set_review_mark(item.name, enabled, persist=True)
        if changed:
            # A review flag changes only this item's status, never its PNG.
            # Do not destroy/reinsert the whole workspace Treeview (hundreds
            # of rows) when Gallery toggles one badge.
            changed_rows = self._apply_png_states(self._folder_snapshot,
                                                  {item.name.casefold()})
            self._refresh_review_rows(changed_rows)
            self._refresh_target()
            if self.current_page == "gallery":
                # MonoUI reconciles card status in place, preserving all other
                # thumbnail widgets, scroll position, and pending image cache.
                self.refresh_gallery()
            if (hasattr(self, "_gallery_selected") and self._gallery_selected and
                    self._gallery_selected[1] == item.name and hasattr(self, "_gallery_select")):
                self._gallery_select(self._gallery_selected[0], item.name,
                                     self._matching_png_path(item.name))
            if self.current_page == "progress" and hasattr(self, "progress_body"):
                self._refresh_progress_page()
        self._status(("Đã đánh dấu cần xem xét: " if enabled else "Đã bỏ đánh dấu cần xem xét: ") + item.name)

    def _schedule_folder_rebind(self, *_):
        if self._changing_project or self._live_monitor is None:
            return
        if self._folder_rebind_task is not None:
            self.root.after_cancel(self._folder_rebind_task)
        self._folder_rebind_task = self.root.after(380, self._rebind_folder_monitor)

    def _rebind_folder_monitor(self, force=False):
        if self._folder_rebind_task is not None:
            try:
                self.root.after_cancel(self._folder_rebind_task)
            except tk.TclError:
                pass
            self._folder_rebind_task = None
        if self._live_monitor is None:
            return
        folder = self.destination.get().strip()
        if folder == self._live_folder_path and not force:
            return
        self._live_folder_path = folder
        if self._folder_snapshot.folder != folder or force:
            self._folder_snapshot = FolderSnapshot(folder=folder)
        self._live_generation = self._live_monitor.watch(folder)
        # Do not show the previous project's preview while the new folder scans.
        if hasattr(self, '_refresh_selected_output_preview'):
            self._refresh_selected_output_preview()

    def _matching_png_path(self, icon_name):
        """Return real on-disk path, including its actual spelling and .PNG case."""
        if self._folder_snapshot.folder != self.destination.get().strip():
            return None
        preferred = self.output_format.get() if hasattr(self, 'output_format') else 'png'
        file = self._folder_snapshot.for_icon(icon_name, preferred)
        return file.path if file else None

    def _apply_png_states(self, snapshot, changed_names=None):
        """Update only affected names when a filesystem event changes a few PNGs.

        None means a full reconciliation (new sheet, project, or review flags).
        """
        changed = []
        reviewed_keys = {str(name).strip().casefold() for name in getattr(self, "review_marks", []) if str(name).strip()}
        affected = set(changed_names) if changed_names is not None else None
        for index, item in enumerate(self.items):
            if item.state == "invalid":
                continue
            key = item.name.casefold()
            if affected is not None and key not in affected:
                continue
            preferred = self.output_format.get() if hasattr(self, 'output_format') else 'png'
            valid_file = snapshot.for_icon(item.name, preferred)
            corrupt_file = snapshot.invalid_for_icon(item.name, preferred)
            reviewed = key in reviewed_keys
            new_state = ("review" if valid_file is not None and reviewed else
                         "existing" if valid_file is not None else
                         "corrupt" if corrupt_file is not None else "pending")
            if item.state != new_state:
                item.state = new_state
                changed.append(index)
        return changed

    def delete_gallery_png(self, index, name, *, confirm=True, accept_updated=False):
        """Delete the selected output image, never the spreadsheet entry.

        Gallery keeps its confirmed/strict behavior. Quick Workspace can skip
        confirmation and accept a freshly replaced *valid* image at the exact
        same filename, instead of incorrectly rejecting the user's new export
        because the live folder snapshot is a few milliseconds behind.
        """
        if getattr(self, '_gallery_batch_running', False):
            messagebox.showinfo('Đang xử lý ảnh', 'Hãy hoàn tất xử lý hàng loạt trước khi xóa ảnh.', parent=self.root)
            return False
        folder = self.destination.get().strip()
        project_id = self.project_store.active_id
        snapshot = self._folder_snapshot
        if validate_name(str(name).strip()) or not folder or not snapshot.available or snapshot.error or snapshot.folder != folder:
            messagebox.showwarning("Không thể xóa ảnh", "Thư mục ảnh chưa sẵn sàng. Hãy làm mới rồi thử lại.", parent=self.root)
            return False
        if (index is not None and
                (not isinstance(index, int) or index < 0 or index >= len(self.items) or
                 self.items[index].name.casefold() != str(name).strip().casefold())):
            messagebox.showwarning("Danh sách đã thay đổi", "Ảnh không còn thuộc dòng đã chọn. Hãy mở lại Gallery.", parent=self.root)
            return False
        preferred = self.output_format.get() if hasattr(self, 'output_format') else 'png'
        expected = snapshot.for_icon(str(name).strip(), preferred)
        if expected is None:
            messagebox.showinfo("Không có ảnh", "Ảnh này không còn tồn tại hoặc chưa hợp lệ.", parent=self.root)
            return False
        key = expected.path.name.casefold()
        if confirm and not messagebox.askyesno("Xác nhận xóa ảnh",
                f"Xóa vĩnh viễn file ảnh này khỏi thư mục project?\n\n{expected.path.name}\n\n"
                "Tên ảnh và Prompt trong Excel/CSV vẫn được giữ nguyên.",
                icon="warning", parent=self.root):
            return False
        # Gallery's modal confirmation may allow project/selection changes;
        # keep the same checks for the instant-delete Quick Workspace path.
        if self.project_store.active_id != project_id or self.destination.get().strip() != folder:
            messagebox.showwarning("Project đã thay đổi", "Hãy chọn lại ảnh trong project hiện tại.", parent=self.root)
            return False
        if (index is not None and
                (index >= len(self.items) or self.items[index].name.casefold() != str(name).strip().casefold())):
            messagebox.showwarning("Danh sách đã thay đổi", "Tên ảnh đã thay đổi trong lúc xác nhận. Hãy thử lại.", parent=self.root)
            return False
        try:
            from folder_live import _png_fingerprint, _is_valid_png
            import stat as stat_module
            directory = Path(folder).resolve(strict=True)
            path = expected.path
            if (path.parent.resolve(strict=True) != directory or
                    path.name.casefold() != key or path.is_symlink()):
                raise ValueError("Đường dẫn ảnh không hợp lệ hoặc là liên kết ngoài thư mục.")
            info = path.stat(follow_symlinks=False)
            if not stat_module.S_ISREG(info.st_mode):
                raise ValueError("Đích xóa không phải file ảnh thông thường.")
            changed = (info.st_size != expected.size or info.st_mtime_ns != expected.modified_ns or
                       getattr(info, 'st_ino', 0) != expected.inode or
                       getattr(info, 'st_ctime_ns', 0) != expected.change_ns or
                       (expected.content_digest and _png_fingerprint(path) != expected.content_digest))
            if changed:
                if not accept_updated:
                    raise ValueError("PNG đã được sửa sau khi hiển thị. Hãy làm mới trước khi xóa.")
                # This is still the exact selected filename inside the active
                # output directory, but the file was re-exported/replaced.
                # Verify the *current* bytes are a real image, not an unrelated
                # file that happens to have an image extension.
                if not _is_valid_png(str(path), info.st_size):
                    raise ValueError("Ảnh hiện tại không hợp lệ hoặc đang được ghi. Hãy thử lại.")
                latest = path.stat(follow_symlinks=False)
                if (latest.st_size != info.st_size or latest.st_mtime_ns != info.st_mtime_ns or
                        getattr(latest, 'st_ino', 0) != getattr(info, 'st_ino', 0) or
                        getattr(latest, 'st_ctime_ns', 0) != getattr(info, 'st_ctime_ns', 0) or
                        not stat_module.S_ISREG(latest.st_mode) or path.is_symlink()):
                    raise ValueError("Ảnh đang thay đổi. Hãy thử xóa lại.")
            path.unlink()
        except (OSError, ValueError) as exc:
            messagebox.showwarning("Không xóa được ảnh", str(exc), parent=self.root)
            return False

        # One known on-disk deletion: update the in-memory snapshot immediately
        # instead of scanning the entire directory on Tk's UI thread. The native
        # watcher subsequently reconciles any unrelated external changes.
        remaining = dict(snapshot.files)
        remaining.pop(key, None)
        self._on_live_folder_snapshot(self._live_generation,
                FolderSnapshot(folder=folder, files=remaining))
        self._status("Đã xóa ảnh: " + expected.path.name)
        return True

    def _on_live_folder_snapshot(self, generation, snapshot):
        if (self._changing_project or generation != self._live_generation or
                snapshot.folder != self.destination.get().strip()):
            return  # Ignore any old project/path messages queued before switching.
        previous = self._folder_snapshot
        if snapshot.error or not snapshot.available:
            self._status("Thư mục PNG tạm thời không truy cập được; giữ nguyên các dấu Cần xem xét."
                         + (" " + snapshot.error if snapshot.error else ""))
            return
        self._folder_snapshot = snapshot
        changed_files = {key for key in previous.files.keys() | snapshot.files.keys()
                         if previous.files.get(key) != snapshot.files.get(key)}
        # Release only thumbnails for modified/removed PNGs, not the whole cache.
        if hasattr(self, '_thumbnail_cache'):
            for key in changed_files:
                old = previous.files.get(key)
                new = snapshot.files.get(key)
                if old is not None:
                    self._thumbnail_cache.invalidate_file(old.path)
                if new is not None:
                    self._thumbnail_cache.invalidate_file(new.path)
        # A review mark becomes invalid only when a PNG disappears/is corrupted,
        # or when the active folder has just been bound for the first time.
        preferred = self.output_format.get() if hasattr(self, 'output_format') else 'png'
        changed_names = {file.path.stem.casefold() for key in changed_files
                         for file in (previous.files.get(key), snapshot.files.get(key)) if file is not None}
        lost_valid = any(previous.for_icon(name, preferred) is not None and
                         snapshot.for_icon(name, preferred) is None for name in changed_names)
        full = previous.folder != snapshot.folder or not previous.files
        review_changed = self._prune_review_marks(snapshot) if full or lost_valid else False
        changed = self._apply_png_states(snapshot, None if full or review_changed else
                                         changed_names)
        # Status may remain 'Đã có' when the PNG is overwritten externally.
        # Compare metadata for the selected file as well as presence changes.
        selected_name = (self.items[self.selected_index].name
                         if self.selected_index is not None and 0 <= self.selected_index < len(self.items)
                         else None)
        old_selected_file = previous.for_icon(selected_name, preferred) if selected_name else None
        new_selected_file = snapshot.for_icon(selected_name, preferred) if selected_name else None
        if old_selected_file != new_selected_file and hasattr(self, '_refresh_selected_output_preview'):
            self._refresh_selected_output_preview()
        if changed or review_changed:
            if self.filter_var.get() == "Tất cả":
                # Update changed rows in-place: preserve list scroll and selection.
                labels = {"pending": "Chưa có", "existing": "Đã có", "review": "Cần xem xét",
                          "done": "Đã lưu", "invalid": "Tên lỗi", "corrupt": "Ảnh lỗi"}
                for index in changed:
                    iid = str(index)
                    if self.tree.exists(iid):
                        item = self.items[index]
                        self.tree.set(iid, "status", labels[item.state])
                        self.tree.item(iid, tags=(item.state,))
                self._update_counter()
            else:
                # Status filters change which rows belong in the list.
                self.draw_items()
            if self.selected_index in changed:
                self._refresh_target()
            if self.current_page == "progress" and hasattr(self, "progress_body"):
                self._refresh_progress_page()

        # A modified PNG may need a refreshed thumbnail even if its status is unchanged.
        if changed_files and self.current_page == "gallery":
            self.refresh_gallery()
            selected = getattr(self, "_gallery_selected", None)
            if selected and hasattr(self, "_gallery_select"):
                index, name, _ = selected
                self._gallery_select(index, name, self._matching_png_path(name))

    def refresh_from_disk(self):
        """Explicit F5/Refresh also performs a real disk scan immediately."""
        snapshot = scan_png_folder(self.destination.get().strip(), previous=self._folder_snapshot,
                                   check_contents=True)
        if snapshot.error or not snapshot.available:
            self._status("Thư mục PNG tạm thời không truy cập được; giữ nguyên các dấu Cần xem xét.")
            return
        self._on_live_folder_snapshot(self._live_generation, snapshot)
        if self.current_page == "gallery":
            self.refresh_gallery()

    def refresh_existing_states(self):
        """Immediate authoritative scan after CSV import or destination change."""
        snapshot = scan_png_folder(self.destination.get().strip())
        if snapshot.error or not snapshot.available:
            self._status("Thư mục PNG tạm thời không truy cập được; giữ nguyên các dấu Cần xem xét."
                         + (" " + snapshot.error if snapshot.error else ""))
            return
        self._folder_snapshot = snapshot
        self._prune_review_marks(snapshot)
        self._apply_png_states(snapshot)
        self._update_counter()

