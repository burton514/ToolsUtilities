"""ImageController: isolated responsibilities of the desktop controller.

No imports from application entry points: app.py binds these methods explicitly.
"""
from veloura.controllers.options import CONFLICT_OPTIONS, RESIZE_OPTIONS
from imageflow_core import ExportOptions, OUTPUT_FORMATS, SUPPORTED_EXTENSIONS, export_png
from PIL import Image, ImageTk
from pathlib import Path
from clipboard_image import copy_image_to_clipboard
from tkinter import filedialog, messagebox
import os, subprocess, sys, threading
import tkinter as tk


class ImageController:
    def _set_prompt_text(self, prompt):
        self.prompt_text.configure(state="normal")
        self.prompt_text.delete("1.0", "end")
        self.prompt_text.insert("1.0", prompt)
        self.prompt_text.configure(state="disabled")

    def _refresh_prompt(self):
        item = self.items[self.selected_index] if self.selected_index is not None and 0 <= self.selected_index < len(self.items) else None
        if item is None:
            self._set_prompt_text("Chọn tên ảnh để hiển thị prompt tương ứng.")
            return
        if not self.selected_prompt_col_index():
            self._set_prompt_text("Chưa chọn cột Prompt. Bấm 'Đổi cột' ở panel bên trái.")
        elif not item.prompt.strip():
            self._set_prompt_text("Dòng này không có prompt.")
        else:
            self._set_prompt_text(item.prompt)

    def copy_prompt(self):
        item = self.items[self.selected_index] if self.selected_index is not None and 0 <= self.selected_index < len(self.items) else None
        if item is None or not item.prompt.strip():
            messagebox.showinfo("Chưa có prompt", "Hãy chọn cột Prompt và một tên ảnh có nội dung prompt.")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(item.prompt)
        self.root.update_idletasks()
        self._status(f"Đã sao chép prompt ({len(item.prompt)} ký tự) của {item.name}")

    def choose_reference(self):
        file = filedialog.askopenfilename(title="Gán ảnh mẫu tham chiếu", filetypes=[
            ("Ảnh hỗ trợ", "*.png *.jpg *.jpeg *.webp *.bmp *.gif *.tif *.tiff *.avif"),
            ("Tất cả file", "*.*")])
        if file:
            self.set_reference(file)

    def on_reference_drop(self, event):
        try:
            paths = self.root.tk.splitlist(event.data)
        except (tk.TclError, ValueError):
            paths = [str(event.data).strip().strip("{}")]
        if len(paths) == 1:
            self.set_reference(paths[0])
        else:
            messagebox.showinfo("Ảnh mẫu", "Hãy chọn một ảnh mẫu mỗi lần.")
        return "copy"

    def set_reference(self, path):
        source = Path(path)
        if not source.is_file() or source.suffix.lower() not in SUPPORTED_EXTENSIONS:
            messagebox.showerror("Ảnh mẫu không hợp lệ", "Hãy chọn một file ảnh được hỗ trợ.")
            return
        try:
            with Image.open(source) as src:
                src.verify()
        except Exception as exc:
            messagebox.showerror("Không đọc được ảnh mẫu", str(exc))
            return
        self.reference_path.set(str(source))
        self._render_reference()
        self._status("Đã gán ảnh mẫu: " + source.name)

    def _restore_reference(self):
        source = Path(self.reference_path.get()) if self.reference_path.get() else None
        if source and source.is_file():
            self._render_reference()
        else:
            self.clear_reference()

    def _render_reference(self):
        source = Path(self.reference_path.get())
        try:
            with Image.open(source) as picture:
                preview = picture.convert("RGBA")
                preview.thumbnail((82, 70), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(preview)
            self.reference_photo = photo
            self.reference_img.configure(image=photo, text="", width=82, height=70)
            self.reference_name_lbl.configure(text=source.name if len(source.name) <= 25 else source.name[:22] + "…")
        except Exception as exc:
            self.clear_reference()
            messagebox.showerror("Không mở được ảnh mẫu", str(exc))

    def clear_reference(self):
        self.reference_path.set("")
        self.reference_photo = None
        self.reference_img.configure(image=self.reference_empty, text="Chưa có\nảnh mẫu", width=82, height=70)
        self.reference_name_lbl.configure(text="Chưa chọn ảnh")

    def copy_reference(self):
        source = Path(self.reference_path.get()) if self.reference_path.get() else None
        if not source or not source.is_file():
            messagebox.showinfo("Chưa có ảnh mẫu", "Hãy gán ảnh mẫu trước khi sao chép.")
            return
        try:
            copy_image_to_clipboard(source)
            self._status("Đã copy ảnh mẫu. Dán Ctrl+V vào ChatGPT hoặc ứng dụng khác.")
        except Exception as exc:
            messagebox.showerror("Không sao chép được ảnh", str(exc))

    def set_drop_active(self, flag):
        self.drag_over = flag
        self.paint_dropzone()
        return "copy"

    def on_drop(self, event):
        self.set_drop_active(False)
        try:
            paths = self.root.tk.splitlist(event.data)
        except (tk.TclError, ValueError):
            paths = [str(event.data).strip().strip("{}")]
        cleaned = [Path(x) for x in paths if x]
        if len(cleaned) != 1:
            messagebox.showwarning("Chỉ chọn một ảnh", "Hãy kéo một ảnh cho mỗi tên đang chọn để tránh gán nhầm.")
            return "copy"
        self.process_image(cleaned[0])
        return "copy"

    def _output_format_changed(self, *args):
        """Re-evaluate displayed file choice without loading PNGs on the UI thread."""
        if getattr(self, '_changing_project', False):
            return
        snapshot = getattr(self, '_folder_snapshot', None)
        if snapshot is None or snapshot.folder != self.destination.get().strip():
            return
        changed = self._apply_png_states(snapshot)
        if hasattr(self, 'tree'):
            self._refresh_review_rows(changed)
        if hasattr(self, '_refresh_target'):
            self._refresh_target()
        if hasattr(self, '_refresh_selected_output_preview'):
            self._refresh_selected_output_preview()
        if getattr(self, 'current_page', '') == 'gallery':
            self.refresh_gallery()

    def choose_picture(self):
        if self.processing:
            return
        if self.selected_index is None:
            messagebox.showinfo("Chưa chọn tên ảnh", "Hãy chọn một tên ảnh đích trước khi thêm ảnh.")
            return
        file = filedialog.askopenfilename(title="Chọn ảnh để gán tên", filetypes=[
            ("Ảnh hỗ trợ", "*.png *.jpg *.jpeg *.webp *.bmp *.gif *.tif *.tiff *.avif"),
            ("Mọi file", "*.*")])
        if file:
            self.process_image(Path(file))

    def process_image(self, path: Path, transient_source=False):
        if self.processing:
            self._status("Một ảnh khác đang được xử lý")
            return
        if self.selected_index is None:
            messagebox.showinfo("Chưa chọn tên ảnh", "Hãy chọn một tên ảnh trong danh sách bên trái.")
            return
        item = self.items[self.selected_index]
        if item.state == "invalid":
            messagebox.showwarning("Tên chưa hợp lệ", item.detail)
            return
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            messagebox.showerror("Ảnh không hợp lệ", "Hãy chọn một ảnh JPG, PNG, WEBP, BMP, GIF, TIFF hoặc AVIF.")
            return
        folder_str = self.destination.get().strip()
        if not folder_str:
            messagebox.showwarning("Chưa chọn thư mục", "Hãy chọn thư mục đích trong phần thiết lập.")
            return
        try:
            width, height = int(self.width_var.get()), int(self.height_var.get())
        except ValueError:
            if self.resize_enabled.get():
                messagebox.showwarning("Kích thước chưa đúng", "Chiều rộng và chiều cao phải là số nguyên dương.")
                return
            width, height = 1024, 1024
        if self.resize_enabled.get() and (not (1 <= width <= 16384 and 1 <= height <= 16384) or width * height > 80_000_000):
            messagebox.showwarning("Kích thước quá lớn", "Kích thước hợp lệ: 1–16384 px mỗi chiều, tối đa 80 triệu pixel.")
            return
        try:
            dest_dir = Path(folder_str).expanduser().resolve()
        except OSError as exc:
            messagebox.showerror("Thư mục không hợp lệ", str(exc))
            return
        fmt = self.output_format.get() if hasattr(self, 'output_format') else 'png'
        if fmt not in OUTPUT_FORMATS:
            messagebox.showwarning("Định dạng chưa đúng", "Hãy chọn PNG, JPG, WebP, BMP hoặc TIFF.")
            return
        target = dest_dir / (item.name + OUTPUT_FORMATS[fmt][0])
        same_source = os.path.normcase(str(path.resolve())) == os.path.normcase(str(target))
        overwrite = False
        if target.exists():
            strategy = CONFLICT_OPTIONS.get(self.conflict.get(), "ask")
            if strategy == "skip":
                self._append_activity(f"Bỏ qua · {target.name} đã tồn tại")
                self._status("Bỏ qua tên đã tồn tại")
                return
            if strategy == "ask":
                if not messagebox.askyesno("Ảnh đích đã tồn tại", f"File {target.name} đã có trong thư mục.\n\nBạn có muốn thay thế bằng ảnh mới không?", icon="warning"):
                    return
            overwrite = True
        opts = ExportOptions(destination=dest_dir, operation=self.operation.get(),
                             resize_enabled=self.resize_enabled.get(), width=width, height=height,
                             mode=RESIZE_OPTIONS.get(self.resize_mode.get(), "contain"),
                             overwrite=overwrite, output_format=fmt)
        selected = self.selected_index
        self.processing = True
        self._status(f"Đang xử lý: {path.name}")
        self.paint_dropzone()

        def worker():
            try:
                result = export_png(path, item.name, opts)
                self.messages.put(("export_ok", selected, result, path if transient_source else None))
            except Exception as exc:
                self.messages.put(("export_error", selected, path, str(exc), path if transient_source else None))
        threading.Thread(target=worker, daemon=True).start()

    def _destination_changed(self):
        if self._changing_project or self.processing or getattr(self, '_gallery_batch_running', False):
            return
        self.refresh_existing_states()
        self.draw_items()
        self._refresh_target()
        self.refresh_gallery()

    def pick_destination(self):
        folder = filedialog.askdirectory(title="Chọn thư mục lưu ảnh", initialdir=self.destination.get() or str(Path.home()))
        if folder:
            self.destination.set(folder)
            self._destination_changed()

    def open_destination(self):
        directory = Path(self.destination.get().strip())
        try:
            directory.mkdir(parents=True, exist_ok=True)
            if sys.platform.startswith("win"):
                os.startfile(str(directory))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(directory)])
            else:
                subprocess.Popen(["xdg-open", str(directory)])
        except Exception as exc:
            messagebox.showerror("Không mở được thư mục", str(exc))

    def update_resize_description(self):
        descriptions = {
            "contain": "Giữ nguyên tỷ lệ, căn giữa; phần trống sẽ trong suốt (PNG).",
            "cover": "Lấp đầy khung, cắt bớt viền để vừa đúng tỷ lệ đích.",
            "stretch": "Kéo ảnh vừa đúng rộng × cao; có thể làm méo hình.",
        }
        if hasattr(self, "resize_note"):
            self.resize_note.configure(text=descriptions.get(RESIZE_OPTIONS.get(self.resize_mode.get()), ""))

    def on_resize_toggled(self):
        state = "normal" if self.resize_enabled.get() else "disabled"
        if hasattr(self, "width_input"):
            self.width_input.configure(state=state)
            self.height_input.configure(state=state)
            self.resize_combo.configure(state="readonly" if self.resize_enabled.get() else "disabled")

