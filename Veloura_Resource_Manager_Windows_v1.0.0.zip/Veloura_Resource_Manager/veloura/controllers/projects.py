"""Project data and workflow handlers. GUI navigation lives in veloura.gui.projects."""
from veloura.gui.dialog_theme import BORDER, F, FIELD, INK, WHITE
from veloura.controllers.options import CONFLICT_OPTIONS, RESIZE_OPTIONS
from pathlib import Path
from tkinter import messagebox
from imageflow_core import normalize_source_path
from file_picker import source_file_path
import tkinter as tk


class ProjectController:
    def _notify_project_warnings(self):
        warnings = [self.project_store.recovery_warning, *self.project_store.load_warnings]
        warnings = [warning for warning in warnings if warning]
        if warnings:
            messagebox.showwarning("Cần kiểm tra dữ liệu Project", "\n\n".join(warnings), parent=self.root)

    def _sync_project_registry(self):
        """Read Agent edits without interrupting an active GUI edit/export.

        File changes are already handled by Live Folder Sync. This periodic
        metadata refresh is intentionally less frequent and never changes
        widgets while the user is typing in a field.
        """
        self._sync_project_task = None
        if self._closing:
            return
        editing = True
        try:
            try:
                focused = self.root.focus_get()
                editing = focused is not None and focused.winfo_class() in ('Entry','TEntry','Text','TCombobox')
            except (tk.TclError, KeyError):
                # Native dialogs may temporarily own focus while Tk is unable
                # to resolve their internal widget name. Never sync mid-dialog.
                editing = True
            if not self.processing and not self._changing_project and self.save_task is None and not editing:
                previous = dict(self.project_store.active)
                changed = self.project_store.sync_from_disk()
                if changed:
                    current = self.project_store.active
                    if any(current.get(key) != previous.get(key) for key in (
                            'id', 'destination', 'last_source', 'name',
                            'last_sheet', 'last_column', 'last_prompt_column',
                            'has_header', 'prompt_template', 'template_enabled', 'output_format')):
                        self._install_project(current)
                    else:
                        self.settings.update(current)
                        marks = set(current.get('review_marks', []))
                        if marks != self.review_marks:
                            self.review_marks = marks
                            self._review_marks_dirty = False
                            changed_rows = self._apply_png_states(self._folder_snapshot)
                            self._refresh_review_rows(changed_rows)
                            if self.selected_index in changed_rows:
                                self._refresh_target()
                            elif hasattr(self, '_update_review_controls'):
                                self._update_review_controls()
                            if self.current_page == 'gallery':
                                self.refresh_gallery()
                                selected = getattr(self, '_gallery_selected', None)
                                if selected and hasattr(self, '_gallery_select'):
                                    idx, name, _ = selected
                                    if any(self.items[i].name == name for i in changed_rows):
                                        self._gallery_select(idx, name, self._matching_png_path(name))
                        if (current.get('reference_paths') != previous.get('reference_paths') or
                            current.get('reference_assignments') != previous.get('reference_assignments')):
                            self._restore_reference()
                    self._refresh_project_selector()
                    if hasattr(self, 'projects_list') and self.current_page == 'projects':
                        self.refresh_projects_page()
                # Refresh the loaded spreadsheet even when projects.json itself
                # has not changed. A failed registry sync must not be the only
                # route into source-file monitoring.
                self._reload_source_if_changed()
        except (OSError, ValueError, KeyError) as exc:
            self._status('Không đồng bộ được dữ liệu project: ' + str(exc))
        finally:
            if not self._closing:
                self._sync_project_task = self.root.after(2800, self._sync_project_registry)

    def _restore_startup_project(self):
        # Do not reimport over a source the user has already opened or a
        # project selected during the first moments after app startup.
        if (self.project_store.active_id != self._initial_project_id or
                self.source_path is not None or self.workbook is not None or self.processing):
            return
        source = self.project_store.active.get("last_source", "")
        if source and Path(normalize_source_path(source)).is_file():
            self.import_source(source)

    def _on_project_selected(self, event=None):
        wanted = self.project_choice_var.get()
        project = next((p for p in self.project_store.projects if p["name"] == wanted), None)
        if project:
            self.activate_project(project["id"])

    def activate_project(self, project_id: str):
        if project_id == self.project_store.active_id:
            return
        if self.processing or getattr(self, '_gallery_batch_running', False):
            self.project_choice_var.set(self.project_store.active["name"])
            messagebox.showinfo("Đang xử lý ảnh", "Hãy hoàn tất thao tác hiện tại trước khi đổi project.")
            return
        if self.save_task:
            try:
                self.root.after_cancel(self.save_task)
            except tk.TclError:
                pass
            self.save_task = None
        self.persist_settings()
        old_id = self.project_store.active_id
        self.project_logs[old_id] = self.logs
        self.project_store.select(project_id)
        self._install_project(self.project_store.active)

    def _install_project(self, project):
        self._changing_project = True
        try:
            if self.workbook:
                try:
                    self.workbook.close()
                except Exception:
                    pass
            self.workbook = None
            self.source_path = None
            self._source_disk_signature = None
            self._source_change_pending = None
            self._source_restore_name = None
            self.items = []
            self.columns = []
            self.selected_index = None
            self.read_ticket += 1
            self.render_ticket += 1
            self.duplicates = 0
            self._source_has_collapsed = False
            self.settings.update(project)
            self.destination.set(project["destination"])
            self.operation.set(project["operation"])
            self.output_format.set(str(project.get("output_format", "png")).lower())
            self.resize_enabled.set(bool(project["resize_enabled"]))
            self.width_var.set(str(project["resize_width"]))
            self.height_var.set(str(project["resize_height"]))
            self.resize_mode.set(self._label_for(RESIZE_OPTIONS, project["resize_mode"]))
            self.conflict.set(self._label_for(CONFLICT_OPTIONS, project["conflict"]))
            self.advance.set(bool(project["advance"]))
            self.has_header.set(bool(project["has_header"]))
            self.reference_path.set(project["reference_path"])
            self.sheet_var.set("")
            self.column_var.set("")
            self.prompt_column_var.set("Không chọn")
            self.project_choice_var.set(project["name"])
            self.recent_file_lbl.configure(text="Chưa có bảng dữ liệu")
            self.recent_btn.pack_forget()
            self.sheet_combo.configure(values=[])
            self.column_combo.configure(values=[])
            self.prompt_column_combo.configure(values=["Không chọn"])
            self.search_var.set("")
            self.filter_var.set("Tất cả")
            self.gallery_search_var.set("")
            self.gallery_filter_var.set("Tất cả")
            self.review_marks = set(str(name).strip() for name in project.get("review_marks", []) if str(name).strip())
            self._review_marks_dirty = False
            self.logs = self.project_logs.setdefault(project["id"], [])
            if len(self.logs) > 300:
                del self.logs[:-300]
            self.activity.configure(state="normal")
            self.activity.delete("1.0", "end")
            if self.logs:
                for record in self.logs[-8:]:
                    self.activity.insert("end", str(record.get("Tên ảnh", "")) + " · " + str(record.get("Kết quả", "")) + "\n")
            else:
                self.activity.insert("end", "Chưa có ảnh nào được xử lý trong phiên này.\n")
            self.activity.configure(state="disabled")
            self.preview_ref = None
            self.preview_img.configure(image=self.preview_empty)
            self.preview_title.configure(text="Chưa có ảnh xuất")
            self.preview_sub.configure(text="Ảnh đã lưu sẽ hiện tại đây")
            self.on_resize_toggled()
            self.draw_items()
            self._update_empty_selection()
            self._restore_reference()
        finally:
            self._changing_project = False
        self._refresh_project_selector()
        if project["last_source"]:
            file = Path(normalize_source_path(project["last_source"]))
            if file.is_file():
                self.import_source(str(file))
            else:
                self.toggle_source_details(True)
                self._status("Không tìm thấy bảng dữ liệu của project. Hãy chọn Excel/CSV mới.")
        else:
            self.toggle_source_details(True)
        self.refresh_existing_states()
        self.draw_items()
        self.refresh_gallery()
        self.refresh_projects_page()
        self._status("Đã chuyển sang project: " + project["name"])

    def _refresh_project_selector(self):
        self.project_choice.configure(values=[p["name"] for p in self.project_store.projects])
        self.project_choice_var.set(self.project_store.active["name"])

    def _validate_project_fields(self, name, description, source, destination):
        name = name.strip()
        description = description.strip()
        destination = destination.strip()
        source = normalize_source_path(source)
        if not name:
            raise ValueError("Hãy nhập tên project.")
        if not source:
            raise ValueError("Hãy chọn file Excel hoặc CSV.")
        source = str(source_file_path(source))
        if not destination:
            raise ValueError("Hãy chọn thư mục lưu ảnh Image Gen.")
        if not Path(destination).expanduser().is_dir():
            raise ValueError("Thư mục lưu chưa tồn tại. Hãy chọn một thư mục có thật.")
        return name, destination, description, source

    def _project_dialog(self, title: str, project=None):
        """Four-field create/edit form. Both paths are readonly with picker actions."""
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.configure(bg=WHITE)
        dialog.geometry("700x560")
        dialog.minsize(600, 500)
        dialog.transient(self.root)
        dialog.grab_set()
        content = tk.Frame(dialog, bg=WHITE)
        content.pack(fill="both", expand=True, padx=22, pady=18)
        self.txt(content, title, 15, INK, True).pack(anchor="w", pady=(0, 15))
        self.txt(content, "Tên Project", 10, INK, True).pack(anchor="w", pady=(0, 4))
        name_var = tk.StringVar(value=project.get("name", "") if project else "")
        name_entry = tk.Entry(content, textvariable=name_var, font=F, fg=INK, bg=FIELD,
                              relief="flat", highlightthickness=1, highlightbackground=BORDER)
        name_entry.pack(fill="x", ipady=8, pady=(0, 12))

        self.txt(content, "Mô tả (có thể trống)", 10, INK, True).pack(anchor="w", pady=(0, 4))
        desc_text = tk.Text(content, font=F, fg=INK, bg=FIELD, height=3, wrap="word",
                            relief="flat", highlightthickness=1, highlightbackground=BORDER)
        desc_text.pack(fill="x", pady=(0, 12))
        desc_text.insert("1.0", str(project.get("description", "") if project else ""))

        self.txt(content, "File Excel/CSV", 10, INK, True).pack(anchor="w", pady=(0, 4))
        source_var = tk.StringVar(value=project.get("last_source", "") if project else "")
        source_row = tk.Frame(content, bg=WHITE)
        source_row.pack(fill="x", pady=(0, 12))
        source_entry = tk.Entry(source_row, textvariable=source_var, font=F, fg=INK, bg=FIELD,
                 state="readonly", readonlybackground=FIELD, relief="flat", cursor="hand2",
                 highlightthickness=1, highlightbackground=BORDER)
        source_entry.pack(side="left", fill="x", expand=True, ipady=8)
        source_entry.bind("<Button-1>", lambda _: self._browse_project_source(dialog, source_var))
        self.button(source_row, "Chọn file...", lambda: self._browse_project_source(dialog, source_var),
                    subtle=True).pack(side="right", padx=(8, 0))

        self.txt(content, "Thư mục lưu", 10, INK, True).pack(anchor="w", pady=(0, 4))
        folder_var = tk.StringVar(value=project.get("destination", "") if project else "")
        folder_row = tk.Frame(content, bg=WHITE)
        folder_row.pack(fill="x")
        folder_entry = tk.Entry(folder_row, textvariable=folder_var, font=F, fg=INK, bg=FIELD,
                 state="readonly", readonlybackground=FIELD, relief="flat", cursor="hand2",
                 highlightthickness=1, highlightbackground=BORDER)
        folder_entry.pack(side="left", fill="x", expand=True, ipady=8)
        folder_entry.bind("<Button-1>", lambda _: self._browse_project_folder(dialog, folder_var))
        self.button(folder_row, "Chọn thư mục...", lambda: self._browse_project_folder(dialog, folder_var),
                    subtle=True).pack(side="right", padx=(8, 0))

        result = {"data": None}
        buttons = tk.Frame(content, bg=WHITE)
        buttons.pack(side="bottom", fill="x", pady=(14, 0))

        def save():
            try:
                result["data"] = self._validate_project_fields(name_var.get(),
                                      desc_text.get("1.0", "end-1c"), source_var.get(), folder_var.get())
            except (ValueError, OSError) as exc:
                messagebox.showwarning("Thông tin project chưa hợp lệ", str(exc), parent=dialog)
                return
            dialog.destroy()
        self.button(buttons, "Lưu project", save, primary=True).pack(side="right")
        self.button(buttons, "Hủy", dialog.destroy, subtle=True).pack(side="right", padx=(0, 8))
        dialog.bind("<Escape>", lambda _: dialog.destroy())
        dialog.update_idletasks()
        position_x = self.root.winfo_rootx() + max(0, (self.root.winfo_width() - dialog.winfo_width()) // 2)
        position_y = self.root.winfo_rooty() + max(0, (self.root.winfo_height() - dialog.winfo_height()) // 2)
        dialog.geometry(f"+{position_x}+{position_y}")
        name_entry.focus_set()
        self.root.wait_window(dialog)
        return result["data"]

    def new_project(self):
        if self.processing:
            messagebox.showinfo("Đang xử lý", "Hãy hoàn tất thao tác trước khi tạo project.")
            return
        result = self._project_dialog("Tạo project mới")
        if not result:
            return
        try:
            project = self.project_store.add(*result)
        except ValueError as exc:
            messagebox.showwarning("Project không hợp lệ", str(exc))
            return
        self._refresh_project_selector()
        self.activate_project(project["id"])
        self.show_page("projects")

    def _save_project_fields(self, project_id, data):
        """Save via either Projects detail or modal; preserve other project settings."""
        project = self.project_store.get(project_id)
        active = project_id == self.project_store.active_id
        old_source = str(project.get("last_source") or "")
        old_folder = str(project["destination"])
        if active:
            self.persist_settings()
        self.project_store.edit(project_id, *data)
        if active and (old_folder != data[1] or old_source != data[3]):
            # Reinstall rebinds monitoring, Workspace data and Gallery to new paths.
            self._install_project(self.project_store.active)
        else:
            self._refresh_project_selector()
            if active and hasattr(self, "nav_project_name"):
                self.nav_project_name.configure(text=data[0][:22])
        self.refresh_projects_page()

    def edit_project(self, project_id=None):
        if self.processing:
            messagebox.showinfo("Đang xử lý", "Hãy hoàn tất thao tác trước khi sửa project.")
            return
        project = self.project_store.get(project_id or self.project_store.active_id)
        result = self._project_dialog("Chỉnh sửa project", project)
        if not result:
            return
        try:
            self._save_project_fields(project["id"], result)
        except ValueError as exc:
            messagebox.showwarning("Project không hợp lệ", str(exc))

    def delete_project(self, project_id):
        project = self.project_store.get(project_id)
        if self.processing:
            messagebox.showinfo("Đang xử lý", "Hãy hoàn tất thao tác trước khi xóa project.")
            return
        if not messagebox.askyesno("Xóa project khỏi danh sách", "Xóa cấu hình của project '" + project["name"] + "'?\n\nCác file PNG trong thư mục vẫn được giữ nguyên."):
            return
        was_active = project_id == self.project_store.active_id
        try:
            if was_active:
                self.persist_settings()
            self.project_store.remove(project_id)
        except ValueError as exc:
            messagebox.showwarning("Không xóa được", str(exc))
            return
        self.project_logs.pop(project_id, None)
        if was_active:
            self._install_project(self.project_store.active)
        self._refresh_project_selector()
        self.refresh_projects_page()

