@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_exe_windows.ps1" -CopyToDesktop
if errorlevel 1 (
  echo.
  echo Desktop EXE installation failed. See the message above.
  pause
  exit /b 1
)
echo.
echo Veloura Resource Manager is now on your Desktop.
pause
endlocal
