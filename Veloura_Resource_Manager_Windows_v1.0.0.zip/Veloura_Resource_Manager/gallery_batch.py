"""Safe, folder-first batch transformations for Gallery selections.

No image data or thumbnails are cached on disk. Work is serialized with the
same destination-folder lock used by the GUI and local MCP image exporter.
"""
from __future__ import annotations

import hashlib
import os
import stat
from dataclasses import dataclass
from pathlib import Path

from imageflow_core import (APP_DIR, OUTPUT_EXTENSIONS, OUTPUT_FORMATS,
                            ExportOptions, _export_image_unlocked)
from folder_live import IconFile, _png_fingerprint
from storage_lock import file_lock


@dataclass(frozen=True)
class BatchJob:
    folder: str
    project_id: str
    files: tuple[IconFile, ...]
    operation: str  # resize / convert
    width: int = 1024
    height: int = 1024
    mode: str = 'contain'
    output_format: str = 'png'
    overwrite: bool = False
    remove_original: bool = False


@dataclass
class BatchReport:
    succeeded: int = 0
    skipped: int = 0
    failed: int = 0
    problems: tuple[str, ...] = ()


def validated_source(directory: Path, expected: IconFile) -> Path:
    """Fail closed when a selected entry disappeared or was replaced."""
    path = Path(expected.path)
    if path.is_symlink() or path.parent.resolve(strict=True) != directory:
        raise ValueError('File không thuộc thư mục project hoặc là liên kết ngoài thư mục')
    actual = path.stat(follow_symlinks=False)
    if not stat.S_ISREG(actual.st_mode):
        raise ValueError('Ảnh đã chọn không còn là file thông thường')
    if (actual.st_size != expected.size or actual.st_mtime_ns != expected.modified_ns
            or getattr(actual, 'st_ino', 0) != expected.inode
            or getattr(actual, 'st_ctime_ns', 0) != expected.change_ns
            or (expected.content_digest and _png_fingerprint(path) != expected.content_digest)):
        raise ValueError('Ảnh đã thay đổi sau khi chọn; hãy làm mới Gallery')
    if not expected.valid or path.suffix.lower() not in OUTPUT_EXTENSIONS:
        raise ValueError('Định dạng ảnh không hợp lệ')
    return path


def run_batch(job: BatchJob, notify=None) -> BatchReport:
    """Do work on a worker thread, never on the Tk event loop."""
    if job.operation not in ('resize', 'convert'):
        raise ValueError('Thao tác hàng loạt không hợp lệ')
    if job.operation == 'resize':
        if (job.mode not in ('contain', 'cover', 'stretch') or
                not (1 <= job.width <= 16384 and 1 <= job.height <= 16384) or
                job.width * job.height > 80_000_000):
            raise ValueError('Kích thước resize không hợp lệ')
    if job.operation == 'convert' and job.output_format not in OUTPUT_FORMATS:
        raise ValueError('Định dạng xuất không hợp lệ')
    root = Path(job.folder).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise NotADirectoryError('Thư mục ảnh không khả dụng')
    lock_key = hashlib.sha256(os.path.normcase(str(root)).encode('utf-8')).hexdigest()
    report = BatchReport()
    problems = []
    # Avoid applying the same source twice even when a caller sends duplicate IDs.
    seen = set()
    for position, expected in enumerate(job.files, 1):
        try:
            with file_lock(APP_DIR / 'locks' / (lock_key + '.lock')):
                path = validated_source(root, expected)
                key = path.name.casefold()
                if key in seen:
                    report.skipped += 1
                    continue
                seen.add(key)
                format_key = OUTPUT_EXTENSIONS[path.suffix.lower()]
                new_format = format_key if job.operation == 'resize' else job.output_format
                extension = path.suffix if job.operation == 'resize' else OUTPUT_FORMATS[new_format][0]
                destination = root / (path.stem + extension)
                if job.operation == 'convert' and destination == path:
                    report.skipped += 1
                    continue
                if destination.is_symlink() or (destination.exists() and destination.is_dir()):
                    raise ValueError('Đích không phải file thường hoặc là đường dẫn liên kết')
                options = ExportOptions(
                    destination=root, operation='copy',
                    resize_enabled=job.operation == 'resize',
                    width=job.width, height=job.height, mode=job.mode,
                    overwrite=True if job.operation == 'resize' else job.overwrite,
                    output_format=new_format, output_extension=extension,
                )
                try:
                    _export_image_unlocked(path, path.stem, options)
                except FileExistsError:
                    report.skipped += 1
                else:
                    # Only delete original after successful atomic conversion and
                    # an explicit user choice; never remove on failure/skip.
                    if job.operation == 'convert' and job.remove_original:
                        try:
                            # Check again: an unrelated editor may replace the
                            # source while the conversion was in progress.
                            validated_source(root, expected)
                            path.unlink()
                        except (OSError, ValueError) as exc:
                            problems.append(f'{path.name}: ảnh mới đã lưu nhưng chưa xóa ảnh gốc ({exc})')
                            report.failed += 1
                            continue
                    report.succeeded += 1
        except (OSError, ValueError, RuntimeError) as exc:
            report.failed += 1
            if len(problems) < 12:
                problems.append(f'{expected.path.name}: {exc}')
        finally:
            if notify:
                notify(position, len(job.files))
    report.problems = tuple(problems)
    return report
