"""Portrait quick-workspace features wired explicitly into the desktop manager.

Toggled by Windows' middle caption button. Desktop widgets remain alive while
not mapped; folder-based image state is shared with the normal workspace.
"""
from __future__ import annotations

import tkinter as tk
import tkinter.font as tkfont
from tkinter import messagebox
from urllib.parse import unquote, urlsplit
from urllib.request import url2pathname
from pathlib import Path
from PIL import Image, ImageTk

from app_version import APP_TITLE
from modern_ui import BLACK, BORDER, FIELD, F, INK, MED, MUTED, SOFT, WHITE


class CompactWindowActions:
    def _build_layout(self):
        self._build_desktop_layout()
        self._desktop_shell = self.content_host.master
        self._full_window_geometry = self.settings.get('window_geometry', '1250x790')
        self._compact_active = False
        self._compact_switching = False
        self._compact_toggle_job = None
        self._compact_caption_target = None
        self._compact_last_window_state = self.root.state()
        self._compact_minimized = False
        self._compact_pin = tk.BooleanVar(master=self.root, value=False)
        self._compact_dnd_job = None
        self._compact_dnd_bound = False
        self._compact_dnd_error = None
        self._compact_photo = None
        self._compact_preview_key = None
        self._compact_preview_canvas_item = None
        self._compact_resize_job = None
        self._compact_tooltip_job = None
        self._compact_tooltip_window = None
        self._compact_full_name = ''
        self._compact_full_detail = ''
        self._build_compact_layout()
        # Tk's native caption maximize/restore button is owned by Windows.
        # Listen to the WM state it produces instead of hiding/replacing the
        # window border or intercepting unrelated minimize events.
        self.root.bind('<Configure>', self._compact_window_state_changed, add='+')
        # At startup Tk can report 'iconic' during the initial Configure
        # even though the window becomes normal immediately afterwards.
        self.root.after(150, self._compact_capture_normal_geometry)

    def _compact_icon_button(self, parent, icon_name, command, tooltip, *, size=32):
        icon = self._get_icon(icon_name)
        button = tk.Button(parent, image=icon if icon else '', text='' if icon else '‹',
                           command=command, bg=WHITE, fg=BLACK, activebackground=SOFT,
                           highlightbackground=BORDER, highlightthickness=1,
                           relief='flat', bd=0, cursor='hand2', width=size, height=size,
                           takefocus=True)
        # Keep a descriptive accessibility hint without displaying button text.
        button.tooltip_description = tooltip
        return button

    def _build_compact_layout(self):
        self.compact_host = tk.Frame(self.root, bg=WHITE)
        # Do not pack the compact widgets until the middle caption button is clicked.
        self.compact_host.grid_columnconfigure(0, weight=1)
        self.compact_host.grid_rowconfigure(3, weight=1)

        nav = tk.Frame(self.compact_host, bg=WHITE)
        nav.grid(row=0, column=0, sticky='ew', padx=11, pady=(12, 7))
        self._compact_icon_button(nav, 'previous_item', self.select_previous,
                                  'Ảnh trước').pack(side='left', padx=(0, 6))
        self._compact_icon_button(nav, 'next_item', self._compact_select_next,
                                  'Ảnh tiếp theo').pack(side='left')
        self.compact_pin_btn = self._compact_icon_button(
            nav, 'project_pin', self._compact_toggle_pin, 'Ghim cửa sổ luôn ở trên')
        self.compact_pin_btn.pack(side='right')
        self._compact_bind_tooltip(self.compact_pin_btn,
                                   lambda: self.compact_pin_btn.tooltip_description)

        # A fixed-height, non-propagating name row prevents long Excel/CSV
        # filenames from stealing all of the output preview's space.
        name_card = tk.Frame(self.compact_host, bg=SOFT, height=43,
                             highlightbackground=BORDER, highlightthickness=1)
        name_card.grid(row=1, column=0, sticky='ew', padx=11, pady=(0, 9))
        name_card.grid_propagate(False)
        self.compact_name_label = tk.Label(
            name_card, text='Chưa chọn tên ảnh', font=('Segoe UI Semibold', 11),
            fg=INK, bg=SOFT, anchor='center', justify='center', height=1,
            wraplength=0, pady=0)
        # The name label takes only the remaining width; the copy action must
        # stay visible even for long source filenames or minimum-size windows.
        self.compact_copy_prompt_btn = self._compact_icon_button(
            name_card, 'prompt_copy', self.copy_prompt, 'Sao chép Prompt', size=28)
        self.compact_copy_prompt_btn.pack(side='right', padx=(0, 6), pady=5)
        self._compact_bind_tooltip(
            self.compact_copy_prompt_btn,
            lambda: self.compact_copy_prompt_btn.tooltip_description)
        self.compact_name_label.pack(side='left', fill='both', expand=True, padx=(8, 4), pady=5)
        self.compact_name_label.bind('<Configure>', self._compact_name_resized)
        self._compact_bind_tooltip(self.compact_name_label,
                                   lambda: self._compact_full_name)

        input_card = tk.Frame(self.compact_host, bg=WHITE, highlightbackground=BORDER,
                              highlightthickness=1)
        input_card.grid(row=2, column=0, sticky='ew', padx=11, pady=(0, 9))
        input_header = tk.Frame(input_card, bg=WHITE)
        input_header.pack(fill='x', padx=9, pady=(9, 5))
        tk.Label(input_header, text='Ảnh đầu vào', font=MED, fg=INK, bg=WHITE).pack(side='left')
        self.button(input_header, 'Chọn ảnh', self.choose_picture, small=True,
                    icon_name='image_open').pack(side='right')
        self.compact_drop_canvas = tk.Canvas(input_card, height=112, bg=WHITE,
                                             highlightthickness=0, bd=0,
                                             cursor='hand2')
        self.compact_drop_canvas.pack(fill='x', padx=9, pady=(0, 7))
        self.compact_drop_canvas.bind('<Button-1>', lambda event: self.choose_picture())
        self.compact_drop_canvas.bind('<Configure>', lambda event: self._paint_compact_dropzone())
        self.button(input_card, 'Dán ảnh (Ctrl+V)', self.paste_image_from_clipboard,
                    primary=True, icon_name='image_paste', small=True).pack(
                        fill='x', padx=9, pady=(0, 9))
        # Register *after* the quick workspace has actually been mapped.
        # Registering a hidden Tk window at startup is unreliable with the
        # native Windows OLE drag/drop backend, especially when topmost toggles.
        # Both card and canvas are targets, so their padding is droppable too.
        self._compact_drop_targets = (input_card, self.compact_drop_canvas)

        output_card = tk.Frame(self.compact_host, bg=WHITE, highlightbackground=BORDER,
                               highlightthickness=1)
        output_card.grid(row=3, column=0, sticky='nsew', padx=11, pady=(0, 11))
        output_header = tk.Frame(output_card, bg=WHITE)
        output_header.pack(fill='x', padx=10, pady=(8, 5))
        tk.Label(output_header, text='Ảnh đầu ra', font=MED,
                 fg=INK, bg=WHITE).pack(side='left')
        # Remove the current output immediately (without asking for confirmation).
        # The shared file-scoped deletion still protects the project and source row.
        self.compact_delete_btn = self.button(
            output_header, 'Xóa ảnh', self._compact_delete_output,
            icon_name='image_remove', small=True)
        self.compact_delete_btn.configure(state='disabled')
        self.compact_delete_btn.pack(side='right')
        photo_area = tk.Frame(output_card, bg=FIELD, highlightbackground=BORDER,
                              highlightthickness=1)
        photo_area.pack(fill='both', expand=True, padx=9, pady=(0, 5))
        # Unlike a Label containing a PhotoImage, Canvas has no intrinsic image
        # size that can force the layout beyond the available window height.
        self.compact_preview_canvas = tk.Canvas(
            photo_area, bg=FIELD, highlightthickness=0, bd=0, width=1, height=1)
        self.compact_preview_canvas.pack(fill='both', expand=True, padx=4, pady=4)
        self.compact_preview_canvas.bind('<Configure>', self._compact_preview_resized)
        self.compact_preview_detail = tk.Label(
            output_card, text='Đọc trực tiếp từ thư mục project', height=1,
            font=('Segoe UI', 9), fg=MUTED, bg=WHITE,
            justify='center', anchor='center', wraplength=0)
        self.compact_preview_detail.pack(fill='x', padx=9, pady=(0, 8))
        self.compact_preview_detail.bind('<Configure>', self._compact_detail_resized)
        self._compact_bind_tooltip(self.compact_preview_detail,
                                   lambda: self._compact_full_detail)
        self._paint_compact_dropzone()

    def _compact_schedule_dnd_registration(self):
        """Activate/rebind the native OLE drop targets on the visible window."""
        if not self._compact_active or self._compact_dnd_job is not None:
            return
        self._compact_dnd_job = self.root.after(120, self._compact_activate_drop_targets)

    def _compact_activate_drop_targets(self):
        self._compact_dnd_job = None
        if not self._compact_active:
            return
        canvas = self.compact_drop_canvas
        if not canvas.winfo_ismapped():
            self._compact_schedule_dnd_registration()
            return
        try:
            from tkinterdnd2 import DND_FILES, DND_TEXT
            # Refresh registration after caption-mode or pin changes, as the
            # Windows OLE drop target is associated with a native HWND.
            for target in self._compact_drop_targets:
                if self._compact_dnd_bound:
                    target.drop_target_unregister()
                target.drop_target_register(DND_FILES, DND_TEXT)
                if not self._compact_dnd_bound:
                    target.dnd_bind('<<DropEnter>>', lambda event: self.set_drop_active(True))
                    target.dnd_bind('<<DropLeave>>', lambda event: self.set_drop_active(False))
                    target.dnd_bind('<<DropPosition>>', lambda event: 'copy')
                    # A single <<Drop>> binding avoids double exports on
                    # tkdnd builds that emit both generic and typed events.
                    target.dnd_bind('<<Drop>>', self._compact_on_drop)
            self._compact_dnd_bound = True
            self._compact_dnd_error = None
        except (ImportError, AttributeError, tk.TclError) as exc:
            self._compact_dnd_error = str(exc) or 'Thiếu hỗ trợ kéo thả'
            self._compact_dnd_bound = False
            self._status('Không bật được kéo thả ảnh. Hãy sử dụng Chọn ảnh hoặc Ctrl+V.')
        self._paint_compact_dropzone()

    def _compact_on_drop(self, event, kind='files'):
        """Accept Explorer files and local file:// URLs, not remote URLs."""
        self.set_drop_active(False)
        data = str(getattr(event, 'data', '')).strip()
        if kind == 'files':
            # The generic event does not reliably expose the negotiated DND
            # type. Prefer obvious local text/URI payloads over Tcl splitlist.
            if (data.lower().startswith(('file://', 'http://', 'https://')) or
                    Path(data).is_file()):
                kind = 'text'
            else:
                return self.on_drop(event)
        # DND_TEXT is offered by some browser/file-manager sources instead of
        # CF_HDROP. Never download remote URLs or treat a URL as a local path.
        entries = [line.strip() for line in data.splitlines()
                   if line.strip() and not line.startswith('#')]
        if len(entries) == 1:
            raw = entries[0]
            # Windows drive paths are parsed as URL scheme 'c'/'d', so test
            # the real filesystem before interpreting URI syntax.
            if Path(raw).is_file():
                self.process_image(Path(raw))
                return 'copy'
            uri = urlsplit(raw)
            if uri.scheme.lower() == 'file':
                path = url2pathname(unquote(uri.path))
                if uri.netloc and uri.netloc.lower() != 'localhost':
                    path = f'//{uri.netloc}{path}'
                self.process_image(Path(path))
                return 'copy'
        messagebox.showinfo(
            'Không nhận được file ảnh',
            'Hãy kéo file ảnh từ File Explorer vào khung. Với ảnh trong trình '
            'duyệt, hãy sao chép ảnh rồi nhấn Ctrl+V hoặc tải ảnh về trước.',
            parent=self.root)
        return 'copy'

    def _compact_delete_output(self):
        """Remove the current on-disk output without a confirmation dialog."""
        index = self.selected_index
        if index is None or not 0 <= index < len(self.items):
            return False
        if self.processing:
            messagebox.showinfo('Đang xử lý ảnh',
                                'Hãy đợi ảnh đang xử lý hoàn tất trước khi xóa.',
                                parent=self.root)
            return False
        return self.delete_gallery_png(index, self.items[index].name,
                                       confirm=False, accept_updated=True)

    @staticmethod
    def _compact_ellipsize(text, max_width, measure):
        """Fit one line by rendered pixels, not by the number of characters."""
        text = str(text)
        max_width = max(0, int(max_width))
        if not text or max_width <= 0:
            return ''
        if measure(text) <= max_width:
            return text
        dots = '…'
        if measure(dots) > max_width:
            return ''
        low, high = 0, len(text)
        while low < high:
            mid = (low + high + 1) // 2
            if measure(text[:mid] + dots) <= max_width:
                low = mid
            else:
                high = mid - 1
        return text[:low] + dots

    def _compact_fit_label(self, label, full_text):
        if not label.winfo_exists():
            return
        width = label.winfo_width() - 12
        if width <= 0:
            return
        font = tkfont.Font(font=label.cget('font'))
        shown = self._compact_ellipsize(full_text, width, font.measure)
        if label.cget('text') != shown:
            label.configure(text=shown)

    def _compact_name_resized(self, event=None):
        self._compact_fit_label(self.compact_name_label, self._compact_full_name)

    def _compact_detail_resized(self, event=None):
        self._compact_fit_label(self.compact_preview_detail, self._compact_full_detail)

    def _compact_set_detail(self, value):
        self._compact_full_detail = str(value)
        self._compact_detail_resized()

    def _compact_bind_tooltip(self, widget, text_provider):
        """Transient in-memory tooltip; the full text remains copyable by right click."""
        widget.bind('<Enter>', lambda event: self._compact_schedule_tooltip(widget, text_provider))
        widget.bind('<Leave>', lambda event: self._compact_hide_tooltip())
        widget.bind('<ButtonPress>', lambda event: self._compact_hide_tooltip())
        widget.bind('<Button-3>', lambda event: self._compact_copy_tooltip_text(text_provider))

    def _compact_schedule_tooltip(self, widget, text_provider):
        self._compact_hide_tooltip()
        def show():
            self._compact_tooltip_job = None
            if not self._compact_active or not widget.winfo_exists():
                return
            message = str(text_provider()).strip()
            if not message:
                return
            popup = tk.Toplevel(self.root)
            popup.withdraw()
            popup.overrideredirect(True)
            popup.configure(bg=BLACK)
            tk.Label(popup, text=message, bg=BLACK, fg=WHITE,
                     font=('Segoe UI', 9), justify='left',
                     wraplength=min(420, max(230, self.root.winfo_screenwidth() - 50)),
                     padx=9, pady=7).pack()
            popup.update_idletasks()
            x = min(widget.winfo_rootx(),
                    max(0, self.root.winfo_screenwidth() - popup.winfo_reqwidth() - 6))
            y = widget.winfo_rooty() + widget.winfo_height() + 3
            if y + popup.winfo_reqheight() > self.root.winfo_screenheight():
                y = max(0, widget.winfo_rooty() - popup.winfo_reqheight() - 3)
            popup.geometry(f'+{x}+{y}')
            popup.deiconify()
            self._compact_tooltip_window = popup
        self._compact_tooltip_job = self.root.after(450, show)

    def _compact_hide_tooltip(self):
        pending = self._compact_tooltip_job
        self._compact_tooltip_job = None
        if pending is not None:
            try:
                self.root.after_cancel(pending)
            except tk.TclError:
                pass
        popup = self._compact_tooltip_window
        self._compact_tooltip_window = None
        if popup is not None:
            try:
                popup.destroy()
            except tk.TclError:
                pass

    def _compact_copy_tooltip_text(self, provider):
        text = str(provider())
        if text:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)

    @staticmethod
    def _compact_thumbnail_bounds(width, height):
        """Available image pixels, quantized to avoid decoding on every resize tick."""
        # Canvas already has its own padding. Leave a small safety margin.
        w = max(0, int(width) - 6)
        h = max(0, int(height) - 6)
        if w < 24 or h < 24:
            return None
        return max(8, w // 8 * 8), max(8, h // 8 * 8)

    def _compact_preview_resized(self, event=None):
        # Keep old thumbnail centered without decoding it again while the user
        # drags the window; decode at most once after the resize settles.
        if self._compact_preview_canvas_item is not None:
            canvas = self.compact_preview_canvas
            canvas.coords(self._compact_preview_canvas_item,
                          canvas.winfo_width() // 2, canvas.winfo_height() // 2)
        if self._compact_resize_job is not None:
            try:
                self.root.after_cancel(self._compact_resize_job)
            except tk.TclError:
                pass
        self._compact_resize_job = self.root.after(90, self._compact_redraw_after_resize)

    def _compact_redraw_after_resize(self):
        self._compact_resize_job = None
        if self._compact_active:
            self._compact_refresh_output()

    def _paint_compact_dropzone(self):
        canvas = getattr(self, 'compact_drop_canvas', None)
        if canvas is None:
            return
        canvas.delete('all')
        width = max(230, canvas.winfo_width())
        height = max(105, canvas.winfo_height())
        canvas.create_rectangle(4, 4, width - 4, height - 4, outline=BLACK,
                                width=2, dash=(5, 4), fill=WHITE)
        canvas.create_text(width / 2, height / 2 - 20, text='↓',
                           font=('Segoe UI Semibold', 23), fill=INK)
        canvas.create_text(width / 2, height / 2 + 15,
                           text=('Kéo thả chưa sẵn sàng' if self._compact_dnd_error
                                 else 'Kéo thả ảnh vào đây'), font=MED,
                           fill=INK)
        if self.processing:
            canvas.create_text(width / 2, height - 14,
                               text='Đang xử lý…', fill=MUTED, font=('Segoe UI', 9))

    def paint_dropzone(self):
        self._paint_workspace_dropzone()
        if getattr(self, '_compact_active', False):
            self._paint_compact_dropzone()

    def _compact_select_next(self):
        """Portrait arrow means the immediate next image, not 'next pending'."""
        if not self.items:
            return
        index = self.selected_index if self.selected_index is not None else -1
        self.select_by_index((index + 1) % len(self.items))

    def _compact_toggle_pin(self):
        pinned = not self._compact_pin.get()
        self._compact_pin.set(pinned)
        try:
            self.root.attributes('-topmost', pinned)
        except tk.TclError:
            self._compact_pin.set(False)
        self.compact_pin_btn.configure(
            bg=SOFT if self._compact_pin.get() else WHITE,
            activebackground=SOFT if self._compact_pin.get() else WHITE,
            relief='sunken' if self._compact_pin.get() else 'flat',
            highlightbackground=BLACK if self._compact_pin.get() else BORDER,
            highlightthickness=2 if self._compact_pin.get() else 1)
        self.compact_pin_btn.tooltip_description = (
            'Bỏ ghim cửa sổ' if self._compact_pin.get() else 'Ghim cửa sổ luôn ở trên')
        self._compact_schedule_dnd_registration()

    def _compact_capture_normal_geometry(self):
        if self._compact_active or self._compact_switching:
            return
        try:
            if (self.root.state() == 'normal' and
                    self.root.winfo_width() >= 1040 and self.root.winfo_height() >= 690):
                self._full_window_geometry = self.root.geometry()
        except tk.TclError:
            pass

    def _compact_window_state_changed(self, event):
        # The native middle caption button emits opposite transitions in the
        # two modes: normal -> zoomed for quick workspace, and zoomed ->
        # normal when restoring the maximized desktop. Ignore minimize.
        if event.widget is not self.root or getattr(self, '_closing', False):
            return
        try:
            state = self.root.state()
        except tk.TclError:
            return
        previous = getattr(self, '_compact_last_window_state', 'normal')
        self._compact_last_window_state = state
        if self._compact_switching:
            return
        if state == 'iconic':
            self._compact_minimized = True
            return
        if getattr(self, '_compact_minimized', False):
            # Reopening via the taskbar after minimizing is not a click on
            # the caption's middle button. Preserve whichever mode was open.
            self._compact_minimized = False
            return

        if state == 'zoomed':
            # A transition into zoomed means the user clicked the middle
            # button in compact mode (or initially maximized a normal window).
            # Configure events while already maximized must not toggle modes.
            if self._compact_active or previous != 'zoomed':
                self._compact_schedule_caption_switch('desktop' if self._compact_active else 'compact')
        elif state == 'normal' and not self._compact_active:
            if previous == 'zoomed':
                # On Windows the same button restores a maximized desktop to
                # 'normal'. That action means enter Quick Workspace, not leave
                # a medium-sized desktop window visible.
                self._compact_schedule_caption_switch('compact')
            elif self.root.winfo_width() >= 1040 and self.root.winfo_height() >= 690:
                self._full_window_geometry = self.root.geometry()
        # 'iconic' is the left (–) button: keep native minimize behavior.

    def _compact_schedule_caption_switch(self, target):
        if self._compact_toggle_job is not None:
            return
        self._compact_caption_target = target
        self._compact_toggle_job = self.root.after_idle(self._compact_switch_from_caption)

    def _compact_switch_from_caption(self):
        self._compact_toggle_job = None
        target = getattr(self, '_compact_caption_target', None)
        self._compact_caption_target = None
        if self._compact_switching or self._closing:
            return
        try:
            state = self.root.state()
            if target == 'desktop' and self._compact_active and state == 'zoomed':
                self._compact_exit()
            elif target == 'compact' and not self._compact_active and state in ('normal', 'zoomed'):
                self._compact_enter()
        except tk.TclError:
            return

    def _compact_enter(self):
        if self._compact_active:
            return
        if getattr(self, '_gallery_batch_running', False):
            # Switching during an active batch could cause confusing updates.
            self.root.state('normal')
            return
        if self.root.state() == 'normal':
            self._compact_capture_normal_geometry()
        self._compact_switching = True
        try:
            self.root.state('normal')
            self.root.minsize(310, 520)
            self._desktop_shell.pack_forget()
            self.compact_host.pack(fill='both', expand=True)
            self._compact_active = True
            self._compact_schedule_dnd_registration()
            height = min(690, max(540, self.root.winfo_screenheight() - 100))
            # Preserve the window's position where possible; never place
            # its compact layout completely outside the screen.
            x = min(max(0, self.root.winfo_x()), max(0, self.root.winfo_screenwidth() - 340))
            y = min(max(0, self.root.winfo_y()), max(0, self.root.winfo_screenheight() - height - 35))
            self.root.geometry(f'340x{height}+{x}+{y}')
            if self.selected_index is None and self.items:
                self.select_by_index(0)
            self._compact_update_name()
            self._compact_refresh_output(force=True)
            self._compact_last_window_state = 'normal'
        finally:
            self.root.after(100, self._compact_release_switch)

    def _compact_exit(self):
        if not self._compact_active:
            return
        self._compact_switching = True
        try:
            self.root.state('normal')
            # Pin belongs to the quick window only: never leave the full
            # application unintentionally always-on-top with no pin control.
            if self._compact_pin.get():
                self._compact_pin.set(False)
                try:
                    self.root.attributes('-topmost', False)
                except tk.TclError:
                    pass
                self.compact_pin_btn.configure(bg=WHITE, relief='flat')
            self._compact_hide_tooltip()
            if getattr(self, '_compact_dnd_job', None) is not None:
                self.root.after_cancel(self._compact_dnd_job)
                self._compact_dnd_job = None
            if self._compact_resize_job is not None:
                self.root.after_cancel(self._compact_resize_job)
                self._compact_resize_job = None
            self.compact_host.pack_forget()
            self._desktop_shell.pack(fill='both', expand=True)
            self._compact_active = False
            self._compact_photo = None
            self._compact_preview_key = None
            self._compact_preview_canvas_item = None
            self.compact_preview_canvas.delete('all')
            self.root.minsize(1040, 690)
            self.root.geometry(self._full_window_geometry)
            # Restore the *maximized* desktop, not its old medium-size rectangle.
            # Use Windows' native zoomed state so the title bar and taskbar
            # remain available, including the same middle toggle button.
            try:
                self.root.state('zoomed')
            except tk.TclError:
                # Tk/X11 represents native maximize as a WM attribute, while
                # Windows supports 'zoomed' directly. Keep Linux test hosts
                # usable without changing the Windows behavior.
                self.root.attributes('-zoomed', True)
            self._compact_last_window_state = 'zoomed'
        finally:
            self.root.after(100, self._compact_release_switch)

    def _compact_release_switch(self):
        try:
            self._compact_last_window_state = self.root.state()
        except tk.TclError:
            pass
        self._compact_switching = False

    def _compact_update_name(self):
        if not hasattr(self, 'compact_name_label'):
            return
        selected = self.selected_index
        if selected is None or not (0 <= selected < len(self.items)):
            full = 'Chưa chọn tên ảnh'
        else:
            from imageflow_core import OUTPUT_FORMATS
            suffix = OUTPUT_FORMATS.get(self.output_format.get(), OUTPUT_FORMATS['png'])[0]
            full = self.items[selected].name + suffix
        self._compact_full_name = full
        self._compact_name_resized()

    def _compact_show_preview_message(self, message):
        canvas = self.compact_preview_canvas
        canvas.delete('all')
        self._compact_preview_canvas_item = None
        self._compact_photo = None
        canvas.create_text(max(1, canvas.winfo_width()) // 2,
                           max(1, canvas.winfo_height()) // 2,
                           text=message, fill=MUTED, font=F,
                           width=max(0, canvas.winfo_width() - 10))

    def _compact_refresh_output(self, *, force=False):
        if not getattr(self, '_compact_active', False):
            return
        from output_preview import resolve_selected_output, preview_identity
        selected = self.items[self.selected_index] if (self.selected_index is not None and
                    0 <= self.selected_index < len(self.items)) else None
        current = resolve_selected_output(self._folder_snapshot,
                       self.destination.get().strip(), self.items, self.selected_index,
                       self.output_format.get())
        key = preview_identity(self.project_store.active_id, current) if current else (
            self.project_store.active_id, selected.name if selected else None,
            selected.state if selected else None, self.destination.get().strip())
        canvas = self.compact_preview_canvas
        if hasattr(self, 'compact_delete_btn'):
            self.compact_delete_btn.configure(
                state='normal' if current is not None and not self.processing and
                      not getattr(self, '_gallery_batch_running', False) else 'disabled')
        available = self._compact_thumbnail_bounds(canvas.winfo_width(), canvas.winfo_height())
        redraw_key = (key, available)
        if redraw_key == self._compact_preview_key and not force:
            # Moving inside one size bucket only requires re-centering the image.
            return
        self._compact_preview_key = redraw_key
        if current is None:
            self._compact_show_preview_message(
                'Ảnh bị lỗi' if selected is not None and selected.state == 'corrupt' else 'Chưa có ảnh')
            self._compact_set_detail(
                'Ảnh bị lỗi hoặc chưa ghi xong' if selected is not None and selected.state == 'corrupt'
                else 'Chưa có ảnh đầu ra trong thư mục project')
            return
        if available is None:
            # Very small/unmapped area: do not create an image larger than the
            # canvas, and let the next Configure event do the real rendering.
            self._compact_show_preview_message('')
            self._compact_set_detail(current.path.name)
            return
        try:
            photo, dimensions = self._cached_thumbnail(current.path, available, icon_file=current)
        except (OSError, ValueError):
            self._compact_show_preview_message('Không đọc được ảnh')
            self._compact_set_detail('File đang được ghi hoặc không hợp lệ')
            return
        self._compact_photo = photo
        canvas.delete('all')
        self._compact_preview_canvas_item = canvas.create_image(
            canvas.winfo_width() // 2, canvas.winfo_height() // 2,
            anchor='center', image=photo)
        self._compact_set_detail(f'{current.path.name}  ·  {dimensions[0]} × {dimensions[1]} px')

    def _refresh_target(self):
        self._refresh_workspace_target()
        self._compact_update_name()
        self._compact_refresh_output()

    def _update_empty_selection(self):
        self._update_workspace_empty_selection()
        self._compact_update_name()
        self._compact_refresh_output()

    def _refresh_selected_output_preview(self):
        self._refresh_workspace_output_preview()
        self._compact_refresh_output()
