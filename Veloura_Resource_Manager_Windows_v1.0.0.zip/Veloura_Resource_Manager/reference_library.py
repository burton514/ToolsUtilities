"""Project-local reference selections and compositing, independent of the UI.

Reference files are never deleted. A project stores paths, while per-icon
assignments store a subset of paths; missing paths are safely ignored.
"""
from __future__ import annotations
from pathlib import Path
from PIL import Image, ImageOps


def unique_paths(paths):
    result = []
    seen = set()
    for raw in paths or []:
        if not isinstance(raw, str) or not raw.strip():
            continue
        value = str(Path(raw.strip()).expanduser())
        key = value.replace('\\', '/').casefold()
        if key not in seen:
            seen.add(key)
            result.append(value)
    return result


def enabled_references(library, assignments, icon_name):
    library = unique_paths(library)
    specified = (assignments or {}).get(icon_name)
    if not isinstance(specified, list):
        return library.copy()  # New icons use all project references by default.
    selected = set(unique_paths(specified))
    return [p for p in library if p in selected]


def set_reference_selection(library, assignments, icon_name, path, selected):
    library = unique_paths(library)
    if path not in library:
        raise ValueError('Ảnh mẫu không thuộc project hiện tại.')
    updated = dict(assignments or {})
    current = enabled_references(library, updated, icon_name)
    if selected and path not in current:
        current.append(path)
    elif not selected:
        current = [p for p in current if p != path]
    updated[icon_name] = current
    return updated


def remove_reference(library, assignments, path):
    paths = [p for p in unique_paths(library) if p != path]
    mapping = {k: [p for p in unique_paths(v) if p in paths]
               for k, v in (assignments or {}).items() if isinstance(v, list)}
    return paths, mapping


def contact_sheet(paths, tile=480, margin=20):
    """Merge selected reference images into a single transparent image to paste.

    Windows' image clipboard stores one bitmap, so a grid is used when there
    are multiple selected references. Never modify original reference images.
    """
    from math import ceil, sqrt
    files = [Path(p) for p in unique_paths(paths) if Path(p).is_file()]
    if not files:
        raise ValueError('Không có ảnh mẫu hợp lệ để sao chép.')
    if len(files) == 1:
        with Image.open(files[0]) as pic:
            return ImageOps.exif_transpose(pic).convert('RGBA').copy()
    columns = min(3, ceil(sqrt(len(files))))
    rows = ceil(len(files) / columns)
    cell = tile + margin * 2
    result = Image.new('RGBA', (columns * cell, rows * cell), (255, 255, 255, 0))
    for i, path in enumerate(files):
        with Image.open(path) as pic:
            img = ImageOps.exif_transpose(pic).convert('RGBA')
            img.thumbnail((tile, tile), Image.Resampling.LANCZOS)
            x = (i % columns) * cell + (cell - img.width) // 2
            y = (i // columns) * cell + (cell - img.height) // 2
            result.alpha_composite(img, (x, y))
    return result
