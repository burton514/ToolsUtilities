# Veloura Resource Manager v1.0.0

Ứng dụng Windows quản lý ảnh theo từng project, hỗ trợ xuất PNG, JPG, WebP, BMP và TIFF. Mỗi project có tên, mô tả, file Excel/CSV và thư mục lưu riêng. Ứng dụng hỗ trợ Prompt, nhiều ảnh mẫu, Copy/Move, resize, dán ảnh từ clipboard, Gallery và theo dõi ảnh đầu ra trực tiếp từ folder theo thời gian gần thực.

## Khởi động trên Windows

**Cài ứng dụng và MCP EXE ra Desktop (đề xuất):**

1. Giải nén toàn bộ ZIP vào một thư mục trên Windows.
2. Nhấp đúp **`CAI_EXE_RA_DESKTOP.cmd`**. Lần đầu cần Internet để cài Python, thư viện và PyInstaller phục vụ **đóng gói**.
3. Khi quá trình kết thúc thành công, Desktop có **`Veloura Resource Manager.exe`** và **`VelouraMCP.exe`**. Từ lần sau chỉ cần mở file này, **không cần Python hoặc chạy CMD**.

**Chỉ tạo EXE để tự sao chép:** chạy `BUILD_EXE_WINDOWS.cmd`, lấy `dist/VelouraResourceManager.exe` (GUI) và `dist/VelouraMCP.exe` (MCP Agent).

**Chạy bản nguồn không build:** mở `START_WINDOWS.cmd` như trước. Cấu hình project vẫn nằm trong `%LOCALAPPDATA%\VelouraImageManager`, không bị xóa hoặc thay đổi khi đóng gói.

**Lưu ý:** PyInstaller phải biên dịch trên **Windows 64-bit**; không thể dùng file build từ Linux/macOS. EXE độc lập có thể mất thêm thời gian khi mở lần đầu vì giải nén thư viện. File EXE chưa được ký số, nên Windows SmartScreen có thể yêu cầu xác minh nhà phát hành.

Giữ nguyên thư mục `assets` và các file `.py` khi chạy bản nguồn hoặc đóng gói lại.

## Chế độ cửa sổ dọc nhỏ gọn (Quick Workspace)

Trên Windows, nhấp **nút □ ở giữa thanh tiêu đề** (Phóng to/Khôi phục) để chuyển giữa giao diện đầy đủ và một **cửa sổ dọc nhỏ gọn**. Đây **không phải nút –** (Thu nhỏ xuống thanh tác vụ); nút – vẫn hoạt động như bình thường.

- Đầu cửa sổ dọc có **mũi tên Trước / Tiếp theo chỉ bằng biểu tượng**, dùng để chuyển đúng một ảnh trong danh sách theo thứ tự. Tên ảnh đích hiển thị ngay bên dưới, với nút **sao chép Prompt** (chỉ icon) ở bên phải tên. Nút dùng cùng nội dung Prompt và mẫu Prompt đang bật của Workspace; nếu không có nội dung thì thông báo rõ ràng.
- Khu vực **Ảnh đầu vào** cho phép chọn ảnh, kéo/thả **file ảnh từ File Explorer** hoặc dán ảnh (`Ctrl+V`) như Workspace thông thường. Việc đăng ký kéo thả được thực hiện sau khi cửa sổ dọc hiển thị, và được làm mới khi bật/tắt ghim. Nếu kéo ảnh trực tiếp từ trình duyệt chỉ trả về liên kết, hãy sao chép ảnh và dán (`Ctrl+V`) hoặc tải file về rồi kéo thả. Tùy chọn lưu, định dạng, resize và xử lý trùng tên vẫn lấy từ project hiện tại.
- Bên dưới là **Ảnh đầu ra**, có nút **Xóa ảnh** để xóa file đầu ra đang hiển thị sau khi xác nhận (không xóa dòng tên hoặc Prompt trong Excel/CSV); đọc chính file có thật trong thư mục project. Ảnh tự co vừa vùng xem ở cửa sổ thấp (tối thiểu 310 × 520 px) và luôn giữ tỷ lệ, có dòng thông tin phía dưới; không tạo cache xuống ổ đĩa. Tên ảnh dài được rút gọn trên một dòng bằng `…`; rê chuột lên tên hoặc thông tin đầu ra để xem đầy đủ, nhấp chuột phải để sao chép.
- Nút **biểu tượng ghim** ở góc trên bên phải bật/tắt **Luôn ở trên cùng** (`topmost`) để sử dụng cùng cửa sổ Image Gen. Khi bật, nút có nền/viền nổi bật; rê chuột để xem chú thích.
- Nhấn lại **nút □ ở giữa thanh tiêu đề** để quay về giao diện đầy đủ, giữ nguyên project, dòng đang chọn và kích thước cửa sổ chính trước đó.
- Chế độ dọc không làm thay đổi dữ liệu project hoặc vị trí lưu ảnh. Nếu máy không hỗ trợ thông báo `zoomed` của trình quản lý cửa sổ (ví dụ một số môi trường Linux), không thể bảo đảm thao tác qua nút □ như Windows.

## Agent trên cùng máy Windows (MCP cục bộ)

**Kết nối Agent cục bộ:** Sau khi build, dùng `VelouraMCP.exe` để kết nối Codex, Claude Desktop hoặc Agent hỗ trợ MCP qua stdio. MCP chạy theo yêu cầu, không cần GUI mở, không mở cổng mạng và không yêu cầu API key. Không dùng EXE giao diện (`--windowed`) làm MCP Server. Sau khi chạy `CAI_EXE_RA_DESKTOP.cmd` hoặc `BUILD_EXE_WINDOWS.cmd`, bộ build tạo hai file cấu hình có sẵn đường dẫn EXE trong thư mục `dist/`: `Veloura_MCP_Claude_Config.json` và `Veloura_MCP_Codex_Config.toml`.

Ví dụ cấu hình Claude Desktop (thay bằng đường dẫn thực trên máy Windows):

```json
{
  "mcpServers": {
    "veloura": {
      "command": "C:\\Users\\<user>\\Desktop\\VelouraMCP.exe",
      "args": []
    }
  }
}
```

Ví dụ cấu hình Codex:

```toml
[mcp_servers.veloura]
command = "C:\\Users\\<user>\\Desktop\\VelouraMCP.exe"
```

Nếu Agent đã có MCP Server khác, chỉ thêm mục `veloura` vào cấu hình hiện tại. Với bản mã nguồn, có thể dùng `RUN_MCP_WINDOWS.cmd` (qua `cmd.exe /d /c` nếu cần) hoặc `.venv\Scripts\python.exe -u mcp_stdio.py` với đường dẫn tuyệt đối; không dùng `pythonw.exe`.

**18 công cụ MCP hiện có** (giữ nguyên tên định danh để tương thích Agent đã kết nối):

| Nhóm | Công cụ | Công dụng |
|---|---|---|
| Project | `veloura_list_projects`, `veloura_select_project`, `veloura_get_project` | Liệt kê, chọn ngữ cảnh Agent, xem cấu hình |
| Project | `veloura_create_project`, `veloura_update_project`, `veloura_delete_project` | Tạo, sửa, xóa cấu hình project |
| Nguồn Excel/CSV | `veloura_get_source_columns`, `veloura_set_source_columns` | Xem và chọn cột tên Image Gen, Prompt và sheet |
| Image Gen | `veloura_list_icons`, `veloura_get_icon` | Tìm kiếm, lọc, xem trạng thái và Prompt |
| Ảnh mẫu | `veloura_list_references`, `veloura_add_reference`, `veloura_assign_reference` | Quản lý ảnh mẫu theo project/mục Image Gen |
| Ảnh đầu ra | `veloura_scan_project`, `veloura_set_review`, `veloura_view_image` | Quét ảnh thật, đánh dấu Cần xem xét và trả ảnh cho Agent |
| Nhập/xử lý | `veloura_import_image`, `veloura_rename_png` | Nhập, resize, đổi định dạng và đổi tên file ảnh |

**An toàn dữ liệu:** các thao tác ghi phải có `project_id` hợp lệ; `overwrite` và `move` mặc định đều là `false`. Xóa project chỉ xóa cấu hình khi có `confirm=true`, không xóa file ảnh. Agent chọn project trong phiên của mình, không tự chuyển project đang mở trong GUI. GUI và Agent dùng chung Core Service, có khóa phối hợp khi ghi; trạng thái ảnh lấy trực tiếp từ file thực tế. Không có HTTP Server hoặc kết nối Internet do MCP tự tạo; tuy nhiên dữ liệu Agent đọc có thể được xử lý theo chính sách của ứng dụng AI mà bạn sử dụng. Chỉ kết nối Agent đáng tin cậy.

Khi nhập qua `veloura_import_image`, có thể chọn `output_format` là `png`, `jpg`, `webp`, `bmp` hoặc `tiff`; nếu bỏ qua sẽ sử dụng định dạng của project. `veloura_update_project` cũng hỗ trợ chỉnh định dạng mặc định. Hãy khởi động lại/tải lại MCP Server trong Agent sau khi cập nhật EXE.


## Quy trình làm việc

1. Trong **Dự án**, tạo hoặc chọn project. Điền tên, mô tả (có thể trống), dùng nút **Chọn file...** để chọn `.xlsx`, `.xlsm`, `.csv` và **Chọn thư mục...** để chọn nơi lưu ảnh.
2. Trong **Làm việc**, chọn Sheet, **Cột tên Image Gen** và **Cột Prompt**. Các ô chọn này hiển thị trực tiếp trong panel trái.
3. Chọn tên Image Gen trong danh sách, sao chép Prompt và ảnh mẫu phù hợp (nếu cần).
4. Chọn ảnh bằng nút **Chọn ảnh** ở khung Ảnh đầu vào, kéo thả ảnh hoặc nhấn `Ctrl+V` để dán ảnh từ clipboard. Công cụ lưu đúng tên và định dạng đã chọn trong **Định dạng xuất**, áp dụng Copy/Move và resize theo cấu hình.
5. Mở **Thư viện ảnh** (Gallery) để xem thumbnail, lọc trạng thái và tìm Image Gen. Trạng thái **Cần xem xét** được đánh dấu thủ công, chỉ dùng cho ảnh đầu ra hợp lệ.

Ứng dụng đọc ảnh đầu ra **trực tiếp từ thư mục project**, không tạo bản sao hoặc thư mục cache ảnh trên ổ đĩa. Trên Windows, ứng dụng ưu tiên **thông báo thay đổi của hệ điều hành** thay vì quét folder liên tục. Lúc có sự kiện, chương trình kiểm tra metadata và dấu vân tay byte của file ảnh để nhận ra cả trường hợp file bị ghi đè nhưng kích thước/thời gian sửa không đổi; **ảnh có nội dung không thay đổi không bị giải mã lại**. Cơ chế sự kiện không cung cấp tên file nên có thể cần đọc nội dung ảnh trong folder sau mỗi sự kiện để đối chiếu, không tạo cache ảnh trên ổ đĩa. Chương trình tự quét bù metadata mỗi 45 giây để phát hiện thay đổi bị bỏ lỡ và chuyển sang quét thưa (2,5 giây) khi không có thông báo. **Nhấn F5** sẽ kiểm tra lại cả nội dung ảnh, bao gồm trường hợp metadata không đổi. Ảnh `.veloura_*` đang lưu tạm không xuất hiện trong Gallery.

Thumbnail chỉ được giữ tạm trong RAM (tối đa 48 bản), tự loại khi file đổi/xóa và được giải phóng khi chuyển project. Excel/CSV tự nạp lại sau khi file nguồn thay đổi và ổn định, trừ lúc bạn đang chỉnh sửa hay app đang xử lý. Khi thư mục output không truy cập được, ứng dụng giữ nguyên dấu **Cần xem xét** đã lưu; chỉ gỡ dấu khi thư mục truy cập lại được và ảnh thực sự không còn/hỏng.

## Các màn hình

- **Dự án:** tạo, sửa, chọn hoặc xóa cấu hình project; xóa cấu hình không xóa ảnh đầu ra trên đĩa.
- **Làm việc:** tên Image Gen, Prompt, nhiều ảnh mẫu, ảnh đầu vào/đầu ra và cài đặt xuất ảnh.
- **Thư viện ảnh:** Gallery thumbnail, tìm kiếm, lọc, xem nhanh và điều hướng về Workspace. Khi đánh dấu hoặc bỏ dấu **Cần xem xét**, ứng dụng chỉ cập nhật nhãn trạng thái trên thẻ ảnh, không tạo lại các thẻ không đổi hay làm mất vị trí cuộn; bộ lọc Cần xem xét chỉ thêm/bớt và sắp xếp các thẻ liên quan. Mỗi thẻ đã có ảnh hợp lệ có nút **Xóa** cạnh **Đi tới** và **Mở**: ứng dụng hỏi xác nhận trước khi xóa vĩnh viễn đúng file đang hiển thị trong thư mục của project. Dòng tên và Prompt trong Excel/CSV không bị xóa, Gallery cập nhật đúng thẻ mà không tải lại cả lưới. Nếu file vừa thay đổi từ bên ngoài, ứng dụng từ chối xóa file cũ và yêu cầu làm mới.
- **Tiến độ:** tổng quan số Image Gen và tình trạng file.
- **Ảnh mẫu / Mẫu Prompt:** quản lý tài nguyên tham chiếu và Prompt theo project.
- **Lịch sử / Cài đặt:** xem và quản lý hoạt động trong phiên của project hiện tại. Màn Lịch sử có **Làm mới**, **Xóa nhật ký** (có xác nhận) và **Xuất CSV**. Xóa nhật ký chỉ xóa bản ghi trong RAM của project đang chọn, không xóa ảnh, bảng Excel/CSV, ảnh mẫu hay cấu hình. Lịch sử trong RAM được giới hạn 300 bản ghi mỗi project; vùng nhật ký nhanh tại Workspace cũng được giữ gọn. Nhật ký hoạt động trong UI không phải file báo cáo đi kèm project nguồn.

### Chọn nhiều ảnh và xử lý hàng loạt trong Thư viện ảnh

- **Chọn một hoặc nhiều:** bấm vào ảnh/thẻ hoặc dòng **☐ Chọn**. Thẻ được chọn có **nền xám và viền đen**, không dựng lại toàn bộ lưới. Lặp lại để bỏ chọn.
- **Chọn tất cả:** chọn mọi file ảnh hợp lệ khớp bộ lọc/từ khóa hiện tại, **trên toàn bộ các trang**. Các tên chưa có file sẽ không được chọn. **Bỏ chọn** xóa lựa chọn trong RAM, không xóa ảnh.
- **Resize:** nhập rộng × cao (1–16384 px, tối đa 80 triệu px), chọn Giữ tỷ lệ / Phủ đầy khung / Kéo giãn. Chương trình **xác nhận trước khi ghi đè file gốc**, giữ nguyên định dạng và tên file gốc (cả `.jpeg` và `.tif`).
- **Đổi định dạng:** chọn PNG, JPG, WebP, BMP hoặc TIFF. Mặc định **giữ nguyên file gốc**, tạo file mới và **bỏ qua đích trùng tên**. Có tùy chọn ghi đè đích hoặc xóa file gốc **chỉ sau khi chuyển đổi thành công**, đều được xác nhận trước. JPG/BMP chuyển vùng trong suốt sang nền trắng. Trong Gallery có thể tồn tại hai file cùng tên khác đuôi; Gallery ưu tiên định dạng xuất đã chọn ở Workspace.
- Hai thao tác chạy tuần tự trên luồng xử lý riêng; hộp thoại kết quả cho biết số thành công, bỏ qua và lỗi. File ảnh được đọc/ghi **trực tiếp trong folder** bằng lưu tạm và thay thế nguyên tử; **không sinh cache ảnh trên đĩa**. Nếu file bị thay đổi sau khi được chọn, thao tác đó bị từ chối để tránh ghi nhầm.
- Khi một lượt xử lý hàng loạt đang chạy, không chuyển project hoặc đóng ứng dụng để tránh gián đoạn; khi hoàn tất Gallery chỉ cập nhật các thẻ đã đổi và giữ vị trí cuộn.

## Phím tắt

| Phím | Tác vụ |
|---|---|
| `Ctrl+E` | Mở Excel/CSV |
| `Ctrl+Shift+V` | Dán đường dẫn Excel/CSV |
| `Ctrl+V` | Dán ảnh clipboard vào Image Gen đang chọn |
| `Ctrl+O`, `Ctrl+S` | Mở hộp chọn ảnh đầu vào (phím tắt vẫn hoạt động) |
| `Ctrl+Enter` | Chuyển sang tên tiếp theo |
| `Ctrl+Shift+C` | Sao chép Prompt |
| `Ctrl+Shift+I` | Sao chép ảnh mẫu |
| `F5` | Quét lại thư mục ảnh đầu ra |

## Cấu hình và tài nguyên

- **Cấu hình người dùng:** `%LOCALAPPDATA%\VelouraImageManager\settings.json` và `projects.json` (có cơ chế sao lưu registry project).
- **Mã nguồn:** `app.py` và `mcp_stdio.py` là các điểm vào giữ tương thích; màn hình và controller tách theo chức năng trong `veloura/gui/`, `veloura/controllers/`. Các module nghiệp vụ/lưu trữ như `core_service.py`, `imageflow_core.py`, `project_store.py`, `folder_live.py` vẫn giữ đường dẫn import cũ để không ảnh hưởng Agent và dữ liệu hiện tại.
- **Biểu tượng giao diện:** `assets/mono/`, `assets/veloura_icon.ico`; `assets/mono/ICON_MANIFEST.csv` mô tả tên asset.
- **Thư viện:** `requirements.txt`; file khởi động/build nằm ở thư mục gốc.
- **Kiểm thử:** `tests/`; file Excel dùng trong test nằm tại `tests/fixtures/`, không phải dữ liệu project thật.

Chức năng tạo ảnh, clipboard và DPI nên được xác nhận thêm trên máy Windows thực tế. Không thay đổi hay xóa dữ liệu người dùng trong thư mục project khi cập nhật ứng dụng.


## Chuyển đổi định dạng ảnh

Trong **Làm việc với Image Gen → Thiết lập xuất ảnh**, chọn **Định dạng xuất**: PNG (mặc định), JPG, WebP, BMP hoặc TIFF. Khi lưu, ứng dụng mã hóa ảnh theo định dạng thật, không chỉ đổi phần mở rộng. JPEG và BMP không hỗ trợ kênh alpha: vùng trong suốt được ghép lên nền trắng. PNG, WebP và TIFF có thể giữ alpha. Chế độ resize và Copy/Move tiếp tục hoạt động như trước.

Nếu cùng tên có nhiều định dạng (ví dụ `demo.png` và `demo.webp`), đây là hai file độc lập; xuất định dạng mới không tự xóa bản cũ. Gallery ưu tiên định dạng đang chọn, sau đó chọn PNG hay định dạng khác đang tồn tại. **Xóa** chỉ xóa đúng file được hiển thị sau xác nhận. MCP cho phép `output_format` khi cập nhật project hoặc nhập ảnh; mặc định theo project.


## Cấu trúc mã nguồn (dành cho bảo trì và mở rộng)

Cấu trúc được phân nhóm theo **trách nhiệm**, thay vì tập trung mọi màn hình và tác vụ vào hai file lớn:

```text
Veloura_Resource_Manager/
├── app.py                   # Entry GUI + khởi tạo trạng thái + tương thích API cũ
├── modern_ui.py             # Shell, thanh điều hướng, widget dùng chung
├── compact_view.py          # Cửa sổ dọc và chế độ ghim
├── mcp_stdio.py             # Entry MCP/18 công cụ, giao tiếp stdio
├── app_version.py           # Phiên bản phát hành chung
├── veloura/
│   ├── gui/
│   │   ├── theme.py         # Bảng màu/kiểu chữ (nguồn duy nhất)
│   │   ├── widgets.py       # Widget Tk dùng chung
│   │   ├── dialog_theme.py  # Màu/tài nguyên của hộp thoại project
│   │   ├── workspace.py     # Workspace: input, output, Prompt, ảnh mẫu
│   │   ├── gallery.py       # Gallery: thẻ ảnh, chọn nhiều, thao tác batch
│   │   ├── projects.py      # Màn quản lý project
│   │   └── other_pages.py   # Tiến độ, Cài đặt, Lịch sử, Giới thiệu
│   └── controllers/
│       ├── projects.py      # Quản lý dữ liệu và thao tác project
│       ├── source.py        # Excel/CSV và danh sách công việc
│       ├── folder.py        # Theo dõi folder, trạng thái, Cần xem xét
│       ├── images.py        # Ảnh nhập/xuất, Prompt và ảnh mẫu
│       ├── activity.py      # Vòng xử lý event, lịch sử, đóng ứng dụng
│       └── options.py       # Nhãn và mã của các lựa chọn xuất ảnh
├── core_service.py         # Nghiệp vụ dùng bởi MCP
├── imageflow_core.py       # Đọc nguồn và xử lý ảnh
├── folder_live.py          # Windows watcher + đối chiếu folder
├── project_store.py        # Cấu hình project và phối hợp ghi
├── gallery_batch.py        # Xử lý ảnh hàng loạt
├── assets/                  # Tài nguyên UI; không lưu cache ảnh
└── tests/                   # Regression/integration test
```

**Quy tắc mở rộng:** UI gọi controller và các dịch vụ nghiệp vụ; controller không import ngược `app.py`/`modern_ui.py` để tránh vòng phụ thuộc. Mỗi màn hình mới nên nằm trong `veloura/gui/`, mỗi quy trình độc lập nằm trong controller hoặc module xử lý tương ứng. Các chức năng được **ánh xạ tường minh** trong `ImageManager`, `MonoUI` và `ModernResourceManager`: xem tên phương thức là biết module sở hữu, không dùng `import *` hay chuỗi đa kế thừa. Chỉ có `ModernResourceManager(ImageManager)` là quan hệ kế thừa chính; các lớp feature chứa hàm và không cần tự kế thừa. Năm callback UI bọc các thao tác nền sử dụng tên delegate cụ thể (ví dụ `_persist_controller_settings`, `_refresh_workspace_target`) thay vì dựa vào thứ tự `super()`.

Để phát triển tính năng mới, thêm phương thức vào module đúng trách nhiệm và khai báo rõ ánh xạ tại lớp điều phối tương ứng. Không di chuyển nghiệp vụ ảnh sang `modern_ui.py`, không thêm cache ảnh trên ổ đĩa và giữ nguyên các tên công cụ MCP.

**Tương thích:** Không đổi nội dung `projects.json`/`settings.json`, không đổi tên công cụ MCP, `project_id`, cột dữ liệu cũ, đường dẫn nguồn/đích hay logic Folder-First. Các script Windows vẫn dùng `app.py` và `mcp_stdio.py`. Chỉ giữ README là tài liệu chính; không tạo changelog hay file báo cáo trong project.

**Kiểm thử:** Tại thư mục project, chạy `python -m pytest -q` sau khi cài các dependencies trong `requirements.txt` và pytest. Hai file EXE được build trên Windows bằng `CAI_EXE_RA_DESKTOP.cmd`.
