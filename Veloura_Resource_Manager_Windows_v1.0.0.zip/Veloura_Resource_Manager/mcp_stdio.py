"""Local Veloura MCP tools over JSON-RPC 2.0 stdio (no listening port).

Supports the established 2025-11-25 / 2025-06-18 MCP initialization,
notifications/initialized, tools/list, tools/call, and ping. Stdio is reserved
exclusively for protocol JSON; diagnostics go to stderr.
"""
from __future__ import annotations

import json
import sys
import traceback
from dataclasses import dataclass
from typing import Any, Callable

from core_service import CoreService
from app_version import APP_VERSION, MCP_SERVER_NAME


@dataclass(frozen=True)
class Tool:
    description: str
    method: str
    properties: dict
    required: tuple[str, ...] = ()


def field(kind, description: str, **details):
    return {'type': kind, 'description': description, **details}


ID = field('string', 'ID project (bắt buộc cho thao tác ghi); bỏ qua để đọc project đã chọn', minLength=1)
NAME = field('string', 'Tên Image Gen (có thể bỏ đuôi định dạng ảnh)')

TOOLS: dict[str, Tool] = {
    'veloura_list_projects': Tool('Xem danh sách project cục bộ của Veloura.', 'list_projects', {}),
    'veloura_select_project': Tool('Chọn project cho phiên Agent; không chuyển GUI.', 'select_project', {'project_id': ID}, ('project_id',)),
    'veloura_get_project': Tool('Xem cấu hình project và cột Excel/CSV.', 'get_project', {'project_id': ID}),
    'veloura_create_project': Tool('Tạo project; file Excel/CSV và folder phải tồn tại.', 'create_project',
        {'name': field('string','Tên project'), 'description': field('string','Mô tả'),
         'source_file': field('string','Đường dẫn tuyệt đối Excel/CSV'),
         'output_folder': field('string','Thư mục PNG đã tồn tại')}, ('name','source_file','output_folder')),
    'veloura_update_project': Tool('Sửa tên, mô tả, file Excel/CSV hoặc thư mục project.', 'update_project',
        {'project_id': ID, 'name': field('string','Tên mới'), 'description': field('string','Mô tả'),
         'source_file': field('string','Đường dẫn Excel/CSV'), 'output_folder': field('string','Thư mục ảnh'),
         'output_format': field('string','Định dạng xuất mặc định',enum=['png','jpg','webp','bmp','tiff'])}, ('project_id',)),
    'veloura_delete_project': Tool('Chỉ xóa cấu hình project; cần confirm=true, không xóa ảnh vật lý.', 'delete_project',
        {'project_id': ID, 'confirm': field('boolean','Xác nhận xóa cấu hình; không xóa file')}, ('project_id','confirm')),
    'veloura_get_source_columns': Tool('Xem sheet/cột Excel/CSV và gợi ý cột tên, Prompt.', 'get_source_columns', {'project_id': ID}),
    'veloura_set_source_columns': Tool('Cập nhật cột tên, Prompt, sheet của một project.', 'set_source_columns',
        {'project_id': ID, 'name_column': field('integer','Cột tên (1-based)',minimum=1,maximum=150),
         'prompt_column': field('integer','Cột Prompt, 0=không dùng',minimum=0,maximum=150),
         'sheet': field('string','Tên sheet'), 'has_header': field('boolean','Dòng đầu là tiêu đề')}, ('project_id','name_column')),
    'veloura_list_icons': Tool('Danh sách Image Gen theo project; lọc trạng thái và tìm kiếm, có phân trang.', 'list_icons',
        {'project_id': ID, 'status': field('string','all/existing/missing/needs_review/corrupt/invalid_name',enum=['all','existing','missing','needs_review','corrupt','invalid_name']),
         'query': field('string','Chuỗi tìm tên'), 'offset': field('integer','Vị trí bắt đầu',minimum=0),
         'limit': field('integer','Số mục tối đa 500',minimum=1,maximum=500),
         'include_prompt': field('boolean','Có trả Prompt đầy đủ hay không')}),
    'veloura_get_icon': Tool('Xem một mục Image Gen gồm trạng thái, ảnh đầu ra, Prompt và ảnh mẫu tương ứng.', 'get_icon',
        {'project_id': ID, 'name': NAME}, ('name',)),
    'veloura_list_references': Tool('Liệt kê ảnh mẫu của project và lựa chọn theo Image Gen.', 'list_references',
        {'project_id': ID, 'icon_name': NAME}),
    'veloura_add_reference': Tool('Gắn một ảnh mẫu hợp lệ vào thư viện của project.', 'add_reference',
        {'project_id': ID, 'image_path': field('string','Đường dẫn ảnh mẫu trên Windows')}, ('project_id','image_path')),
    'veloura_assign_reference': Tool('Bật/bỏ một ảnh mẫu được sử dụng cho Image Gen.', 'assign_reference',
        {'project_id': ID, 'icon_name': NAME, 'image_path': field('string','Ảnh đã thuộc thư viện project'),
         'selected': field('boolean','Bật/tắt ảnh mẫu')}, ('project_id','icon_name','image_path','selected')),
    'veloura_scan_project': Tool('Thống kê mới nhất từ ảnh trên ổ đĩa, không dùng lịch sử tool.', 'scan_project', {'project_id': ID}),
    'veloura_set_review': Tool('Đánh dấu hoặc bỏ Cần xem xét; bật chỉ khi có PNG hợp lệ.', 'set_review',
        {'project_id': ID, 'icon_name': NAME, 'enabled': field('boolean','true=đánh dấu, false=bỏ đánh dấu')},
        ('project_id','icon_name','enabled')),
    'veloura_view_image': Tool('Xem ảnh đầu ra hoặc ảnh mẫu được chọn dưới dạng hình ảnh MCP.', 'view_image',
        {'project_id': ID, 'icon_name': NAME, 'source': field('string','output/reference',enum=['output','reference']),
         'reference_path': field('string','Ảnh mẫu đã được gán; bỏ qua để lấy ảnh đầu tiên')},
        ('project_id','icon_name')),
    'veloura_import_image': Tool('Nhập ảnh vào thư mục project, đổi định dạng và resize. Không ghi đè mặc định.', 'import_image',
        {'project_id': ID, 'icon_name': NAME,
         'image_path': field('string','Đường dẫn ảnh nguồn tồn tại trên cùng máy Windows'),
         'overwrite': field('boolean','true cho phép ghi đè định dạng được chọn, mặc định false'),
         'move': field('boolean','true xóa ảnh nguồn sau khi lưu thành công, mặc định false'),
         'resize': field('boolean','true dùng resize, false giữ kích thước, mặc định theo project'),
         'width': field('integer','Chiều rộng px',minimum=1,maximum=16384),
         'height': field('integer','Chiều cao px',minimum=1,maximum=16384),
         'mode': field('string','contain/cover/stretch',enum=['contain','cover','stretch']),
         'output_format': field('string','png/jpg/webp/bmp/tiff; mặc định theo project',enum=['png','jpg','webp','bmp','tiff'])},
        ('project_id','icon_name','image_path')),
    'veloura_rename_png': Tool('Đổi tên file ảnh bên trong project; không đổi Excel/CSV.', 'rename_png',
        {'project_id': ID, 'old_name': NAME, 'new_name': NAME,
         'overwrite': field('boolean','true cho phép ghi đè file mới')}, ('project_id','old_name','new_name')),
}


class MCPServer:
    def __init__(self, service: CoreService | None = None):
        self.service = service or CoreService()
        self.initialized = False
        self.protocol = '2025-11-25'

    @staticmethod
    def _result(id_value, result):
        return {'jsonrpc':'2.0', 'id':id_value, 'result':result}

    @staticmethod
    def _error(id_value, code: int, message: str):
        return {'jsonrpc':'2.0', 'id':id_value, 'error':{'code':code, 'message':message}}

    def handle(self, message: Any):
        """Answer either legacy handshake or modern per-request-meta MCP."""
        if not isinstance(message, dict):
            return self._error(None, -32600, 'Invalid JSON-RPC request')
        if 'params' in message and not isinstance(message['params'], dict):
            return self._error(message.get('id'), -32602, 'params must be an object')
        params = message.get('params', {})
        metadata = params.get('_meta', {})
        modern = (message.get('method') == 'server/discover' or
                  isinstance(metadata, dict) and metadata.get('io.modelcontextprotocol/protocolVersion') == '2026-07-28')
        response = self._handle_request(message, modern=modern)
        if modern and response is not None and 'result' in response:
            response['result'].setdefault('resultType', 'complete')
            response['result'].setdefault('_meta', {})['io.modelcontextprotocol/serverInfo'] = {
                'name':MCP_SERVER_NAME, 'version':APP_VERSION}
        return response

    def _handle_request(self, message: Any, modern: bool = False):
        if not isinstance(message, dict) or message.get('jsonrpc') != '2.0':
            return self._error(None, -32600, 'Invalid JSON-RPC request')
        if 'params' in message and not isinstance(message['params'], dict):
            return self._error(message.get('id'), -32602, 'params must be an object')
        method = message.get('method')
        if method is None:  # client response; nothing to do
            return None
        is_notification = 'id' not in message
        id_value = message.get('id')
        if is_notification:
            if method == 'notifications/initialized':
                self.initialized = True
            return None
        if method == 'server/discover':
            return self._result(id_value, {'supportedVersions':['2026-07-28'],
                'capabilities':{'tools':{}} , 'ttlMs':300000, 'cacheScope':'private'})
        if method == 'initialize':
            params = message.get('params', {})
            request_version = params.get('protocolVersion', '2025-11-25')
            self.protocol = request_version if request_version in ('2025-11-25','2025-06-18') else '2025-11-25'
            return self._result(id_value, {'protocolVersion':self.protocol,
                'capabilities':{'tools':{'listChanged':False}},
                'serverInfo':{'name':MCP_SERVER_NAME,'version':APP_VERSION}})
        if method == 'ping':
            return self._result(id_value, {})
        if not self.initialized and not modern:
            return self._error(id_value, -32000, 'Client must initialize MCP first')
        if method == 'tools/list':
            return self._result(id_value, {'ttlMs':300000, 'cacheScope':'private', 'tools':[
                {'name':name, 'description': tool.description,
                 'inputSchema':{'type':'object','properties':tool.properties,
                                'required':list(tool.required),'additionalProperties':False}}
                for name,tool in TOOLS.items()]})
        if method == 'tools/call':
            params = message.get('params', {})
            name = params.get('name')
            tool = TOOLS.get(name)
            if tool is None:
                return self._error(id_value, -32602, 'Unknown Veloura tool')
            # Missing arguments is allowed for zero-argument tools; explicitly
            # provided null/list/scalar must not be silently coerced to {}.
            args = params['arguments'] if 'arguments' in params else {}
            if not isinstance(args, dict):
                return self._error(id_value, -32602, 'arguments must be an object')
            missing = [key for key in tool.required if key not in args]
            unknown = [key for key in args if key not in tool.properties]
            if missing or unknown:
                return self._error(id_value,-32602,'Invalid arguments: missing=' + ','.join(missing) + ', unknown=' + ','.join(unknown))
            for key, value in args.items():
                spec = tool.properties[key]
                kind = spec['type']
                valid = (isinstance(value, str) if kind == 'string' else
                         type(value) is bool if kind == 'boolean' else
                         type(value) is int if kind == 'integer' else False)
                if (not valid or
                        'enum' in spec and value not in spec['enum'] or
                        'minimum' in spec and value < spec['minimum'] or
                        'maximum' in spec and value > spec['maximum'] or
                        'minLength' in spec and len(value) < spec['minLength'] or
                        key == 'project_id' and not value.strip()):
                    return self._error(id_value, -32602, 'Invalid type/value for ' + key)
            try:
                value = getattr(self.service,tool.method)(**args)
                if name == 'veloura_view_image':
                    encoded = value.pop('image_base64')
                    mime = value.pop('mime_type')
                    return self._result(id_value, {'content':[
                        {'type':'text', 'text':json.dumps(value,ensure_ascii=False)},
                        {'type':'image','data':encoded,'mimeType':mime}], 'isError':False})
                return self._result(id_value, {'content':[{'type':'text','text':json.dumps(value, ensure_ascii=False)}],
                                               'structuredContent': value, 'isError':False})
            except (ValueError, FileNotFoundError, FileExistsError, OSError, PermissionError, RuntimeError, KeyError) as exc:
                return self._result(id_value, {'content':[{'type':'text','text':str(exc)}], 'isError':True})
        return self._error(id_value, -32601, 'Method not found')

    def serve(self, stdin=None, stdout=None):
        reader = stdin if stdin is not None else sys.stdin
        writer = stdout if stdout is not None else sys.stdout
        if reader is None or writer is None:
            raise RuntimeError('MCP yêu cầu stdin/stdout; dùng VelouraMCP.exe dạng console')
        for line in reader:
            if not line.strip():
                continue
            try:
                msg = json.loads(line)
            except (ValueError, UnicodeError):
                response = self._error(None,-32700,'Parse error')
            else:
                try:
                    response = self.handle(msg)
                except Exception:
                    traceback.print_exc(file=sys.stderr)
                    response = self._error(msg.get('id') if isinstance(msg,dict) else None,-32603,'Internal server error')
            if response is not None:
                writer.write(json.dumps(response, ensure_ascii=False, separators=(',',':')) + '\n')
                writer.flush()


def main():
    # Windows console code page may not be UTF-8. MCP wire data is UTF-8.
    for stream in (sys.stdin,sys.stdout):
        if stream is not None and hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8')
    MCPServer().serve()


if __name__ == '__main__':
    main()
