# -*- coding: utf-8 -*-
"""Veloura Image Manager: Excel/CSV-based name queue and drag/drop PNG image organizer."""
from __future__ import annotations

import queue
import sys
import tempfile
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

try:
    from PIL import ImageGrab
except Exception:
    ImageGrab = None

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    ROOT_CLASS = TkinterDnD.Tk
    DND_AVAILABLE = True
except ImportError:
    ROOT_CLASS = tk.Tk
    DND_AVAILABLE = False

from app_version import APP_TITLE
from file_picker import ask_source_file
from project_store import ProjectStore
from folder_live import FolderLiveMonitor, FolderSnapshot

from imageflow_core import NameItem, load_settings, normalize_source_path, save_settings

from veloura.gui.dialog_theme import BG
from veloura.controllers.options import CONFLICT_OPTIONS, RESIZE_OPTIONS
from veloura.controllers.options import label_for
from veloura.gui.widgets import make_label
from veloura.gui.gallery import GalleryUI

from veloura.controllers.projects import ProjectController
from veloura.controllers.source import SourceController
from veloura.controllers.folder import FolderController
from veloura.controllers.images import ImageController
from veloura.controllers.activity import ActivityController


class ImageManager:
    """Application controller with explicit method ownership, no MRO ambiguity.

    Feature functions run on this instance so GUI callbacks and app state retain
    their original behavior while implementation lives in dedicated modules.
    """
    txt = staticmethod(make_label)
    _label_for = staticmethod(label_for)
    _notify_project_warnings = ProjectController._notify_project_warnings
    _sync_project_registry = ProjectController._sync_project_registry
    _restore_startup_project = ProjectController._restore_startup_project
    _on_project_selected = ProjectController._on_project_selected
    activate_project = ProjectController.activate_project
    _install_project = ProjectController._install_project
    _refresh_project_selector = ProjectController._refresh_project_selector
    _validate_project_fields = ProjectController._validate_project_fields
    _project_dialog = ProjectController._project_dialog
    new_project = ProjectController.new_project
    _save_project_fields = ProjectController._save_project_fields
    edit_project = ProjectController.edit_project
    delete_project = ProjectController.delete_project
    open_source = SourceController.open_source
    paste_source_path = SourceController.paste_source_path
    open_recent = SourceController.open_recent
    _source_fingerprint = staticmethod(SourceController._source_fingerprint)
    _reload_source_if_changed = SourceController._reload_source_if_changed
    import_source = SourceController.import_source
    on_header_changed = SourceController.on_header_changed
    on_sheet_changed = SourceController.on_sheet_changed
    selected_col_index = SourceController.selected_col_index
    selected_prompt_col_index = SourceController.selected_prompt_col_index
    load_selected_column = SourceController.load_selected_column
    _apply_names = SourceController._apply_names
    _update_counter = SourceController._update_counter
    draw_items = SourceController.draw_items
    on_tree_select = SourceController.on_tree_select
    _refresh_target = SourceController._refresh_target
    _update_empty_selection = SourceController._update_empty_selection
    select_next = SourceController.select_next
    select_by_index = SourceController.select_by_index
    _focus_tree = SourceController._focus_tree
    add_name = SourceController.add_name
    _insert_custom_name = SourceController._insert_custom_name
    rename_item = SourceController.rename_item
    _reviewed_name_set = FolderController._reviewed_name_set
    _is_reviewed_name = FolderController._is_reviewed_name
    _can_mark_review = FolderController._can_mark_review
    _store_review_marks = FolderController._store_review_marks
    _set_review_mark = FolderController._set_review_mark
    _prune_review_marks = FolderController._prune_review_marks
    _refresh_review_rows = FolderController._refresh_review_rows
    toggle_review_for_selected = FolderController.toggle_review_for_selected
    _schedule_folder_rebind = FolderController._schedule_folder_rebind
    _rebind_folder_monitor = FolderController._rebind_folder_monitor
    _matching_png_path = FolderController._matching_png_path
    _apply_png_states = FolderController._apply_png_states
    delete_gallery_png = FolderController.delete_gallery_png
    _on_live_folder_snapshot = FolderController._on_live_folder_snapshot
    refresh_from_disk = FolderController.refresh_from_disk
    refresh_existing_states = FolderController.refresh_existing_states
    _set_prompt_text = ImageController._set_prompt_text
    _refresh_prompt = ImageController._refresh_prompt
    copy_prompt = ImageController.copy_prompt
    choose_reference = ImageController.choose_reference
    on_reference_drop = ImageController.on_reference_drop
    set_reference = ImageController.set_reference
    _restore_reference = ImageController._restore_reference
    _render_reference = ImageController._render_reference
    clear_reference = ImageController.clear_reference
    copy_reference = ImageController.copy_reference
    set_drop_active = ImageController.set_drop_active
    on_drop = ImageController.on_drop
    _output_format_changed = ImageController._output_format_changed
    choose_picture = ImageController.choose_picture
    process_image = ImageController.process_image
    _destination_changed = ImageController._destination_changed
    pick_destination = ImageController.pick_destination
    open_destination = ImageController.open_destination
    update_resize_description = ImageController.update_resize_description
    on_resize_toggled = ImageController.on_resize_toggled
    _poll = ActivityController._poll
    _append_activity = ActivityController._append_activity
    _show_preview = ActivityController._show_preview
    refresh_history = ActivityController.refresh_history
    clear_history = ActivityController.clear_history
    _clear_activity_text = ActivityController._clear_activity_text
    export_logs = ActivityController.export_logs
    _status = ActivityController._status
    on_close = ActivityController.on_close

    def __init__(self):
        self.root = ROOT_CLASS()
        self.settings = load_settings()
        try:
            self.project_store = ProjectStore(self.settings)
        except (OSError, ValueError, TypeError) as exc:
            messagebox.showerror(
                "Không thể mở danh sách project",
                "Không thể bảo vệ hoặc khôi phục dữ liệu project. File cấu hình chưa bị ghi đè.\n\n"
                "Hãy kiểm tra quyền ghi thư mục cấu hình.\n\n" + str(exc),
                parent=self.root,
            )
            self.root.destroy()
            raise SystemExit(1) from exc
        self._initial_project_id = self.project_store.active_id
        self.settings.update(self.project_store.active)
        self._changing_project = False
        self.project_logs = {}
        self.root.title(APP_TITLE)
        self.root.configure(bg=BG)
        try:
            self.root.iconbitmap(str(Path(__file__).parent / "assets" / "veloura_icon.ico"))
        except (tk.TclError, OSError):
            pass
        geometry = str(self.settings.get("window_geometry", "1380x900"))
        self.root.geometry(geometry if "x" in geometry else "1250x790")
        self.root.minsize(1060, 690)
        try:
            # Keep platform/Windows DPI scaling; do not forcibly enlarge every widget.
            self.root.tk.call("tk", "scaling", self.root.winfo_fpixels("1i") / 72.0)
        except tk.TclError:
            pass
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.messages = queue.Queue()
        self.workbook = None
        self.source_path = None
        self._source_disk_signature = None
        self._source_change_pending = None
        self._source_restore_name = None
        self.items: list[NameItem] = []
        self.selected_index = None
        self.columns = []
        self.duplicates = 0
        self.processing = False
        self.render_ticket = 0
        self.logs: list[dict] = []
        self.preview_ref = None
        self.save_task = None
        self._save_error_reported = False
        self._save_retry_count = 0
        self._closing = False
        self._sync_project_task = None
        self._review_marks_dirty = False
        self.read_ticket = 0
        self.drag_over = False
        self._on_scroll = False
        self._source_has_collapsed = False

        self.destination = tk.StringVar(value=self.settings["destination"])
        self.operation = tk.StringVar(value=self.settings["operation"])
        self.output_format = tk.StringVar(value=str(self.settings.get("output_format", "png")).lower())
        self.resize_enabled = tk.BooleanVar(value=bool(self.settings["resize_enabled"]))
        self.width_var = tk.StringVar(value=str(self.settings["resize_width"]))
        self.height_var = tk.StringVar(value=str(self.settings["resize_height"]))
        self.resize_mode = tk.StringVar(value=self._label_for(RESIZE_OPTIONS, self.settings["resize_mode"]))
        self.conflict = tk.StringVar(value=self._label_for(CONFLICT_OPTIONS, self.settings["conflict"]))
        self.advance = tk.BooleanVar(value=bool(self.settings["advance"]))
        self.has_header = tk.BooleanVar(value=bool(self.settings["has_header"]))
        self.search_var = tk.StringVar()
        self.filter_var = tk.StringVar(value="Tất cả")
        self.sheet_var = tk.StringVar()
        self.column_var = tk.StringVar()
        self.prompt_column_var = tk.StringVar(value="Không chọn")
        self.reference_path = tk.StringVar(value=self.settings.get("reference_path", ""))
        self.reference_photo = None
        self.reference_original = None
        self.reference_drag_over = False
        self.notice_var = tk.StringVar(value="Nhập file Excel hoặc CSV để bắt đầu")
        self.project_choice_var = tk.StringVar(value=self.project_store.active["name"])
        self.current_page = "workspace"
        self.gallery_search_var = tk.StringVar()
        self.gallery_filter_var = tk.StringVar(value="Tất cả")
        self.gallery_thumb_refs = []
        self.review_marks = set(str(name).strip() for name in self.settings.get("review_marks", []) if str(name).strip())
        # PNG status is sourced from the active folder, never from saved logs.
        self._folder_snapshot = FolderSnapshot()
        self._live_monitor = None
        self._live_generation = 0
        self._live_folder_path = None
        self._folder_rebind_task = None
        self.ui_icons = {}
        self._prepare_icons()
        self._build_styles()
        self._build_layout()
        self._live_monitor = FolderLiveMonitor(
            lambda generation, snapshot: self.messages.put(("folder_snapshot", generation, snapshot)),
            interval=2.5,  # Windows uses native events; fallback checks every 2.5 s.
            reconcile_interval=45.0,
        )
        self._rebind_folder_monitor()
        for variable in (self.destination, self.operation, self.output_format, self.resize_enabled, self.width_var,
                         self.height_var, self.resize_mode, self.conflict, self.advance, self.has_header, self.reference_path):
            variable.trace_add("write", self._schedule_save)
        self.search_var.trace_add("write", lambda *args: self.draw_items())
        self.filter_var.trace_add("write", lambda *args: self.draw_items())
        self.destination.trace_add("write", self._schedule_folder_rebind)
        self.gallery_search_var.trace_add("write", lambda *args: self.refresh_gallery())
        self.gallery_filter_var.trace_add("write", lambda *args: self.refresh_gallery())
        self.output_format.trace_add("write", self._output_format_changed)
        self.root.after(130, self._poll)
        self.root.after(280, self._update_empty_selection)
        self.root.after(330, self._restore_reference)
        self.root.after(480, self._restore_startup_project)
        self.root.after(850, self._notify_project_warnings)
        self._sync_project_task = self.root.after(2800, self._sync_project_registry)

    def _browse_project_source(self, parent, variable):
        """Project paths are selected, not typed. Reuse the proven CSV/Excel browser."""
        current = variable.get().strip()
        initial = Path(normalize_source_path(current)).expanduser().parent if current else Path.home()
        selected = ask_source_file(parent, initial)
        if selected:
            variable.set(normalize_source_path(selected))

    def _browse_project_folder(self, parent, variable):
        current = variable.get().strip()
        initial = Path(current).expanduser()
        if not initial.is_dir():
            initial = initial.parent if initial.parent.is_dir() else Path.home()
        selected = filedialog.askdirectory(parent=parent, title="Chọn thư mục lưu PNG của project",
                                          initialdir=str(initial), mustexist=True)
        if selected:
            variable.set(selected)

    def _schedule_save(self, *args):
        if self._changing_project:
            return
        if self.save_task:
            self.root.after_cancel(self.save_task)
        self.save_task = self.root.after(500, self.persist_settings)

    def persist_settings(self):
        self.save_task = None
        if self._changing_project:
            return
        self.settings.update({
            "destination": self.destination.get().strip(),
            "operation": self.operation.get(),
            "output_format": self.output_format.get() if hasattr(self, "output_format") else self.settings.get("output_format", "png"),
            "resize_enabled": self.resize_enabled.get(),
            "resize_width": self.width_var.get(),
            "resize_height": self.height_var.get(),
            "resize_mode": RESIZE_OPTIONS.get(self.resize_mode.get(), "contain"),
            "conflict": CONFLICT_OPTIONS.get(self.conflict.get(), "ask"),
            "advance": self.advance.get(),
            "has_header": self.has_header.get(),
            "last_source": str(self.source_path) if self.source_path else self.settings.get("last_source", ""),
            "last_sheet": self.sheet_var.get(),
            "last_column": self.selected_col_index(),
            "last_prompt_column": self.selected_prompt_col_index(),
            "reference_path": self.reference_path.get(),
            "review_marks": sorted(getattr(self, "review_marks", []), key=str.casefold),
        })
        try:
            save_settings(self.settings)
            project_updates = dict(self.settings)
            # Agent review marks are external edits. Don't restore an older
            # in-memory copy when the GUI only changed an unrelated setting.
            if not getattr(self, '_review_marks_dirty', False):
                project_updates.pop('review_marks', None)
            self.project_store.update_active(project_updates)
        except (OSError, ValueError, TypeError) as exc:
            msg = f"Không thể lưu cài đặt/project: {exc}"
            self._status(msg)
            if hasattr(self, 'activity'):
                self._append_activity("!  " + msg)
            if not self._save_error_reported:
                self._save_error_reported = True
                advice = ("Cài đặt chưa được lưu. Hãy kiểm tra quyền ghi thư mục cấu hình."
                          if self._closing else
                          "Ứng dụng sẽ thử lưu lại tối đa 3 lần. Hãy kiểm tra quyền ghi thư mục cấu hình.")
                messagebox.showwarning("Không lưu được cài đặt", msg + "\n\n" + advice, parent=self.root)
            self._save_retry_count += 1
            if not self._closing and self._save_retry_count <= 3:
                if self.save_task:
                    self.root.after_cancel(self.save_task)
                self.save_task = self.root.after(2500, self.persist_settings)
            return False
        self._save_error_reported = False
        self._save_retry_count = 0
        self._review_marks_dirty = False
        return True

    def paste_image_from_clipboard(self, event=None):
        # Let ordinary text fields handle Ctrl+V as text paste.
        if event is not None:
            target = self.root.focus_get()
            if isinstance(target, (tk.Entry, ttk.Entry, ttk.Combobox)):
                return None
            if isinstance(target, tk.Text) and str(target.cget("state")) == "normal":
                return None
        if self.processing:
            return "break"
        if self.selected_index is None:
            messagebox.showinfo("Chưa chọn tên ảnh", "Hãy chọn một tên ảnh đích trước khi dán ảnh từ clipboard.")
            return
        if ImageGrab is None:
            messagebox.showerror("Chưa hỗ trợ", "Môi trường hiện tại không hỗ trợ đọc ảnh từ clipboard.")
            return
        try:
            payload = ImageGrab.grabclipboard()
        except Exception as exc:
            messagebox.showerror("Không đọc được clipboard", str(exc))
            return
        if payload is None:
            messagebox.showinfo("Clipboard trống", "Clipboard hiện chưa có ảnh để dán.")
            return
        if isinstance(payload, list) and payload:
            candidate = Path(payload[0])
            if candidate.is_file():
                self.process_image(candidate)
                return
        if hasattr(payload, "save"):
            temp_dir = Path(tempfile.gettempdir()) / "veloura_image_manager"
            temp_dir.mkdir(parents=True, exist_ok=True)
            # Unique path prevents two fast pastes from reusing the same file.
            with tempfile.NamedTemporaryFile(prefix="clipboard_", suffix=".png",
                                             dir=temp_dir, delete=False) as tmp:
                temp_path = Path(tmp.name)
            try:
                payload.save(temp_path, format="PNG")
            except Exception as exc:
                temp_path.unlink(missing_ok=True)
                messagebox.showerror("Không đọc được clipboard", str(exc))
                return
            try:
                self.process_image(temp_path, transient_source=True)
            finally:
                # The background worker takes ownership only after processing=True.
                # Skip/cancel/invalid destination must never leak temp PNGs.
                if not self.processing:
                    temp_path.unlink(missing_ok=True)
            return
        messagebox.showinfo("Clipboard chưa đúng", "Clipboard hiện chưa chứa ảnh hợp lệ. Bạn có thể copy ảnh rồi thử lại.")



from modern_ui import MonoUI
from veloura.gui.workspace import WorkspaceUI
from veloura.gui.projects import ProjectsUI
from veloura.gui.other_pages import OtherPagesUI
from compact_view import CompactWindowActions


class ModernResourceManager(ImageManager):
    """Single-inheritance GUI: explicit UI overrides and compact-mode hooks."""

    # Use the controller implementation when a presentation hook wraps it.
    _persist_controller_settings = ImageManager.persist_settings
    _install_controller_project = ProjectController._install_project
    _rename_source_item = SourceController.rename_item
    _refresh_source_target = SourceController._refresh_target
    _update_source_empty_selection = SourceController._update_empty_selection

    # UI routing: stable, easily searchable mapping to each page module.
    _build_sidebar = WorkspaceUI._build_sidebar
    toggle_source_details = WorkspaceUI.toggle_source_details
    _build_main_panel = WorkspaceUI._build_main_panel
    _resize_options = staticmethod(WorkspaceUI._resize_options)
    _conflict_options = staticmethod(WorkspaceUI._conflict_options)
    _responsive_workspace = WorkspaceUI._responsive_workspace
    _resize_right_content = WorkspaceUI._resize_right_content
    _update_counter = WorkspaceUI._update_counter
    paint_dropzone = WorkspaceUI.paint_dropzone
    select_previous = WorkspaceUI.select_previous
    _update_review_controls = WorkspaceUI._update_review_controls
    _refresh_selected_output_preview = WorkspaceUI._refresh_selected_output_preview
    _show_preview = WorkspaceUI._show_preview
    rename_item = WorkspaceUI.rename_item
    _restore_reference = WorkspaceUI._restore_reference
    _update_reference_scroll_region = WorkspaceUI._update_reference_scroll_region
    _render_reference = WorkspaceUI._render_reference
    _toggle_reference_for_icon = WorkspaceUI._toggle_reference_for_icon
    _store_reference_config = WorkspaceUI._store_reference_config
    choose_reference = WorkspaceUI.choose_reference
    set_reference = WorkspaceUI.set_reference
    clear_reference = WorkspaceUI.clear_reference
    _remove_reference = WorkspaceUI._remove_reference
    copy_reference = WorkspaceUI.copy_reference
    _refresh_target = WorkspaceUI._refresh_target
    _update_empty_selection = WorkspaceUI._update_empty_selection
    persist_settings = WorkspaceUI.persist_settings
    _install_project = WorkspaceUI._install_project
    _get_template_text = WorkspaceUI._get_template_text
    _set_template_text = WorkspaceUI._set_template_text
    _assembled_prompt = WorkspaceUI._assembled_prompt
    _refresh_prompt = WorkspaceUI._refresh_prompt
    copy_prompt = WorkspaceUI.copy_prompt
    _build_gallery_page = GalleryUI._build_gallery_page
    _gallery_mouse_wheel = GalleryUI._gallery_mouse_wheel
    _bind_gallery_wheel_children = GalleryUI._bind_gallery_wheel_children
    _gallery_query_changed = GalleryUI._gallery_query_changed
    _on_gallery_canvas_configure = GalleryUI._on_gallery_canvas_configure
    _gallery_resize_done = GalleryUI._gallery_resize_done
    _change_gallery_page = GalleryUI._change_gallery_page
    _gallery_display_items = GalleryUI._gallery_display_items
    _gallery_status_text = staticmethod(GalleryUI._gallery_status_text)
    _gallery_can_reconcile_cards = staticmethod(GalleryUI._gallery_can_reconcile_cards)
    _make_gallery_card = GalleryUI._make_gallery_card
    _update_gallery_card_image = GalleryUI._update_gallery_card_image
    _reconcile_gallery_cards = GalleryUI._reconcile_gallery_cards
    refresh_gallery = GalleryUI.refresh_gallery
    _gallery_scope = GalleryUI._gallery_scope
    _gallery_prune_selection = GalleryUI._gallery_prune_selection
    _gallery_update_batch_toolbar = GalleryUI._gallery_update_batch_toolbar
    _gallery_paint_selection = GalleryUI._gallery_paint_selection
    _gallery_repaint_selections = GalleryUI._gallery_repaint_selections
    _gallery_toggle_selection = GalleryUI._gallery_toggle_selection
    _gallery_clear_selection = GalleryUI._gallery_clear_selection
    _gallery_select_all = GalleryUI._gallery_select_all
    _gallery_batch_dialog = GalleryUI._gallery_batch_dialog
    _gallery_batch_resize = GalleryUI._gallery_batch_resize
    _gallery_batch_convert = GalleryUI._gallery_batch_convert
    _gallery_start_batch = GalleryUI._gallery_start_batch
    _gallery_batch_progress = GalleryUI._gallery_batch_progress
    _gallery_batch_finished = GalleryUI._gallery_batch_finished
    _gallery_go = GalleryUI._gallery_go
    _gallery_select = GalleryUI._gallery_select
    _toggle_gallery_review = GalleryUI._toggle_gallery_review
    _open_gallery_selected = GalleryUI._open_gallery_selected
    _goto_gallery_selected = GalleryUI._goto_gallery_selected
    _on_gallery_card = GalleryUI._on_gallery_card
    _open_external = GalleryUI._open_external
    _build_projects_page = ProjectsUI._build_projects_page
    refresh_projects_page = ProjectsUI.refresh_projects_page
    _select_project_card = ProjectsUI._select_project_card
    _render_project_detail = ProjectsUI._render_project_detail
    _select_project_from_page = ProjectsUI._select_project_from_page
    _duplicate_project = ProjectsUI._duplicate_project
    _build_extra_pages = OtherPagesUI._build_extra_pages
    _refresh_progress_page = OtherPagesUI._refresh_progress_page
    _refresh_reference_page = OtherPagesUI._refresh_reference_page
    _copy_one_reference = OtherPagesUI._copy_one_reference
    _build_template_content = OtherPagesUI._build_template_content
    _save_prompt_template = OtherPagesUI._save_prompt_template
    _refresh_template_page = OtherPagesUI._refresh_template_page
    _refresh_history_page = OtherPagesUI._refresh_history_page
    _refresh_settings_page = OtherPagesUI._refresh_settings_page
    _build_about_page = OtherPagesUI._build_about_page
    _build_workspace_shell = MonoUI._build_workspace_shell
    _create_nav_button = MonoUI._create_nav_button
    _scroll_area = MonoUI._scroll_area
    _is_descendant = MonoUI._is_descendant
    _project_bar = MonoUI._project_bar
    _section_title = MonoUI._section_title
    _set_nav_button_state = MonoUI._set_nav_button_state
    _surface = MonoUI._surface
    _field = MonoUI._field
    show_page = MonoUI.show_page
    _cached_thumbnail = MonoUI._cached_thumbnail
    _build_layout = MonoUI._build_layout
    _build_styles = MonoUI._build_styles
    _workspace_wheel_router = MonoUI._workspace_wheel_router
    _build_navigation_drawer = MonoUI._build_navigation_drawer
    button = MonoUI.button
    _install_workspace_wheel_router = MonoUI._install_workspace_wheel_router
    _prepare_icons = MonoUI._prepare_icons
    _get_icon = MonoUI._get_icon

    # Compact hooks wrap the base UI callbacks without MRO/super() chaining.
    _build_desktop_layout = MonoUI._build_layout
    _paint_workspace_dropzone = WorkspaceUI.paint_dropzone
    _refresh_workspace_target = WorkspaceUI._refresh_target
    _update_workspace_empty_selection = WorkspaceUI._update_empty_selection
    _refresh_workspace_output_preview = WorkspaceUI._refresh_selected_output_preview
    _build_layout = CompactWindowActions._build_layout
    _compact_icon_button = CompactWindowActions._compact_icon_button
    _compact_schedule_dnd_registration = CompactWindowActions._compact_schedule_dnd_registration
    _compact_activate_drop_targets = CompactWindowActions._compact_activate_drop_targets
    _compact_on_drop = CompactWindowActions._compact_on_drop
    _compact_delete_output = CompactWindowActions._compact_delete_output
    _build_compact_layout = CompactWindowActions._build_compact_layout
    _compact_ellipsize = staticmethod(CompactWindowActions._compact_ellipsize)
    _compact_fit_label = CompactWindowActions._compact_fit_label
    _compact_name_resized = CompactWindowActions._compact_name_resized
    _compact_detail_resized = CompactWindowActions._compact_detail_resized
    _compact_set_detail = CompactWindowActions._compact_set_detail
    _compact_bind_tooltip = CompactWindowActions._compact_bind_tooltip
    _compact_schedule_tooltip = CompactWindowActions._compact_schedule_tooltip
    _compact_hide_tooltip = CompactWindowActions._compact_hide_tooltip
    _compact_copy_tooltip_text = CompactWindowActions._compact_copy_tooltip_text
    _compact_thumbnail_bounds = staticmethod(CompactWindowActions._compact_thumbnail_bounds)
    _compact_preview_resized = CompactWindowActions._compact_preview_resized
    _compact_redraw_after_resize = CompactWindowActions._compact_redraw_after_resize
    _paint_compact_dropzone = CompactWindowActions._paint_compact_dropzone
    paint_dropzone = CompactWindowActions.paint_dropzone
    _compact_select_next = CompactWindowActions._compact_select_next
    _compact_toggle_pin = CompactWindowActions._compact_toggle_pin
    _compact_capture_normal_geometry = CompactWindowActions._compact_capture_normal_geometry
    _compact_window_state_changed = CompactWindowActions._compact_window_state_changed
    _compact_schedule_caption_switch = CompactWindowActions._compact_schedule_caption_switch
    _compact_switch_from_caption = CompactWindowActions._compact_switch_from_caption
    _compact_enter = CompactWindowActions._compact_enter
    _compact_exit = CompactWindowActions._compact_exit
    _compact_release_switch = CompactWindowActions._compact_release_switch
    _compact_update_name = CompactWindowActions._compact_update_name
    _compact_show_preview_message = CompactWindowActions._compact_show_preview_message
    _compact_refresh_output = CompactWindowActions._compact_refresh_output
    _refresh_target = CompactWindowActions._refresh_target
    _update_empty_selection = CompactWindowActions._update_empty_selection
    _refresh_selected_output_preview = CompactWindowActions._refresh_selected_output_preview


def main():
    if '--mcp' in sys.argv:
        from mcp_stdio import main as serve_agent
        serve_agent()
        return
    app = ModernResourceManager()
    app.root.mainloop()


if __name__ == "__main__":
    main()
