"""Persistent, isolated project profiles for Veloura Image Manager.

Only project metadata is managed here. No operation deletes user images or
source spreadsheets. The pre-project settings are migrated on first run.
"""
from __future__ import annotations

import json
import os
import uuid
import ntpath
import re
import shutil
import datetime as dt
from copy import deepcopy
from storage_lock import file_lock
from pathlib import Path

from imageflow_core import APP_DIR, DEFAULTS

REGISTRY_PATH = APP_DIR / "projects.json"
PROJECT_KEYS = (
    "destination", "last_source", "last_sheet", "last_column",
    "last_prompt_column", "reference_path", "has_header", "operation",
    "resize_enabled", "resize_width", "resize_height", "resize_mode", "output_format",
    "conflict", "advance", "reference_paths", "reference_assignments",
    "prompt_template", "template_enabled", "review_marks",
)


def project_data(name: str, destination: str, settings: dict | None = None, project_id: str | None = None) -> dict:
    name = name.strip()
    destination = destination.strip().strip('"')
    if not name:
        raise ValueError("Hãy nhập tên project.")
    if not destination:
        raise ValueError("Hãy chọn thư mục lưu ảnh Image Gen cho project.")
    if any(ch in name for ch in "\n\r\t"):
        raise ValueError("Tên project không được chứa ký tự xuống dòng hoặc tab.")
    fallback = {"reference_paths": [], "reference_assignments": {},
                "prompt_template": "", "template_enabled": False, "review_marks": []}
    profile = {key: (settings or {}).get(key, DEFAULTS.get(key, fallback.get(key))) for key in PROJECT_KEYS}
    # Legacy v1.9 projects used one reference_path; preserve it during migration.
    if "reference_paths" not in (settings or {}) or not isinstance(profile.get("reference_paths"), list):
        previous = str(profile.get("reference_path", "") or "")
        profile["reference_paths"] = [previous] if previous else []
    if not isinstance(profile.get("reference_assignments"), dict):
        profile["reference_assignments"] = {}
    profile["prompt_template"] = str(profile.get("prompt_template") or "")
    profile["template_enabled"] = bool(profile.get("template_enabled", False))
    if not isinstance(profile.get("review_marks"), list):
        profile["review_marks"] = []
    profile["review_marks"] = sorted({str(name).strip() for name in profile.get("review_marks", []) if str(name).strip()}, key=str.casefold)
    profile.update({"id": project_id or uuid.uuid4().hex, "name": name,
                    "destination": destination, "description": str((settings or {}).get("description", "") or "")})
    return profile


class ProjectStore:
    def __init__(self, legacy_settings: dict, path: Path = REGISTRY_PATH):
        self.path = Path(path)
        self.projects: list[dict] = []
        self.active_id = ""
        self.recovery_warning = ""
        self.load_warnings: list[str] = []
        self._base_projects = []
        self._base_active_id = ""
        self._stamp = None
        self._registry_was_corrupt = False
        # First launch can start both the GUI and the MCP process. Serialize
        # initial creation using the same lock as save() so every process
        # loads the one registry/ID that actually won the race.
        self._bootstrap_missing_registry(legacy_settings)
        data = None
        if self.path.exists():
            try:
                data = self._read_registry(self.path)
            except (OSError, ValueError, TypeError) as exc:
                self._registry_was_corrupt = True
                # Preserve the damaged bytes BEFORE writing a new registry.
                # If we cannot make a recovery copy, refuse to overwrite anything.
                stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
                corrupt = self.path.with_name(f"{self.path.stem}.corrupt.{stamp}.{uuid.uuid4().hex[:6]}.json")
                shutil.copy2(self.path, corrupt)
                backup = self.path.with_suffix(".bak")
                if backup.is_file():
                    try:
                        data = self._read_registry(backup)
                        self.recovery_warning = ("File project bị lỗi. Đã giữ bản gốc tại " + str(corrupt)
                                                 + "; khôi phục từ bản sao lưu " + str(backup))
                    except (OSError, ValueError, TypeError):
                        pass
                if data is None:
                    self.recovery_warning = ("File project bị lỗi. Đã giữ bản gốc tại " + str(corrupt)
                                             + ". Ứng dụng khởi tạo project mặc định; hãy kiểm tra lại danh sách project.")
        if data is not None:
            ids = set()
            for item in data["projects"]:
                if not isinstance(item, dict) or not item.get("id") or item["id"] in ids:
                    continue
                try:
                    project = project_data(str(item.get("name", "")), str(item.get("destination", "")), item, str(item["id"]))
                except ValueError:
                    continue
                self.projects.append(project)
                ids.add(project["id"])
            self.active_id = str(data.get("active_id", ""))
        if not self.projects:
            self.projects = [project_data("Project mặc định", legacy_settings.get("destination", DEFAULTS["destination"]), legacy_settings)]
            self.active_id = self.projects[0]["id"]
            self.save()
        if not any(p["id"] == self.active_id for p in self.projects):
            self.active_id = self.projects[0]["id"]
            self.save()
        self._base_projects = deepcopy(self.projects)
        self._base_active_id = self.active_id
        self._stamp = self._stat_stamp()
        seen_paths = {}
        for project in self.projects:
            key = self._path_key(project["destination"])
            if key in seen_paths:
                self.load_warnings.append(f"Project '{project['name']}' và '{seen_paths[key]}' trỏ cùng thư mục. Hãy tách thư mục để tránh trộn ảnh Image Gen.")
            seen_paths[key] = project["name"]

    def _bootstrap_missing_registry(self, legacy_settings: dict):
        """Create the first registry exactly once, with no nested save() lock.

        A second process must observe the already-created ID instead of
        constructing a competing default project. Never touch an existing
        (including corrupt) registry here; the normal recovery path owns it.
        """
        if self.path.is_file():
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with file_lock(self.path.with_suffix('.lock')):
            if self.path.exists():
                return
            first = project_data(
                'Project mặc định', legacy_settings.get('destination', DEFAULTS['destination']),
                legacy_settings,
            )
            data = {'version': 1, 'active_id': first['id'], 'projects': [first]}
            temp = self.path.with_name(self.path.name + '.' + uuid.uuid4().hex + '.tmp')
            try:
                with temp.open('w', encoding='utf-8') as handle:
                    json.dump(data, handle, ensure_ascii=False, indent=2)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temp, self.path)
            finally:
                temp.unlink(missing_ok=True)

    @staticmethod
    def _read_registry(path: Path) -> dict:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("projects"), list) or not data["projects"]:
            raise ValueError("Cấu trúc danh sách project không hợp lệ")
        if not any(isinstance(item, dict) and item.get("id") and item.get("name") and item.get("destination")
                   for item in data["projects"]):
            raise ValueError("Không có project hợp lệ")
        return data

    @property
    def active(self) -> dict:
        return self.get(self.active_id)

    def get(self, project_id: str) -> dict:
        for item in self.projects:
            if item["id"] == project_id:
                return item
        raise KeyError("Không tìm thấy project")

    def _check_unique(self, name: str, project_id: str | None = None):
        if any(p["name"].casefold() == name.strip().casefold() and p["id"] != project_id for p in self.projects):
            raise ValueError("Đã có project trùng tên.")

    @staticmethod
    def _path_key(path: str) -> str:
        """Compare real folders, not their spelling (including symlinks and '..')."""
        raw = path.strip().strip('"')
        if not raw:
            return ""
        if re.match(r"^[A-Za-z]:[\\/]", raw) or raw.startswith("\\\\"):
            # Also canonicalize Windows paths when tests run on Linux.
            return ntpath.normcase(ntpath.normpath(raw.replace("/", "\\")))
        return os.path.normcase(str(Path(raw).expanduser().resolve(strict=False))).casefold()

    def _check_destination(self, destination: str, project_id: str | None = None):
        key = self._path_key(destination)
        if any(self._path_key(p["destination"]) == key and p["id"] != project_id for p in self.projects):
            raise ValueError("Thư mục này đã được một project khác sử dụng. Hãy chọn thư mục riêng.")

    def add(self, name: str, destination: str, description: str = "", last_source: str = "",
            source_defaults: dict | None = None) -> dict:
        self._check_unique(name)
        self._check_destination(destination)
        initial = {"description": description, "last_source": last_source, "last_column": 0}
        if source_defaults:
            initial.update(source_defaults)
        project = project_data(name, destination, initial)
        self.projects.append(project)
        self.save()
        return project

    def edit(self, project_id: str, name: str, destination: str, description: str | None = None,
             last_source: str | None = None, source_defaults: dict | None = None):
        project = self.get(project_id)
        self._check_unique(name, project_id)
        self._check_destination(destination, project_id)
        data = project_data(name, destination, project, project_id)
        if description is not None:
            data["description"] = description
        if last_source is not None:
            normalized_source = last_source.strip()
            if normalized_source != str(project.get("last_source") or ""):
                data["last_source"] = normalized_source
                # Auto-suggest columns for the newly chosen spreadsheet.
                data["last_sheet"] = ""
                data["last_column"] = 0
                data["last_prompt_column"] = 0
                if source_defaults:
                    data.update(source_defaults)
        project.update(data)
        self.save()

    def update_active(self, settings: dict):
        project = self.active
        for key in PROJECT_KEYS:
            if key in settings:
                project[key] = settings[key]
        self.save()

    def select(self, project_id: str):
        self.get(project_id)
        self.active_id = project_id
        self.save()

    def remove(self, project_id: str):
        if len(self.projects) < 2:
            raise ValueError("Cần giữ lại ít nhất một project.")
        self.get(project_id)
        self.projects = [p for p in self.projects if p["id"] != project_id]
        if self.active_id == project_id:
            self.active_id = self.projects[0]["id"]
        self.save()

    def _stat_stamp(self):
        try:
            stat = self.path.stat()
            return stat.st_mtime_ns, stat.st_size
        except FileNotFoundError:
            return None

    def sync_from_disk(self) -> bool:
        """Reload only if the registry changed and no GUI edits are pending."""
        stamp = self._stat_stamp()
        if stamp == self._stamp:
            return False
        with file_lock(self.path.with_suffix('.lock')):
            if not self.path.is_file():
                return False
            data = self._read_registry(self.path)
            projects = []
            for row in data['projects']:
                if isinstance(row, dict) and row.get('id'):
                    projects.append(project_data(str(row['name']), str(row['destination']), row, str(row['id'])))
            if not projects:
                raise ValueError('Danh sách project trống')
            self.projects = projects
            self.active_id = str(data.get('active_id'))
            if self.active_id not in {p['id'] for p in projects}:
                self.active_id = projects[0]['id']
            self._base_projects = deepcopy(self.projects)
            self._base_active_id = self.active_id
            self._stamp = self._stat_stamp()
            return True

    def _merged_registry(self, remote):
        """Three-way merge changed fields only, rejecting real concurrent conflicts."""
        base = {p['id']: p for p in self._base_projects}
        local = {p['id']: p for p in self.projects}
        remote_rows = [project_data(str(p['name']), str(p['destination']), p, str(p['id']))
                       for p in remote.get('projects', []) if isinstance(p, dict) and p.get('id') and p.get('name') and p.get('destination')]
        latest = {p['id']: p for p in remote_rows}
        for project_id in base.keys() - local.keys():
            if project_id in latest:
                if latest[project_id] != base[project_id]:
                    raise ValueError('Project vừa được thay đổi bởi tiến trình khác; vui lòng thử lại')
                remote_rows = [p for p in remote_rows if p['id'] != project_id]
        for project_id, current in local.items():
            if project_id not in base:
                if project_id in latest:
                    raise ValueError('Mã project đã tồn tại')
                if any(p['name'].casefold() == current['name'].casefold() for p in remote_rows):
                    raise ValueError('Đã có project trùng tên')
                if any(self._path_key(p['destination']) == self._path_key(current['destination']) for p in remote_rows):
                    raise ValueError('Thư mục này đã thuộc project khác')
                remote_rows.append(deepcopy(current))
                continue
            old = base[project_id]
            changes = {key: deepcopy(value) for key, value in current.items() if old.get(key) != value}
            if not changes:
                continue
            target = next((p for p in remote_rows if p['id'] == project_id), None)
            if target is None:
                raise ValueError('Project đã bị xóa ở tiến trình khác')
            for key, value in changes.items():
                if target.get(key) != old.get(key) and target.get(key) != value:
                    raise ValueError('Cấu hình ' + key + ' vừa bị thay đổi bởi tiến trình khác; hãy làm mới project')
                target[key] = value
        if not remote_rows:
            raise ValueError('Cần giữ lại ít nhất một project')
        for i, p in enumerate(remote_rows):
            for other in remote_rows[i+1:]:
                if p['name'].casefold() == other['name'].casefold() or self._path_key(p['destination']) == self._path_key(other['destination']):
                    raise ValueError('Có project trùng tên hoặc thư mục với tiến trình khác')
        active = self.active_id if self.active_id != self._base_active_id else remote.get('active_id', self.active_id)
        if active not in {p['id'] for p in remote_rows}:
            active = remote_rows[0]['id']
        return {'version': 1, 'active_id': active, 'projects': remote_rows}

    def save(self):
        """Cross-process locked, atomic, conflict-detecting metadata save.

        Preserve the last valid registry as backup. Never overwrite an
        external change to a project field with a stale in-memory copy.
        """
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with file_lock(self.path.with_suffix('.lock')):
            if self.path.is_file() and not self._registry_was_corrupt:
                remote = self._read_registry(self.path)
            else:
                remote = {'version': 1, 'projects': [], 'active_id': ''}
            if not self._base_projects and not remote['projects']:
                data = {'version': 1, 'active_id': self.active_id, 'projects': deepcopy(self.projects)}
            else:
                data = self._merged_registry(remote)
            temp = self.path.with_name(self.path.name + '.' + uuid.uuid4().hex + '.tmp')
            try:
                with temp.open('w', encoding='utf-8') as handle:
                    json.dump(data, handle, ensure_ascii=False, indent=2)
                    handle.flush()
                    os.fsync(handle.fileno())
                if self.path.is_file():
                    try:
                        self._read_registry(self.path)
                    except (OSError, ValueError, TypeError):
                        pass
                    else:
                        backup = self.path.with_suffix('.bak')
                        backup_temp = backup.with_name(backup.name + '.' + uuid.uuid4().hex + '.tmp')
                        try:
                            shutil.copy2(self.path, backup_temp)
                            os.replace(backup_temp, backup)
                        finally:
                            backup_temp.unlink(missing_ok=True)
                os.replace(temp, self.path)
                by_id = {p['id']: p for p in self.projects}
                merged_objects = []
                for row in data['projects']:
                    normalized = project_data(row['name'], row['destination'], row, row['id'])
                    existing = by_id.get(row['id'])
                    if existing is not None:
                        existing.clear()
                        existing.update(normalized)
                        merged_objects.append(existing)
                    else:
                        merged_objects.append(normalized)
                self.projects = merged_objects
                self.active_id = data['active_id']
                self._base_projects = deepcopy(self.projects)
                self._base_active_id = self.active_id
                self._stamp = self._stat_stamp()
                self._registry_was_corrupt = False
            finally:
                temp.unlink(missing_ok=True)
